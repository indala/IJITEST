module.exports=[43622,(a,b,c)=>{}];

//# sourceMappingURL=b1735_p2_ijitest__next-internal_server_app_admin_settings_page_actions_377c3173.js.map