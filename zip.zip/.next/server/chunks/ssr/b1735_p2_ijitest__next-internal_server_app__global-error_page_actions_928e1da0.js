module.exports=[28586,(a,b,c)=>{}];

//# sourceMappingURL=b1735_p2_ijitest__next-internal_server_app__global-error_page_actions_928e1da0.js.map