module.exports=[29376,(a,b,c)=>{}];

//# sourceMappingURL=b1735_p2_ijitest__next-internal_server_app_admin_reviews_page_actions_e04d5926.js.map