module.exports=[98055,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_indexing_page_actions_e6be4588.js.map