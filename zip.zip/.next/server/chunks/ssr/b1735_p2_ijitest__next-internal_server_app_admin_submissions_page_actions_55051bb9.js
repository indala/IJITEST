module.exports=[2545,(a,b,c)=>{}];

//# sourceMappingURL=b1735_p2_ijitest__next-internal_server_app_admin_submissions_page_actions_55051bb9.js.map