module.exports=[97966,(a,b,c)=>{}];

//# sourceMappingURL=b1735_p2_ijitest__next-internal_server_app_reviewer-guidelines_page_actions_8185c536.js.map