module.exports=[6083,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},21731,a=>{"use strict";let b={src:a.i(6083).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=OneDrive_Desktop_p2_ijitest_src_app_387293a0._.js.map