module.exports=[3865,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_admin_login_page_actions_b699008b.js.map