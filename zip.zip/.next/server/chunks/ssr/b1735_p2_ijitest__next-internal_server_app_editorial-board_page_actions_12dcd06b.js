module.exports=[42521,(a,b,c)=>{}];

//# sourceMappingURL=b1735_p2_ijitest__next-internal_server_app_editorial-board_page_actions_12dcd06b.js.map