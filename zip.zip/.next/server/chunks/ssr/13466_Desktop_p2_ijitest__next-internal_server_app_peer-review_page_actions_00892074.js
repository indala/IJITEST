module.exports=[31252,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_peer-review_page_actions_00892074.js.map