module.exports=[98705,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app__not-found_page_actions_0d20e0ea.js.map