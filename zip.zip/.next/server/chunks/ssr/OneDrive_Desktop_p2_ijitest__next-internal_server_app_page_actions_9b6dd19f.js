module.exports=[54397,(a,b,c)=>{}];

//# sourceMappingURL=OneDrive_Desktop_p2_ijitest__next-internal_server_app_page_actions_9b6dd19f.js.map