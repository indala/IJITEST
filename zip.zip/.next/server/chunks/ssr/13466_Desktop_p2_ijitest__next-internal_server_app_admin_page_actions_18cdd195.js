module.exports=[82327,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_admin_page_actions_18cdd195.js.map