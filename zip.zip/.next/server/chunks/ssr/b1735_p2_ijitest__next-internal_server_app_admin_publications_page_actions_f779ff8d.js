module.exports=[45266,(a,b,c)=>{}];

//# sourceMappingURL=b1735_p2_ijitest__next-internal_server_app_admin_publications_page_actions_f779ff8d.js.map