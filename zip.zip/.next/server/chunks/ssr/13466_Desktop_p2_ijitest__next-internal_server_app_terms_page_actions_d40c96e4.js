module.exports=[78887,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_terms_page_actions_d40c96e4.js.map