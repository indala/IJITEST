module.exports=[58283,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_about_page_actions_afe84661.js.map