module.exports=[72693,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_guidelines_page_actions_72428531.js.map