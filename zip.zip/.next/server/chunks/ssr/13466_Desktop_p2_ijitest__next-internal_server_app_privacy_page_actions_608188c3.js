module.exports=[98975,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_privacy_page_actions_608188c3.js.map