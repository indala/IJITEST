module.exports=[69280,(a,b,c)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_dashboard_page_actions_04598339.js.map