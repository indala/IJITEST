module.exports=[33484,(e,o,d)=>{}];

//# sourceMappingURL=13466_Desktop_p2_ijitest__next-internal_server_app_favicon_ico_route_actions_114ef2ff.js.map