globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/9b34e485af0747e6.js",
    "static/chunks/65d1a60bb3db118b.js",
    "static/chunks/5aa9a4a78135bdfd.js",
    "static/chunks/9c2cf3e701b6b67f.js",
    "static/chunks/71dc2d37a5f4da20.js",
    "static/chunks/turbopack-6631196fdd16f0dc.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];