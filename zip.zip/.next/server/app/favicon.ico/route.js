var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__e04813c4._.js")
R.c("server/chunks/13466_Desktop_p2_ijitest__next-internal_server_app_favicon_ico_route_actions_114ef2ff.js")
R.m(52678)
module.exports=R.m(52678).exports
