"use client";

import Link from 'next/link';
import {
  ArrowRight,
  BookOpen,
  Search,
  ShieldCheck,
  Zap,
  FileText,
  CheckCircle2,
  Upload,
  Mail,
  Users,
  Scale
} from 'lucide-react';
import { motion } from 'framer-motion';

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

const disciplines = [
  "Engineering",
  "Science & Applied Sciences",
  "Technology & Innovation",
  "Computer Science & IT",
  "AI, ML & Data Science",
  "Electronics & Communication",
  "Mechanical & Civil",
  "IoT, Robotics & Automation",
  "Renewable Energy",
  "Management Studies"
];

const submissionSteps = [
  { icon: <FileText className="w-8 h-8" />, title: "Prepare", desc: "Format your paper using our template." },
  { icon: <Upload className="w-8 h-8" />, title: "Submit", desc: "Send via portal or email." },
  { icon: <Users className="w-8 h-8" />, title: "Review", desc: "Rigorous double-blind peer review." },
  { icon: <CheckCircle2 className="w-8 h-8" />, title: "Publish", desc: "Fast-track publication within 3 days." }
];

const quickLinks = [
  { title: "Editorial Board", href: "/editorial-board", icon: <Users className="w-5 h-5" />, color: "bg-blue-50 text-blue-600" },
  { title: "Journal Ethics", href: "/ethics", icon: <Scale className="w-5 h-5" />, color: "bg-purple-50 text-purple-600" },
  { title: "Author Guidelines", href: "/guidelines", icon: <FileText className="w-5 h-5" />, color: "bg-emerald-50 text-emerald-600" },
  { title: "Peer Review", href: "/peer-review", icon: <Search className="w-5 h-5" />, color: "bg-orange-50 text-orange-600" }
];

export default function Home() {
  return (
    <div className="flex flex-col overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 bg-white overflow-hidden">
        {/* Subtle Background Elements */}
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl opacity-50" />
        <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/4 w-[400px] h-[400px] bg-secondary/5 rounded-full blur-3xl opacity-50" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={staggerContainer}
            >
              <motion.div variants={fadeInUp} className="inline-flex items-center space-x-2 bg-blue-50 text-primary border border-blue-100 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest mb-8">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                </span>
                <span>Call for Papers - Vol. 1 Issue 1 (2026)</span>
              </motion.div>

              <motion.p variants={fadeInUp} className="text-secondary font-bold mb-3 tracking-widest uppercase text-sm">Felix Academic Publications Presents</motion.p>

              <motion.h1 variants={fadeInUp} className="text-4xl md:text-5xl lg:text-6xl font-serif font-black leading-[1.1] mb-8 text-primary">
                International Journal of Innovative Trends in <span className="text-primary italic">Engineering Science</span> & Technology
              </motion.h1>

              <motion.p variants={fadeInUp} className="text-2xl text-gray-500 font-serif italic mb-8 border-l-4 border-secondary pl-6">
                An International Peer-Reviewed open access Journal
              </motion.p>

              <motion.p variants={fadeInUp} className="text-lg text-gray-600 mb-12 max-w-xl leading-relaxed">
                IJITEST is a peer-reviewed scholarly journal dedicated to the dissemination of high-quality research across <span className="font-bold text-gray-900 underline decoration-secondary/30">Engineering, Science, Technology, and Management</span>.
              </motion.p>

              <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row gap-5">
                <Link href="/submit" className="group bg-primary text-white py-5 px-10 text-lg font-bold flex items-center justify-center gap-3 rounded-xl shadow-xl shadow-primary/20 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
                  Submit Your Paper
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link href="/guidelines" className="bg-white border-2 border-gray-100 text-gray-900 py-5 px-10 text-lg font-bold flex items-center justify-center gap-2 rounded-xl hover:border-primary hover:text-primary transition-all duration-300">
                  Author Guidelines
                </Link>
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9, x: 50 }}
              whileInView={{ opacity: 1, scale: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative hidden lg:block"
            >
              <div className="absolute -inset-10 bg-gradient-to-tr from-primary/10 to-transparent rounded-full blur-3xl" />
              <div className="relative bg-white p-10 rounded-[3rem] shadow-2xl border border-gray-50 backdrop-blur-sm overflow-hidden group">
                {/* Decorative Pattern */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-gray-50 rounded-bl-full -z-10 transition-transform group-hover:scale-110" />

                <div className="flex items-center justify-between mb-12">
                  <h3 className="text-2xl font-bold font-serif text-gray-900">Journal DNA</h3>
                  <div className="flex items-center gap-2 bg-gray-50 px-3 py-1 rounded-full">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[10px] font-black uppercase text-gray-400">Open For 2026</span>
                  </div>
                </div>

                <div className="space-y-6">
                  {[
                    { title: "Peer Reviewed", desc: "Rigorous Double-Blind Review", icon: <ShieldCheck className="w-6 h-6" />, color: "text-blue-500 bg-blue-50" },
                    { title: "Open Access", desc: "Creative Commons Attribution 4.0", icon: <Zap className="w-6 h-6" />, color: "text-amber-500 bg-amber-50" },
                    { title: "Rapid Decision", desc: "Review Result within 3 Days", icon: <Zap className="w-6 h-6" />, color: "text-emerald-500 bg-emerald-50" },
                  ].map((item, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ x: 10 }}
                      className="flex items-center gap-5 p-4 rounded-2xl border border-transparent hover:border-gray-100 hover:bg-gray-50 transition-all duration-300"
                    >
                      <div className={`p-3 rounded-xl ${item.color}`}>
                        {item.icon}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900">{item.title}</h4>
                        <p className="text-xs text-gray-500">{item.desc}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Quick Access Grid */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {quickLinks.map((link, i) => (
              <Link key={i} href={link.href} className="group bg-white p-6 rounded-2xl border border-gray-100 hover:border-primary shadow-sm hover:shadow-xl transition-all duration-500 flex flex-col items-center text-center gap-4">
                <div className={`p-3 rounded-xl transition-transform group-hover:scale-110 duration-500 ${link.color}`}>
                  {link.icon}
                </div>
                <span className="font-bold text-sm text-gray-800 group-hover:text-primary transition-colors">{link.title}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Submission Flow Section */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-serif font-black text-primary mb-6">Simple Submission Flow</h2>
            <p className="text-gray-500 text-lg max-w-2xl mx-auto uppercase tracking-widest font-bold text-xs">How it works for Authors</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
            {/* Connecting Line (Desktop) */}
            <div className="hidden lg:block absolute top-[40%] left-0 w-full h-0.5 bg-gray-50 -z-10" />

            {submissionSteps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-lg hover:shadow-2xl transition-all duration-500 text-center flex flex-col items-center group"
              >
                <div className="w-20 h-20 rounded-3xl bg-primary/5 flex items-center justify-center text-primary mb-6 transition-all group-hover:bg-primary group-hover:text-white group-hover:rotate-6 shadow-sm">
                  {step.icon}
                </div>
                <h3 className="text-xl font-bold mb-3 text-gray-900">0{i + 1}. {step.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed font-medium">{step.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <Link href="/submit" className="inline-flex items-center gap-2 text-primary font-black uppercase text-sm group tracking-widest">
              Start Submission Now <ArrowRight className="w-4 h-4 group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      </section>

      {/* Disciplines Section (Redesigned Call for Papers) */}
      <section className="py-24 bg-primary text-white overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none"
          style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <motion.h2
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl font-serif font-black mb-6"
            >
              Call for Papers
            </motion.h2>
            <p className="text-white/70 text-lg italic max-w-3xl mx-auto">
              We invite researchers to contribute their latest findings across a wide range of academic disciplines.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {disciplines.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                whileHover={{ y: -5, backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="p-6 rounded-2xl border border-white/10 text-center transition-all cursor-default"
              >
                <span className="text-xs md:text-sm font-bold tracking-wide uppercase leading-tight block">{item}</span>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-20 text-center"
          >
            <Link href="/submit" className="bg-white text-primary px-12 py-5 rounded-2xl font-black text-lg hover:bg-gray-100 transition-all shadow-xl shadow-black/20 transform hover:scale-105 active:scale-95">
              Submit Your Manuscript
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Indexing Badges */}
      <section className="py-16 bg-white border-b border-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-[10px] font-black uppercase text-gray-400 tracking-[0.3em] mb-12">Indexing & Future Goals</p>
          <div className="flex flex-wrap justify-center gap-12 md:gap-20 opacity-30 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-1000">
            <div className="font-black text-2xl text-gray-900 border-2 border-primary/20 px-4 py-1 rounded italic">GOOGLE SCHOLAR</div>
            <div className="font-black text-2xl text-gray-900 border-2 border-primary/20 px-4 py-1 rounded italic">CROSSREF</div>
            <div className="font-black text-2xl text-gray-900 border-2 border-primary/20 px-4 py-1 rounded italic">ROAD</div>
            <div className="font-black text-2xl text-gray-900 border-2 border-primary/20 px-4 py-1 rounded italic">DOI</div>
          </div>
        </div>
      </section>
    </div>
  );
}
