"use server";
import "server-only"

import { db } from "@/lib/db";
import { settings } from "@/db/schema";
import { type ActionResponse, actionSuccess, actionError } from "@/db/types";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { revalidatePath, updateTag, cacheLife, cacheTag } from "next/cache";
import { uploadFileToStorage } from "@/lib/fs-utils";
function camelCase(str: string): string {
    return str
        .replace(/[-_\s]+(.)?/g, (_, c: string | undefined) => (c ? c.toUpperCase() : ""))
        .replace(/^[A-Z]/, (c) => c.toLowerCase());
}

function kebabCase(str: string): string {
    return str
        .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
        .replace(/([A-Z])([A-Z][a-z])/g, "$1-$2")
        .toLowerCase();
}

const ALLOWED_SETTING_KEYS = new Set([
    'journalName', 'journalShortName', 'issnNumber', 'apcInr', 'apcUsd',
    'supportEmail', 'supportPhone', 'officeAddress', 'publisherName',
    'journalWebsite', 'apcDescription', 'templateUrl', 'copyrightUrl',
    'isPromotionActive', 'publicationFrequency', 'startingYear', 
    'publicationFormat', 'journalLanguage', 'journalSubject', 'udyamRegistration'
]);

const DEFAULT_SETTINGS: Record<string, string> = {
    journalName: 'International Journal of Innovative Trends in Engineering, Science and Technology',
    journalShortName: 'IJITEST',
    issnNumber: 'XXXX-XXXX',
    apcInr: '2500',
    apcUsd: '50',
    supportEmail: 'support@ijitest.org',
    supportPhone: '+91 8919643590',
    officeAddress: 'Dr. Ravibabu T.\nAssociate Professor\nDepartment of Electronics and Communication Engineering\nMES Group of Institutions, Vizianagaram,\nAndhra Pradesh, India - 530048',
    publisherName: 'Felix Academic Publications',
    journalWebsite: 'www.ijitest.org',
    apcDescription: 'APC covers SJIF impact evaluation, long-term hosting, indexing maintenance, and editorial handling. There are no submission or processing charges before acceptance.',
    templateUrl: '/docs/template.docx',
    copyrightUrl: '/docs/copyright-form.docx',
    isPromotionActive: 'true',
    publicationFrequency: 'Monthly (12 Issues per year)',
    startingYear: '2026',
    publicationFormat: 'Online',
    journalLanguage: 'English',
    journalSubject: 'Multidisciplinary (Engineering, Science and Technology, Healthcare, Management Sciences)',
    udyamRegistration: 'UDYAM-AP-10-0125617'
};

export async function getSettings(): Promise<ActionResponse<Record<string, string>>> {
    'use cache'
    cacheLife('hours')
    cacheTag('settings', 'public-data')

    try {
        const rows = await db.select().from(settings);

        const result: Record<string, string> = { ...DEFAULT_SETTINGS };

        rows.forEach((row) => {
            if (row.settingValue) {
                const key = camelCase(row.settingKey);
                if (ALLOWED_SETTING_KEYS.has(key)) {
                    result[key] = row.settingValue;
                }
            }
        });

        return actionSuccess(result);
    } catch (error) {
        console.error("Get Settings Error:", error);
        return actionError(error instanceof Error ? error.message : String(error));
    }
}

/**
 * Utility for Server Components to get raw settings directly.
 */
export async function getSettingsData(): Promise<Record<string, string>> {
    const res = await getSettings();
    return res.data || DEFAULT_SETTINGS;
    
}

export async function updateSettings(formData: FormData): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return actionError("Unauthorized");
        }

        const entries = Array.from(formData.entries());

        // Resolve file uploads outside the transaction first
        const resolvedEntries: Array<[string, string]> = [];
        for (const [key, value] of entries) {
            if (key.startsWith('$')) continue;
            if (!ALLOWED_SETTING_KEYS.has(key)) continue; // whitelist guard

            if (value instanceof File && value.size > 0) {
                const bytes = await value.arrayBuffer();
                const fileExt = value.name.split('.').pop();
                const fileName = `${kebabCase(key)}.${fileExt}`;
                const relativeDocsPath = `docs/${fileName}`;
                await uploadFileToStorage(relativeDocsPath, Buffer.from(bytes), value.name);
                resolvedEntries.push([key, `/api/files/docs/${fileName}`]);
            } else if (value instanceof File && value.size === 0) {
                continue; // skip empty file — preserve existing
            } else {
                resolvedEntries.push([key, String(value ?? "")]);
            }
        }

        await db.transaction(async (tx) => {
            for (const [key, value] of resolvedEntries) {
                // Store as camelCase in DB as requested
                await tx.insert(settings)
                    .values({ settingKey: key, settingValue: value })
                    .onDuplicateKeyUpdate({ set: { settingValue: value } });
            }
        });

        updateTag('settings');           // Immediate cache expiration (Next.js 16)
        revalidatePath('/', 'layout');       // Re-renders root layout + all children
        return actionSuccess();
    } catch (error) {
        console.error("Update Settings Error:", error);
        return actionError("Failed to update settings: " + (error instanceof Error ? error.message : String(error)));
    }
}
