"use server";
import "server-only"

import { db } from "@/lib/db";
import { payments, submissions, submissionVersions, userProfiles, users } from "@/db/schema";
import { eq, desc, and, isNull, sql } from "drizzle-orm";
import { revalidatePath, updateTag } from "next/cache";
import { CACHE_TAGS } from "@/lib/cache-tags";
import { invalidateAuthorActionsCount, createNotification } from "./notifications";
import { type PaymentRow, type UnpaidPaperRow, type PaymentStatus } from "@/db/types";
import { type ActionResponse, serverError, actionSuccess } from "@/lib/action-response";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { generateInvoicePdf } from "@/lib/invoice-generator";
import { sendEmailWithRetry } from "@/lib/mail";



export async function getPayments(): Promise<ActionResponse<PaymentRow[]>> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
            return { success: false, error: "Unauthorized" };
        }

        const latestVersions = db.select({
            submissionId: submissionVersions.submissionId,
            maxVersion: sql<number>`MAX(${submissionVersions.versionNumber})`.as('max_version')
        })
        .from(submissionVersions)
        .groupBy(submissionVersions.submissionId)
        .as('lv');

        const results = await db.select({
            id: payments.id,
            submissionId: payments.submissionId,
            amount: payments.amount,
            currency: payments.currency,
            status: payments.status,
            transactionId: payments.transactionId,
            paidAt: payments.paidAt,
            createdAt: payments.createdAt,
            title: submissionVersions.title,
            paperId: submissions.paperId,
            authorName: userProfiles.fullName,
            authorEmail: users.email
        })
        .from(payments)
        .innerJoin(submissions, eq(payments.submissionId, submissions.id))
        .innerJoin(users, eq(submissions.correspondingAuthorId, users.id))
        .innerJoin(userProfiles, eq(users.id, userProfiles.userId))
        .innerJoin(latestVersions, eq(submissions.id, latestVersions.submissionId))
        .innerJoin(submissionVersions, and(
            eq(submissionVersions.submissionId, submissions.id),
            eq(submissionVersions.versionNumber, latestVersions.maxVersion)
        ))
        .orderBy(desc(payments.createdAt))
        .limit(200);

        return { success: true, data: results as PaymentRow[] };
    } catch (error) {
        console.error("Get Payments Error:", error);
        return serverError(error, "fetch payments");
    }
}

export async function updatePaymentStatus(paymentId: number, status: PaymentStatus, transactionId?: string): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
            return { success: false, error: "Unauthorized" };
        }

        let authorId: string | null = null;
        const invoiceNum = `INV-${new Date().getFullYear()}-${paymentId.toString().padStart(5, '0')}`;
        await db.transaction(async (tx) => {
            await tx.update(payments)
                .set({ 
                    status, 
                    transactionId: transactionId || null, 
                    paidAt: status === 'paid' || status === 'verified' || status === 'waived' ? new Date() : null,
                    invoiceNumber: ['paid', 'verified', 'waived'].includes(status)
                        ? sql`COALESCE(${payments.invoiceNumber}, ${invoiceNum})`
                        : undefined
                })
                .where(eq(payments.id, paymentId));

            // Move submission forward when payment is confirmed
            if (status === 'verified' || status === 'waived') {
                const [payment] = await tx.select({ 
                    submissionId: payments.submissionId,
                    currentStatus: submissions.status,
                    correspondingAuthorId: submissions.correspondingAuthorId
                })
                    .from(payments)
                    .innerJoin(submissions, eq(payments.submissionId, submissions.id))
                    .where(eq(payments.id, paymentId))
                    .limit(1);
                
                if (payment) {
                    authorId = payment.correspondingAuthorId;
                    if (payment.currentStatus !== 'published' && payment.currentStatus !== 'retracted' && payment.currentStatus !== 'rejected') {
                        await tx.update(submissions)
                            .set({ status: 'accepted' })
                            .where(eq(submissions.id, payment.submissionId));
                    }
                }
            }
        });

        if (authorId) {
            await invalidateAuthorActionsCount(authorId);

            if (status === 'verified' || status === 'waived') {
                const payInfo = await db.select({ 
                    paperId: submissions.paperId,
                    submissionId: payments.submissionId
                })
                    .from(payments)
                    .innerJoin(submissions, eq(payments.submissionId, submissions.id))
                    .where(eq(payments.id, paymentId))
                    .limit(1);

                if (payInfo[0]) {
                    await createNotification({
                        userId: authorId,
                        createdByUserId: session.user.id,
                        type: "payment_verified",
                        priority: "high",
                        message: `Payment verified for manuscript ${payInfo[0].paperId}. Your paper has been cleared for publication.`,
                        actionLink: `/author/submissions/${payInfo[0].submissionId}`,
                        metadata: { submissionId: payInfo[0].submissionId, paperId: payInfo[0].paperId }
                    });
                }
            }
        }

        const [payRecord] = await db.select({ submissionId: payments.submissionId })
            .from(payments)
            .where(eq(payments.id, paymentId))
            .limit(1);

        if (payRecord?.submissionId) {
            updateTag(CACHE_TAGS.SUBMISSION(payRecord.submissionId));
        }
        updateTag(CACHE_TAGS.SUBMISSIONS);
        revalidatePath('/admin/payments');
        revalidatePath('/admin/submissions');
        return { success: true };
    } catch (error) {
        console.error("Update Payment Error:", error);
        return serverError(error, "update payment");
    }
}

export async function initializePayment(submissionId: number, amount: number, currency: string = 'INR'): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
            return { success: false, error: "Unauthorized" };
        }

        await db.insert(payments).values({
            submissionId,
            amount: amount.toString(),
            currency,
            status: 'pending'
        });

        // Trigger payment_pending notification
        const [sub] = await db.select({ correspondingAuthorId: submissions.correspondingAuthorId, paperId: submissions.paperId })
            .from(submissions)
            .where(eq(submissions.id, submissionId))
            .limit(1);

        if (sub) {
            await createNotification({
                userId: sub.correspondingAuthorId,
                createdByUserId: session.user.id,
                type: "payment_pending",
                priority: "high",
                message: `Publication fee payment of ${amount} ${currency} is pending for manuscript ${sub.paperId}.`,
                actionLink: `/author/submissions/${submissionId}`,
                metadata: { submissionId, paperId: sub.paperId }
            });
            await invalidateAuthorActionsCount(sub.correspondingAuthorId);
        }

        updateTag(CACHE_TAGS.SUBMISSION(submissionId));
        updateTag(CACHE_TAGS.SUBMISSIONS);
        revalidatePath('/admin/payments');
        revalidatePath(`/admin/submissions/${submissionId}`);
        return { success: true };
    } catch (error) {
        console.error("Initialize Payment Error:", error);
        return serverError(error, "initialize payment");
    }
}



export async function getAcceptedUnpaidPapers(): Promise<ActionResponse<UnpaidPaperRow[]>> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
            return { success: false, error: "Unauthorized" };
        }

        const latestVersions = db.select({
            submissionId: submissionVersions.submissionId,
            maxVersion: sql<number>`MAX(${submissionVersions.versionNumber})`.as('max_version')
        })
        .from(submissionVersions)
        .groupBy(submissionVersions.submissionId)
        .as('lv');

        // Find submissions that are 'accepted' but have no entry in 'payments'
        const results = await db.select({
            id: submissions.id,
            paperId: submissions.paperId,
            title: submissionVersions.title,
            authorName: userProfiles.fullName
        })
        .from(submissions)
        .innerJoin(users, eq(submissions.correspondingAuthorId, users.id))
        .innerJoin(userProfiles, eq(users.id, userProfiles.userId))
        .innerJoin(latestVersions, eq(submissions.id, latestVersions.submissionId))
        .innerJoin(submissionVersions, and(
            eq(submissionVersions.submissionId, submissions.id),
            eq(submissionVersions.versionNumber, latestVersions.maxVersion)
        ))
        .leftJoin(payments, eq(submissions.id, payments.submissionId))
        .where(and(
            eq(submissions.status, 'accepted'),
            isNull(payments.id)
        ));

        return { success: true, data: results };
    } catch (error) {
        console.error("Get Accepted Unpaid Error:", error);
        return serverError(error, "fetch unpaid papers");
    }
}

export async function waivePayment(submissionId: number): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return { success: false, error: "Unauthorized" };
        }

        let authorId: string | null = null;
        await db.transaction(async (tx) => {
            const [sub] = await tx.select({ correspondingAuthorId: submissions.correspondingAuthorId })
                .from(submissions)
                .where(eq(submissions.id, submissionId))
                .limit(1);
            if (sub) {
                authorId = sub.correspondingAuthorId;
            }

            await tx.update(payments)
                .set({ status: 'waived', paidAt: new Date() })
                .where(eq(payments.submissionId, submissionId));
            
            // Waived payment — submission is cleared to proceed
            await tx.update(submissions)
                .set({ status: 'accepted' })
                .where(eq(submissions.id, submissionId));
        });

        if (authorId) {
            await invalidateAuthorActionsCount(authorId);

            const [sub] = await db.select({ paperId: submissions.paperId })
                .from(submissions)
                .where(eq(submissions.id, submissionId))
                .limit(1);

            if (sub) {
                await createNotification({
                    userId: authorId,
                    createdByUserId: session.user.id,
                    type: "payment_verified",
                    priority: "high",
                    message: `Payment waived for manuscript ${sub.paperId}. Your paper has been cleared for publication.`,
                    actionLink: `/author/submissions/${submissionId}`,
                    metadata: { submissionId, paperId: sub.paperId }
                });
            }
        }
        if (submissionId) {
            updateTag(CACHE_TAGS.SUBMISSION(submissionId));
        }
        updateTag(CACHE_TAGS.SUBMISSIONS);
        revalidatePath('/admin/submissions');
        revalidatePath(`/admin/submissions/${submissionId}`);
        revalidatePath('/admin/payments');
        return { success: true };
    } catch (error) {
        console.error("Waive Payment Error:", error);
        return serverError(error, "waive payment");
    }
}

export async function sendReceiptEmail(paymentId: number): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user) {
            return { success: false, error: "Unauthorized" };
        }

        // Fetch payment + submission + author data (same joins as the old API route)
        const rows = await db.select({
            payment: payments,
            submission: submissions,
            authorProfile: userProfiles,
            authorUser: users,
        })
        .from(payments)
        .innerJoin(submissions, eq(payments.submissionId, submissions.id))
        .innerJoin(users, eq(submissions.correspondingAuthorId, users.id))
        .leftJoin(userProfiles, eq(users.id, userProfiles.userId))
        .where(eq(payments.id, paymentId))
        .limit(1);

        const row = rows[0];
        if (!row?.payment) {
            return { success: false, error: "Invoice not found" };
        }

        // Authorization: must be admin, editor, or the corresponding author
        const isAuthorized =
            session.user.role === "admin" ||
            session.user.role === "editor" ||
            session.user.id === row.submission.correspondingAuthorId;

        if (!isAuthorized) {
            return { success: false, error: "Unauthorized to access this receipt" };
        }

        // Only send for paid/verified/waived payments
        if (!["paid", "verified", "waived"].includes(row.payment.status)) {
            return { success: false, error: "Receipt is only available for completed payments" };
        }

        // Fetch the latest version title
        const versionRows = await db
            .select({ title: submissionVersions.title })
            .from(submissionVersions)
            .where(eq(submissionVersions.submissionId, row.submission.id))
            .orderBy(desc(submissionVersions.versionNumber))
            .limit(1);

        const paperTitle = versionRows[0]?.title || "Research Manuscript";
        const invoiceNumber =
            row.payment.invoiceNumber ||
            `INV-${new Date(row.payment.paidAt || row.payment.createdAt || new Date()).getFullYear()}-${String(row.payment.id).padStart(4, "0")}`;

        // Generate the PDF
        const pdfBytes = await generateInvoicePdf({
            invoiceNumber,
            date: row.payment.paidAt || row.payment.createdAt || new Date(),
            paperId: row.submission.paperId,
            paperTitle,
            authorName: row.authorProfile?.fullName || row.authorUser.email,
            authorEmail: row.authorUser.email,
            authorInstitution: row.authorProfile?.institute || undefined,
            amount: row.payment.amount,
            currency: row.payment.currency || "INR",
            transactionId: row.payment.transactionId,
            paymentMethod: row.payment.provider
                ? `${row.payment.provider} Gateway`
                : "Razorpay Secure Gateway",
        });

        // Email the PDF to the author
        await sendEmailWithRetry(
            {
                to: row.authorUser.email,
                subject: `Tax Invoice & APC Receipt — ${row.submission.paperId}`,
                html: `<p>Dear ${row.authorProfile?.fullName || "Author"},</p>
<p>Please find attached your official Tax Invoice and Article Processing Charge (APC) receipt for manuscript <strong>${row.submission.paperId}</strong>.</p>
<p>Invoice No: <strong>${invoiceNumber}</strong></p>
<p>If you have any questions, please contact us at <a href="mailto:support@ijitest.org">support@ijitest.org</a>.</p>
<p>Best regards,<br/>IJITEST Editorial Office</p>`,
                attachments: [
                    {
                        filename: `APC_Receipt_${row.submission.paperId}.pdf`,
                        content: Buffer.from(pdfBytes),
                        contentType: "application/pdf",
                    },
                ],
            },
            `receipt-email-payment-${paymentId}`
        );

        return actionSuccess(undefined, "Receipt emailed successfully");
    } catch (error) {
        return serverError(error, "send receipt email");
    }
}
