"use server";

import { db } from "@/lib/db";
import {
    publications,
    submissions,
    submissionAuthors,
    submissionVersions,
    volumesIssues,
    userProfiles
} from "@/db/schema";
import { eq, desc, and, sql, ne, inArray, asc } from "drizzle-orm";
import { 
    type PublishedPaperUI, 
    type ActionResponse, 
    type SubmissionStatus, 
    type Author,
    actionSuccess,
    actionError
} from "@/db/types";
import { unstable_cache } from "next/cache";

/**
 * FETCH ALL PUBLISHED PAPERS
 * Used for the global archive list or sitemap
 */
export async function getPublishedPapers(): Promise<ActionResponse<PublishedPaperUI[]>> {
    return unstable_cache(
        async () => {
            try {
                const rows = await db.select({
                    publication: publications,
                    submission: submissions,
                    issue: volumesIssues,
                })
                    .from(publications)
                    .leftJoin(submissions, eq(publications.submissionId, submissions.id))
                    .leftJoin(volumesIssues, eq(publications.issueId, volumesIssues.id))
                    .orderBy(asc(submissions.paperId));

                if (!rows.length) return actionSuccess([] as PublishedPaperUI[]);

                const submissionIds = rows.map(r => r.submission?.id).filter(Boolean) as number[];

                // Fetch Authors and Versions separately to avoid complex joins and combinatorics
                const authorsList = await db.select().from(submissionAuthors)
                    .where(inArray(submissionAuthors.submissionId, submissionIds))
                    .orderBy(submissionAuthors.orderIndex);

                const versionsList = await db.select().from(submissionVersions)
                    .where(inArray(submissionVersions.submissionId, submissionIds))
                    .orderBy(desc(submissionVersions.versionNumber));

                const data = rows.map(row => {
                    const paperAuthors = authorsList.filter(a => a.submissionId === row.submission?.id);
                    const paperVersions = versionsList.filter(v => v.submissionId === row.submission?.id);

                    return mapPublicationToUI({
                        ...row.publication,
                        submission: {
                            ...row.submission,
                            versions: paperVersions,
                            authors: paperAuthors
                        },
                        issue: row.issue
                    });
                });

                return actionSuccess(data);
            } catch (error) {
                console.error("Get Published Papers Error:", error);
                return actionError<PublishedPaperUI[]>(error instanceof Error ? error.message : String(error));
            }
        },
        ['published-papers-all'],
        { tags: ['archives', 'public-data'], revalidate: 3600 }
    )();
}

export async function getLatestIssuePapers(): Promise<ActionResponse<PublishedPaperUI[]>> {
    return unstable_cache(
        async () => {
            try {
                const issues = await db.select()
                    .from(volumesIssues)
                    .where(eq(volumesIssues.status, 'published'))
                    .orderBy(desc(volumesIssues.year), desc(volumesIssues.volumeNumber), desc(volumesIssues.issueNumber))
                    .limit(1);

                if (!issues.length) return actionSuccess([] as PublishedPaperUI[]);
                const latestIssue = issues[0];
                if (!latestIssue) return actionSuccess([] as PublishedPaperUI[]);

                const rows = await db.select({
                    publication: publications,
                    submission: submissions,
                    issue: volumesIssues,
                })
                    .from(publications)
                    .where(eq(publications.issueId, latestIssue.id))
                    .leftJoin(submissions, eq(publications.submissionId, submissions.id))
                    .leftJoin(volumesIssues, eq(publications.issueId, volumesIssues.id))
                    .orderBy(asc(submissions.paperId));

                if (!rows.length) return actionSuccess([] as PublishedPaperUI[]);

                const submissionIds = rows.map(r => r.submission?.id).filter(Boolean) as number[];

                const authorsList = await db.select().from(submissionAuthors)
                    .where(inArray(submissionAuthors.submissionId, submissionIds))
                    .orderBy(submissionAuthors.orderIndex);

                const versionsList = await db.select().from(submissionVersions)
                    .where(inArray(submissionVersions.submissionId, submissionIds))
                    .orderBy(desc(submissionVersions.versionNumber));

                const data = rows.map(row => {
                    const paperAuthors = authorsList.filter(a => a.submissionId === row.submission?.id);
                    const paperVersions = versionsList.filter(v => v.submissionId === row.submission?.id);

                    return mapPublicationToUI({
                        ...row.publication,
                        submission: {
                            ...row.submission,
                            versions: paperVersions,
                            authors: paperAuthors
                        },
                        issue: row.issue
                    });
                });

                return actionSuccess(data);
            } catch (error) {
                console.error("Get Latest Issue Papers Error:", error);
                return actionError<PublishedPaperUI[]>(error instanceof Error ? error.message : String(error));
            }
        },
        ['latest-issue-papers'],
        { tags: ['archives', 'latest-issue', 'public-data'], revalidate: 3600 }
    )();
}

export async function getArchivePapers(limit = 50, offset = 0): Promise<ActionResponse<PublishedPaperUI[]>> {
    return unstable_cache(
        async () => {
            try {
                const issues = await db.select()
                    .from(volumesIssues)
                    .where(eq(volumesIssues.status, 'published'))
                    .orderBy(desc(volumesIssues.year), desc(volumesIssues.volumeNumber), desc(volumesIssues.issueNumber))
                    .limit(1);

                const latestId = issues[0]?.id ?? -1;

                const rows = await db.select({
                    publication: publications,
                    submission: submissions,
                    issue: volumesIssues,
                })
                    .from(publications)
                    .where(ne(publications.issueId, latestId))
                    .leftJoin(submissions, eq(publications.submissionId, submissions.id))
                    .leftJoin(volumesIssues, eq(publications.issueId, volumesIssues.id))
                    .orderBy(asc(submissions.paperId))
                    .limit(limit)
                    .offset(offset);

                if (!rows.length) return actionSuccess([] as PublishedPaperUI[]);

                const submissionIds = rows.map(r => r.submission?.id).filter(Boolean) as number[];

                const authorsList = await db.select().from(submissionAuthors)
                    .where(inArray(submissionAuthors.submissionId, submissionIds))
                    .orderBy(submissionAuthors.orderIndex);

                const versionsList = await db.select().from(submissionVersions)
                    .where(inArray(submissionVersions.submissionId, submissionIds))
                    .orderBy(desc(submissionVersions.versionNumber));

                const data = rows.map(row => {
                    const paperAuthors = authorsList.filter(a => a.submissionId === row.submission?.id);
                    const paperVersions = versionsList.filter(v => v.submissionId === row.submission?.id);

                    return mapPublicationToUI({
                        ...row.publication,
                        submission: {
                            ...row.submission,
                            versions: paperVersions,
                            authors: paperAuthors
                        },
                        issue: row.issue
                    });
                });

                return actionSuccess(data);
            } catch (error) {
                console.error("Get Archive Papers Error:", error);
                return actionError<PublishedPaperUI[]>(error instanceof Error ? error.message : String(error));
            }
        },
        [`archive-papers-${limit}-${offset}`],
        { tags: ['archives', 'public-data'], revalidate: 3600 }
    )();
}

export async function getPaperById(id: string): Promise<ActionResponse<PublishedPaperUI>> {
    return unstable_cache(
        async () => {
            try {
                const numericId = Number(id);
                const whereClause = isNaN(numericId)
                    ? eq(submissions.paperId, id)
                    : eq(publications.submissionId, numericId);

                const latestVersions = db.select({
                    submissionId: submissionVersions.submissionId,
                    maxVersion: sql<number>`MAX(${submissionVersions.versionNumber})`.as('max_version')
                })
                    .from(submissionVersions)
                    .groupBy(submissionVersions.submissionId)
                    .as('lv');

                const rows = await db.select({
                    publication: publications,
                    submission: submissions,
                    version: submissionVersions,
                    issue: volumesIssues,
                    authorProfile: userProfiles
                })
                    .from(publications)
                    .where(whereClause)
                    .leftJoin(submissions, eq(publications.submissionId, submissions.id))
                    .leftJoin(latestVersions, eq(submissions.id, latestVersions.submissionId))
                    .leftJoin(submissionVersions, and(
                        eq(submissions.id, submissionVersions.submissionId),
                        eq(submissionVersions.versionNumber, latestVersions.maxVersion)
                    ))
                    .leftJoin(volumesIssues, eq(publications.issueId, volumesIssues.id))
                    .leftJoin(userProfiles, eq(submissions.correspondingAuthorId, userProfiles.userId))
                    .limit(1);

                const row = rows[0];
                if (!row || !row.submission) return actionError<PublishedPaperUI>("Paper data is incomplete");

                // SECOND QUERY: Fetch all authors separately for the detail view
                const authorsList = await db.select()
                    .from(submissionAuthors)
                    .where(eq(submissionAuthors.submissionId, row.submission.id))
                    .orderBy(submissionAuthors.orderIndex);

                const data = mapPublicationToUI({
                    ...row.publication,
                    submission: {
                        ...row.submission,
                        versions: [row.version],
                        correspondingAuthor: { profile: row.authorProfile },
                        authors: authorsList
                    },
                    issue: row.issue
                });
                return actionSuccess(data);
            } catch (error) {
                console.error("Get Paper By ID Error:", error);
                return actionError<PublishedPaperUI>(error instanceof Error ? error.message : String(error));
            }
        },
        [`paper-${id}`],
        { tags: [`paper-${id}`, 'public-data'], revalidate: 3600 }
    )();
}

/**
 * HELPER: Map relational Drizzle structure to the flat structure the UI expects
 */
interface SubmissionAuthor {
    id: number;
    submissionId: number;
    name: string;
    email: string;
    phone: string | null;
    designation: string | null;
    institution: string | null;
    isCorresponding: boolean;
    orderIndex: number;
}

interface PublicationInput {
    submissionId?: number | null;
    doi?: string | null;
    finalPdfUrl?: string | null;
    startPage?: number | null;
    endPage?: number | null;
    publishedAt?: Date | null;
    views?: number | null;
    downloads?: number | null;
    citations?: number | null;
    submission?: {
        paperId?: string | null;
        status?: string | null;
        updatedAt?: Date | null;
        authors?: SubmissionAuthor[];
        versions?: Array<{ title?: string | null; abstract?: string | null; keywords?: string | null } | null>;
        correspondingAuthor?: {
            profile?: {
                fullName?: string | null,
                institute?: string | null
            } | null
        } | null;
    } | null;
    issue?: {
        volumeNumber?: number | null;
        issueNumber?: number | null;
        year?: number | null;
        monthRange?: string | null;
    } | null;
}

function mapPublicationToUI(pub: PublicationInput): PublishedPaperUI {
    const latestVersion = pub.submission?.versions?.[0];
    const authorsList = Array.isArray(pub.submission?.authors) ? pub.submission.authors : [];

    // Sort authors by orderIndex
    const sortedAuthors = [...authorsList].sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0)) as Author[];

    // Primary author is the one with isCorresponding or the first one
    const correspondingAuthor = sortedAuthors.find(a => a.isCorresponding) || sortedAuthors[0];

    // Combine all names for the display authorName field
    const allAuthorsString = sortedAuthors.map(a => a.name).join(', ');

    return {
        id: pub.submissionId || 0,
        paperId: pub.submission?.paperId || "",
        title: latestVersion?.title || "Untitled Paper",
        abstract: latestVersion?.abstract || "",
        keywords: (() => {
            const raw = latestVersion?.keywords || "";
            try {
                if (raw.startsWith('[') && raw.endsWith(']')) {
                    const parsed = JSON.parse(raw);
                    if (Array.isArray(parsed)) return parsed.join(', ');
                }
            } catch (e) {}
            return raw;
        })(),
        authorName: allAuthorsString || "Anonymous Author",
        authorEmail: correspondingAuthor?.email || "N/A",
        affiliation: correspondingAuthor?.institution || "N/A",
        status: (pub.submission?.status as SubmissionStatus) || "published",
        doi: pub.doi || "",
        finalPdfUrl: pub.finalPdfUrl || "",
        filePath: pub.finalPdfUrl || "",
        pdfUrl: pub.finalPdfUrl || "",
        startPage: pub.startPage || null,
        endPage: pub.endPage || null,
        pageRange: pub.startPage && pub.endPage ? `${pub.startPage}-${pub.endPage}` : null,
        publishedAt: pub.publishedAt || null,
        updatedAt: pub.submission?.updatedAt || pub.publishedAt || null,
        volumeNumber: pub.issue?.volumeNumber || 0,
        issueNumber: pub.issue?.issueNumber || 0,
        publicationYear: pub.issue?.year || 0,
        monthRange: pub.issue?.monthRange || "",
        coAuthors: sortedAuthors, 
        authorsList: sortedAuthors.map(a => a.name),
        views: pub.views || 0,
        downloads: pub.downloads || 0,
        citations: pub.citations || 0
    };
}
