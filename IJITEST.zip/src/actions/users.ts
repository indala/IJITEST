"use server";
import "server-only"

import { db } from "@/lib/db";
import {
    users,
    userProfiles,
    userInvitations,
    reviewAssignments,
    submissionEditors,
    reviews,
} from "@/db/schema";
import {
    type UserWithProfile,
    type SafeUserWithProfile,
} from "@/db/types";
import {
    type ActionResponse,
    actionSuccess,
    actionError,
    serverError,
} from "@/lib/action-response";
import { eq, and, sql, inArray, isNotNull, not } from "drizzle-orm";
import { revalidatePath, updateTag, cacheLife, cacheTag } from "next/cache";
import { CACHE_TAGS } from "@/lib/cache-tags";
import { safeInvalidateTag, invalidateReviewerAssignmentsCount, invalidateAuthorActionsCount } from "./notifications";
import { safeDeleteFile, uploadFileToStorage } from "@/lib/fs-utils";
import crypto from 'crypto';
import { emailTemplates, sendEmail, sendEmailWithRetry } from '@/lib/mail';
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { hash } from "bcryptjs";

export async function getEditorialBoard(): Promise<ActionResponse<SafeUserWithProfile[]>> {
    'use cache'
    cacheLife('days')
    cacheTag(CACHE_TAGS.EDITORIAL_BOARD)

    try {
        const rows = await db.select({
            user: {
                id: users.id,
                email: users.email,
                role: users.role,
                isActive: users.isActive,
                isEmailVerified: users.isEmailVerified,
                emailVerifiedAt: users.emailVerifiedAt,
                hasSeenPromotion: users.hasSeenPromotion,
                createdAt: users.createdAt,
                updatedAt: users.updatedAt,
                deletedAt: users.deletedAt,
                lastActiveAt: users.lastActiveAt,
            },
            profile: userProfiles,
        })
            .from(users)
            .innerJoin(userProfiles, eq(users.id, userProfiles.userId))
            .where(
                and(
                    inArray(users.role, ["admin", "editor", "reviewer"]),
                    isNotNull(users.passwordHash),
                    eq(users.isActive, true)
                )
            )
            .orderBy(users.role, userProfiles.fullName);

        const data: SafeUserWithProfile[] = rows.map(r => ({
            ...r.user,
            profile: r.profile
        }));
        return { success: true, data };
    } catch (error) {
        console.error("Get Editorial Board Error:", error);
        return serverError(error, "fetch editorial board");
    }
}

export async function getUsers(role?: "admin" | "editor" | "reviewer" | "author"): Promise<ActionResponse<SafeUserWithProfile[]>> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return { success: false, error: "Unauthorized" };
        }

        const whereClause = role ? eq(users.role, role) : not(eq(users.role, 'author'));

        const rows = await db.select({
            user: {
                id: users.id,
                email: users.email,
                role: users.role,
                isActive: users.isActive,
                isEmailVerified: users.isEmailVerified,
                emailVerifiedAt: users.emailVerifiedAt,
                hasSeenPromotion: users.hasSeenPromotion,
                createdAt: users.createdAt,
                updatedAt: users.updatedAt,
                deletedAt: users.deletedAt,
                lastActiveAt: users.lastActiveAt,
            },
            profile: userProfiles,
        })
            .from(users)
            .leftJoin(userProfiles, eq(users.id, userProfiles.userId))
            .where(whereClause)
            .limit(500);
        const data: SafeUserWithProfile[] = rows.map(r => ({
            ...r.user,
            profile: r.profile
        }));
        return { success: true, data };
    } catch (error) {
        console.error("Get Users Error:", error);
        return serverError(error, "fetch users");
    }
}



export async function createUser(formData: FormData): Promise<ActionResponse> {
    const session = await getServerSession(authOptions);
    if (!session?.user || session.user.role !== 'admin') {
        return { success: false, error: "Unauthorized" };
    }

    const email = formData.get('email') as string;
    const fullName = formData.get('fullName') as string;
    const role = formData.get('role') as "admin" | "editor" | "reviewer" | "author";

    try {
        const invitationToken = crypto.randomBytes(32).toString('hex');
        const expires = new Date();
        expires.setHours(expires.getHours() + 168); // 7-day window for account setup

        const userId = crypto.randomUUID();

        await db.transaction(async (tx) => {
            await tx.insert(users).values({
                id: userId,
                email,
                role,
            });

            await tx.insert(userProfiles).values({
                userId,
                fullName,
            });

            // All roles except admin can receive setup invitations
            if (role !== 'admin') {
                await tx.insert(userInvitations).values({
                    email,
                    role: role as "editor" | "reviewer" | "author",
                    token: invitationToken,
                    expiresAt: expires,
                });
            }
        });

        // Only send setup email for non-admin roles (admin has no invitation row)
        if (role !== 'admin') {
            const setupUrl = `${process.env['NEXT_PUBLIC_APP_URL'] || 'http://localhost:3000'}/auth/setup-password?token=${invitationToken}`;
            const template = await emailTemplates.boardInvitation(fullName, role, setupUrl);
            sendEmail({ to: email, subject: template.subject, html: template.html })
                .catch(e => console.error("Invitation email failed:", e));
        }

        updateTag(CACHE_TAGS.EDITORIAL_BOARD);
        revalidatePath('/admin/users');
        revalidatePath('/editorial-board');
        return { success: true };
    } catch (error) {
        console.error("Create User Error:", error);
        if (typeof error === 'object' && error !== null && 'code' in error && error.code === 'ER_DUP_ENTRY') {
            return { success: false, error: "Email already exists" };
        }
        return serverError(error, "create user");
    }
}

export async function getPasswordSetupInfo(token: string): Promise<ActionResponse<{ email: string, role: string, fullName: string }>> {
    try {
        const invitation = await db.select({
            email: userInvitations.email,
            role: userInvitations.role,
            fullName: userProfiles.fullName,
        })
            .from(userInvitations)
            .innerJoin(users, eq(userInvitations.email, users.email))
            .innerJoin(userProfiles, eq(users.id, userProfiles.userId))
            .where(
                and(
                    eq(userInvitations.token, token),
                    sql`${userInvitations.expiresAt} > ${new Date()}`
                )
            )
            .limit(1);

        if (!invitation[0]) return { success: false, error: "Link expired or invalid" };
        return { success: true, data: invitation[0] };
    } catch (error) {
        console.error("Get Setup Info Error:", error);
        return serverError(error, "fetch setup info");
    }
}

export async function setupPassword(formData: FormData): Promise<ActionResponse> {
    const token = formData.get('token') as string;
    const password = formData.get('password') as string;

    try {
        const passwordHash = await hash(password, 10);

        const result = await db.transaction(async (tx) => {
            const invitation = await tx.select()
                .from(userInvitations)
                .where(
                    and(
                        eq(userInvitations.token, token),
                        sql`${userInvitations.expiresAt} > ${new Date()}`
                    )
                )
                .limit(1);

            if (!invitation[0]) {
                return { success: false as const, error: "Link expired or invalid" };
            }

            await tx.update(users)
                .set({ passwordHash, isEmailVerified: true, emailVerifiedAt: new Date() })
                .where(eq(users.email, invitation[0].email));

            await tx.delete(userInvitations)
                .where(eq(userInvitations.token, token));

            return { success: true as const };
        });

        if (!result.success) {
            return actionError(result.error);
        }

        updateTag(CACHE_TAGS.EDITORIAL_BOARD);
        revalidatePath('/editorial-board');
        revalidatePath('/admin/users');

        return actionSuccess();
    } catch (error) {
        console.error("Setup Password Error:", error);
        return serverError(error, "setup password");
    }
}



export async function requestPasswordReset(formData: FormData): Promise<ActionResponse> {
    const email = formData.get('email') as string;

    try {
        const userResult = await db.select({
            id: users.id,
            role: users.role,
            fullName: userProfiles.fullName,
        })
            .from(users)
            .innerJoin(userProfiles, eq(users.id, userProfiles.userId))
            .where(eq(users.email, email))
            .limit(1);

        const user = userResult[0];
        if (!user) {
            return { success: true }; // Security: don't reveal if user exists
        }

        const resetToken = crypto.randomBytes(32).toString('hex');
        const expires = new Date();
        expires.setHours(expires.getHours() + 1);

        // Wrap delete + insert in a transaction to prevent token loss on insert failure.
        // Only delete tokens that match the reset context (expiresAt <= 1 hour from now)
        // to avoid nuking pending account-setup invitations (which have 7-day expiry).
        const oneHourFromNow = new Date(Date.now() + 60 * 60 * 1000 + 5000); // 1hr + 5s buffer
        await db.transaction(async (tx) => {
            await tx.delete(userInvitations).where(
                and(
                    eq(userInvitations.email, email),
                    sql`${userInvitations.expiresAt} <= ${oneHourFromNow}`
                )
            );

            await tx.insert(userInvitations).values({
                email,
                // INTENTIONAL WORKAROUND: The `userInvitations.role` mysqlEnum constraint does not allow 'admin'.
                // Since this is a password reset token, the role stored here is ignored during setupPassword
                // (it only uses the email to update the existing user). We map 'admin' to 'reviewer' purely
                // to satisfy the schema constraint without needing to alter the schema or create a separate table.
                role: (user.role === 'admin' ? 'reviewer' : user.role) as "editor" | "reviewer" | "author",
                token: resetToken,
                expiresAt: expires,
            });
        });

        const resetUrl = `${process.env['NEXT_PUBLIC_APP_URL'] || 'http://localhost:3000'}/auth/setup-password?token=${resetToken}&ctx=reset`;

        const template = await emailTemplates.passwordReset(user.fullName, resetUrl);
        sendEmailWithRetry({
            to: email,
            subject: template.subject,
            html: template.html
        }, "password reset");

        return { success: true };
    } catch (error) {
        console.error("Reset Request Error:", error);
        return { success: false, error: "Failed to process reset request" };
    }
}

export async function updateUserRole(userId: string, role: "admin" | "editor" | "reviewer" | "author"): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session || session.user.role !== 'admin') {
            return { success: false, error: "Unauthorized: Admin access required." };
        }

        // Prevent self-demotion or role change to protect administrative access
        if (session.user.id === userId) {
            return { success: false, error: "You cannot change your own role while active." };
        }

        await db.update(users)
            .set({ role })
            .where(eq(users.id, userId));

        updateTag(CACHE_TAGS.EDITORIAL_BOARD);
        revalidatePath('/admin/users');
        revalidatePath('/editorial-board');
        return { success: true };
    } catch (error) {
        console.error("Update User Role Error:", error);
        return { success: false, error: "Failed to update role" };
    }
}

export async function deleteUser(id: string): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);

        if (!session) {
            return { success: false, error: "Unauthorized" };
        }

        if (session.user.id === id) {
            return { success: false, error: "You cannot delete your own account while logged in." };
        }

        if (!['admin', 'editor'].includes(session.user.role)) {
            return { success: false, error: "Only admins and editors can remove staff." };
        }

        const targetUserRows = await db.select({ role: users.role })
            .from(users)
            .where(eq(users.id, id))
            .limit(1);
        const targetUser = targetUserRows[0];

        if (!targetUser) {
            return { success: false, error: "User not found." };
        }

        if (targetUser.role === 'admin' && session.user.role !== 'admin') {
            return { success: false, error: "Unauthorized: Editors cannot delete Admin accounts." };
        }

        await db.transaction(async (tx) => {
            const profile = await tx.select({ photoUrl: userProfiles.photoUrl })
                .from(userProfiles)
                .where(eq(userProfiles.userId, id))
                .limit(1);

            // 1. Remove reviewer assignments (reviews cascade from assignments)
            //    Get assignment IDs first so we can delete reviews that reference them
            const assignmentIds = await tx
                .select({ id: reviewAssignments.id })
                .from(reviewAssignments)
                .where(eq(reviewAssignments.reviewerId, id));

            if (assignmentIds.length > 0) {
                const ids = assignmentIds.map(a => a.id);
                await tx.delete(reviews).where(inArray(reviews.assignmentId, ids));
                await tx.delete(reviewAssignments).where(eq(reviewAssignments.reviewerId, id));
            }

            // Also clean up any assignments where this user was the assigner
            await tx.delete(reviewAssignments).where(eq(reviewAssignments.assignedBy, id));

            // 2. Remove editor assignments to submissions
            await tx.delete(submissionEditors).where(eq(submissionEditors.editorId, id));

            // 3. Delete user profile + user (cascade handles userProfiles, notifications, activityLogs)
            await tx.delete(users).where(eq(users.id, id));

            if (profile[0]?.photoUrl) {
                await safeDeleteFile(profile[0].photoUrl);
            }
        });

        await invalidateReviewerAssignmentsCount(id);
        await invalidateAuthorActionsCount(id);
        await safeInvalidateTag(CACHE_TAGS.USER_NOTIFICATIONS(id));
        await safeInvalidateTag(CACHE_TAGS.USER_NOTIFICATIONS_UNREAD_COUNT(id));
        await safeInvalidateTag(CACHE_TAGS.EDITORIAL_BOARD);

        revalidatePath('/admin/users');
        revalidatePath('/editorial-board');
        return { success: true };
    } catch (error) {
        console.error("Delete User Error:", error);
        return { success: false, error: "Failed to delete user" };
    }
}



export async function getUserProfile(): Promise<ActionResponse<UserWithProfile>> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user) return { success: false, error: "Unauthorized" };

        const result = await db.select({
            user: users,
            profile: userProfiles,
        })
            .from(users)
            .innerJoin(userProfiles, eq(users.id, userProfiles.userId))
            .where(eq(users.id, session.user.id))
            .limit(1);

        if (!result[0]) return { success: false, error: "User not found" };

        const data: UserWithProfile = {
            ...result[0].user,
            profile: result[0].profile
        };
        return { success: true, data };
    } catch (error) {
        console.error("Get User Profile Error:", error);
        return serverError(error, "fetch user profile");
    }
}

export async function updateUserProfile(formData: FormData): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user) {
            return { success: false, error: "Unauthorized" };
        }

        const fullName = formData.get('fullName') as string;
        const designation = formData.get('designation') as string;
        const institute = formData.get('institute') as string;
        const phone = formData.get('phone') as string;
        const bio = formData.get('bio') as string;
        const nationality = formData.get('nationality') as string;
        const photo = formData.get('photo') as File;

        let photoUrl = formData.get('existingPhotoUrl') as string;
        let oldPhotoUrl: string | null = null;

        if (photo && photo.size > 0) {
            const fileName = `${session.user.id}-${Date.now()}-${photo.name.replace(/\s/g, '-')}`;
            const relativePhotoPath = `profiles/${fileName}`;
            const photoBuffer = Buffer.from(await photo.arrayBuffer());
            await uploadFileToStorage(relativePhotoPath, photoBuffer, photo.name);

            if (photoUrl) {
                oldPhotoUrl = photoUrl;
            }
            photoUrl = `/api/files/profiles/${fileName}`;
        }

        await db.update(userProfiles)
            .set({
                fullName,
                designation,
                institute,
                phone,
                bio,
                photoUrl,
                nationality,
            })
            .where(eq(userProfiles.userId, session.user.id));

        if (oldPhotoUrl) {
            await safeDeleteFile(oldPhotoUrl);
        }

        updateTag(CACHE_TAGS.EDITORIAL_BOARD);
        revalidatePath(`/${session.user.role}/profile`);
        revalidatePath('/editorial-board');
        return { success: true };
    } catch (error) {
        console.error("Update User Profile Error:", error);
        return serverError(error, "update user profile");
    }
}

export async function checkUserEmail(email: string): Promise<{ exists: boolean; error?: string }> {
    try {
        const result = await db.select({ id: users.id })
            .from(users)
            .where(eq(users.email, email))
            .limit(1);

        return { exists: result.length > 0 };
    } catch (error) {
        console.error("Check User Email Error:", error);
        return { error: "Check failed", exists: false };
    }
}

export async function updateUserLastActive(): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.id) {
            return { success: false, error: "Unauthorized" };
        }

        await db.update(users)
            .set({ lastActiveAt: new Date() })
            .where(eq(users.id, session.user.id));

        return { success: true };
    } catch (error) {
        console.error("Update User Last Active Error:", error);
        return { success: false, error: "Failed to update last active timestamp" };
    }
}
