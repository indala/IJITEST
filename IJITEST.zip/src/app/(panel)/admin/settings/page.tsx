"use client";

export const dynamic = "force-dynamic";

import { 
    Save, 
    Globe, 
    FileText, 
    Upload, 
    Shield, 
    CreditCard, 
    Headphones, 
    Sparkles, 
    Layout, 
    ExternalLink,
    Loader2,
    CheckCircle2
} from 'lucide-react';
import { cn } from "@/lib/utils";
import { useSettings, useUpdateSettings } from '@/hooks/queries/useSettings';
import { useState, useTransition } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from 'sonner';
import { motion, Variants } from "framer-motion";

const containerVariants: Variants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
        opacity: 1, 
        y: 0,
        transition: { 
            staggerChildren: 0.1,
            duration: 0.8,
            ease: "circOut" 
        }
    }
};

const itemVariants: Variants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0 }
};

export default function SystemSettings() {
    const { data: settings = {}, isLoading: loading } = useSettings();
    const updateSettingsMutation = useUpdateSettings();
    const [isSaving, setIsSaving] = useState(false);
    const [isPending, startTransition] = useTransition();
    const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
    const [selectedCopyright, setSelectedCopyright] = useState<string | null>(null);

    async function handleSave(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();
        setIsSaving(true);
        const formData = new FormData(e.currentTarget);

        try {
            const result = await updateSettingsMutation.mutateAsync(formData);

            if (result.success) {
                toast.success("System Synchronized", {
                    description: "Core environment successfully synchronized & architectural assets locked."
                });
            } else {
                toast.error("Synchronization Failed", {
                    description: result.error || "Failed to update core environment."
                });
            }
        } catch (error) {
            toast.error("Synchronization Error", {
                description: "An unexpected error occurred during synchronization."
            });
        } finally {
            setIsSaving(false);
            setSelectedTemplate(null);
            setSelectedCopyright(null);
        }
    }

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-50/50">
                <div className="text-center space-y-6">
                    <div className="relative">
                        <div className="w-16 h-16 border-4 border-primary/10 border-t-primary rounded-full animate-spin mx-auto" />
                        <div className="absolute inset-0 w-20 h-20 -m-2 blur-xl bg-primary/20 animate-pulse rounded-full" />
                    </div>
                    <p className="opacity-40 animate-pulse">Accessing System Core...</p>
                </div>
            </div>
        );
    }

    return (
        <motion.section 
            initial="hidden"
            animate="visible"
            variants={containerVariants}
            className="pb-12 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto space-y-6"
        >
            <form onSubmit={handleSave} className="space-y-6">
                {/* Header Section */}
                <motion.header 
                    variants={itemVariants}
                    className="relative group p-6 sm:p-8 bg-white/40 backdrop-blur-md rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden"
                >
                    <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-primary/5 blur-[120px] rounded-full pointer-events-none" />
                    
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative z-10">
                        <div className="space-y-2">
                            <Badge variant="outline" className="px-3 py-1 rounded-full border-primary/20 text-primary bg-primary/5 text-[9px] font-bold tracking-wider uppercase">
                                Root Administrator Console
                            </Badge>
                            <h1 className="text-slate-900 dark:text-white text-3xl font-black">
                                System <span className="text-primary underline decoration-primary/10 underline-offset-8">Settings</span>
                            </h1>
                            <p className="text-slate-600 dark:text-slate-400 text-sm font-medium">
                                Configure the bedrock parameters of your journal environment.
                            </p>
                        </div>
                        <div className="flex gap-4 shrink-0">
                            <Button
                                type="submit"
                                disabled={isSaving}
                                className="h-12 px-8 gap-3 bg-primary text-white font-bold text-[10px] tracking-widest rounded-xl shadow-xl shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all group/save"
                            >
                                {isSaving ? (
                                    <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                                ) : (
                                    <Save className="w-4 h-4 group-hover/save:rotate-12 transition-transform" />
                                )}
                                {isSaving ? "SYNCING..." : "SYNC PREFERENCES"}
                            </Button>
                        </div>
                    </div>
                </motion.header>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 2xl:gap-12">
                    {/* Journal Identity */}
                    <motion.div variants={itemVariants}>
                        <Card className="group relative overflow-hidden bg-white/60 backdrop-blur-2xl border border-slate-200 dark:border-slate-800 shadow-xl rounded-2xl p-2 transition-all hover:shadow-2xl hover:shadow-primary/5">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16 blur-2xl group-hover:scale-150 transition-transform duration-1000" />
                            <CardHeader className="p-6 pb-2">
                                <div className="flex items-center gap-4 mb-2">
                                    <div className="w-12 h-12 rounded-xl bg-primary/5 border border-primary/10 flex items-center justify-center text-primary shadow-inner">
                                        <Globe className="w-6 h-6" />
                                    </div>
                                    <div className="space-y-0.5">
                                        <CardTitle className="text-slate-900 dark:text-white">Journal Identity</CardTitle>
                                        <CardDescription className="text-slate-500 dark:text-slate-400 text-xs">Branding & metadata protocols.</CardDescription>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="p-6 pt-0 space-y-6">
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">Full Publication Handle</Label>
                                    <Input
                                        name="journal_name"
                                        defaultValue={settings.journal_name}
                                        className="h-12 bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-primary/20 font-bold text-sm shadow-sm rounded-xl px-4 transition-all"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">Publishing Syndicate</Label>
                                    <Input
                                        name="publisher_name"
                                        defaultValue={settings.publisher_name}
                                        className="h-12 bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-primary/20 font-bold text-sm shadow-sm rounded-xl px-4"
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">SEO Cipher</Label>
                                        <Input
                                            name="journal_short_name"
                                            defaultValue={settings.journal_short_name}
                                            className="h-12 bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-primary/20 font-black text-sm shadow-sm rounded-xl px-4 tracking-widest"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">ISSN Protocol</Label>
                                        <Input
                                            name="issn_number"
                                            defaultValue={settings.issn_number}
                                            className="h-12 bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-primary/20 font-bold text-sm font-mono shadow-sm rounded-xl px-4"
                                        />
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    {/* Financial Infrastructure */}
                    <motion.div variants={itemVariants}>
                        <Card className="group relative overflow-hidden bg-white/60 backdrop-blur-2xl border border-slate-200 dark:border-slate-800 shadow-xl rounded-2xl p-2 transition-all hover:shadow-2xl hover:shadow-emerald-500/5">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full -mr-16 -mt-16 blur-2xl group-hover:scale-150 transition-transform duration-1000" />
                            <CardHeader className="p-6 pb-2">
                                <div className="flex items-center gap-4 mb-2">
                                    <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center justify-center shadow-inner">
                                        <CreditCard className="w-6 h-6" />
                                    </div>
                                    <div className="space-y-0.5">
                                        <CardTitle className="text-slate-900 dark:text-white">Econometrics</CardTitle>
                                        <CardDescription className="text-slate-500 dark:text-slate-400 text-xs">Transmission fees & parameters.</CardDescription>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="p-6 pt-0 space-y-6">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">Domestic (INR)</Label>
                                        <div className="relative">
                                            <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-emerald-600/50 text-base">₹</span>
                                            <Input
                                                name="apc_inr"
                                                defaultValue={settings.apc_inr}
                                                className="h-12 bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-emerald-500/20 font-black text-lg pl-8 rounded-xl"
                                            />
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">International (USD)</Label>
                                        <div className="relative">
                                            <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-emerald-600/50 text-base">$</span>
                                            <Input
                                                name="apc_usd"
                                                defaultValue={settings.apc_usd}
                                                className="h-12 bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-emerald-500/20 font-black text-lg pl-8 rounded-xl"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">Financial Disclosure Text</Label>
                                    <Textarea
                                        name="apc_description"
                                        defaultValue={settings.apc_description}
                                        rows={3}
                                        className="bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-emerald-500/20 font-medium text-xs p-4 rounded-xl resize-none min-h-[100px]"
                                    />
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    {/* Operational Support */}
                    <motion.div variants={itemVariants} className="lg:col-span-2">
                        <Card className="group relative overflow-hidden bg-white/40 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-lg rounded-2xl p-2 transition-all hover:shadow-2xl hover:shadow-amber-500/5">
                            <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full -mr-32 -mt-32 blur-[100px] group-hover:scale-110 transition-transform duration-1000" />
                            <CardHeader className="p-6 pb-2">
                                <div className="flex items-center gap-4 mb-2">
                                    <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 border border-amber-100 flex items-center justify-center shadow-inner">
                                        <Headphones className="w-6 h-6" />
                                    </div>
                                    <div className="space-y-0.5">
                                        <CardTitle className="text-slate-900 dark:text-white">Operations Center</CardTitle>
                                        <CardDescription className="text-slate-500 dark:text-slate-400 text-xs">Support pathways & physical logistics.</CardDescription>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="p-6 pt-0 space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">Editorial Council Inbox</Label>
                                        <Input
                                            name="support_email"
                                            defaultValue={settings.support_email}
                                            className="h-12 bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-amber-500/20 font-bold text-sm rounded-xl px-4"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">Direct Operations Phone</Label>
                                        <Input
                                            name="support_phone"
                                            defaultValue={settings.support_phone}
                                            className="h-12 bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-amber-500/20 font-bold text-sm rounded-xl px-4"
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-[10px] font-bold text-slate-900 dark:text-slate-300 tracking-wider px-1 uppercase">HQ Physical Architecture</Label>
                                    <Textarea
                                        name="office_address"
                                        defaultValue={settings.office_address}
                                        rows={2}
                                        className="bg-white/50 border-slate-200 dark:border-slate-800 focus-visible:ring-amber-500/20 font-bold text-sm p-4 rounded-xl resize-none"
                                    />
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    {/* Resources */}
                    <motion.div variants={itemVariants} className="lg:col-span-2">
                        <Card className="group relative bg-white shadow-xl rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
                            <CardHeader className="p-6 pb-2 border-b border-slate-50 dark:border-slate-900">
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shadow-inner">
                                        <Layout className="w-6 h-6" />
                                    </div>
                                    <div className="space-y-0.5">
                                        <CardTitle className="text-slate-900 dark:text-white">Asset Repository</CardTitle>
                                        <CardDescription className="text-slate-500 dark:text-slate-400 text-xs">Manage templates & covenants.</CardDescription>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="p-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    {/* Template Asset */}
                                    <div className="group/asset bg-slate-50/50 dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 transition-all hover:bg-white dark:hover:bg-slate-900 hover:shadow-xl">
                                        <div className="flex items-start justify-between mb-6">
                                            <div className="space-y-1">
                                                <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-none font-bold text-[8px] tracking-wider uppercase rounded-lg px-2 py-0.5">
                                                    MS-DOCX / PDF
                                                </Badge>
                                                <h4 className="text-sm font-bold text-slate-900 dark:text-white">Upload Template</h4>
                                            </div>
                                            <div className="w-10 h-10 rounded-lg bg-white dark:bg-slate-800 shadow-sm border border-slate-100 dark:border-slate-700 flex items-center justify-center text-blue-600">
                                                <FileText className="w-5 h-5" />
                                            </div>
                                        </div>
                                        
                                        <div className={cn(
                                            "relative group/field h-28 border-2 border-dashed rounded-xl flex flex-col items-center justify-center gap-2 transition-all overflow-hidden",
                                            selectedTemplate ? "border-blue-400 bg-blue-50/50 dark:bg-blue-900/10" : "border-slate-200 dark:border-slate-800 hover:border-blue-300 hover:bg-blue-50/30"
                                        )}>
                                            <Input
                                                type="file"
                                                name="template_url"
                                                onChange={(e) => setSelectedTemplate(e.target.files?.[0]?.name || null)}
                                                className="absolute inset-0 opacity-0 cursor-pointer z-20 h-full w-full"
                                            />
                                            {isSaving && selectedTemplate ? (
                                                <div className="flex flex-col items-center gap-2">
                                                    <Loader2 className="w-6 h-6 text-blue-500 animate-spin" />
                                                    <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest animate-pulse">Uploading...</span>
                                                </div>
                                            ) : selectedTemplate ? (
                                                <div className="flex flex-col items-center gap-1">
                                                    <CheckCircle2 className="w-6 h-6 text-blue-500" />
                                                    <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Staged: {selectedTemplate}</span>
                                                </div>
                                            ) : (
                                                <>
                                                    <Upload className="w-6 h-6 text-slate-300 group-hover/field:text-blue-500 group-hover/field:scale-110 transition-all" />
                                                    <span className="text-xs font-bold text-slate-500 group-hover/field:text-blue-600 uppercase tracking-tighter">Select Asset</span>
                                                </>
                                            )}

                                            {isSaving && selectedTemplate && (
                                                <motion.div 
                                                    initial={{ width: 0 }}
                                                    animate={{ width: "100%" }}
                                                    transition={{ duration: 2, ease: "easeInOut" }}
                                                    className="absolute bottom-0 left-0 h-1 bg-blue-500" 
                                                />
                                            )}
                                        </div>

                                        {settings.template_url && (
                                            <div className="mt-4 flex items-center justify-between p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                                                <div className="flex items-center gap-2 min-w-0">
                                                    <div className="w-7 h-7 rounded-lg bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-600 shrink-0">
                                                        <FileText className="w-3.5 h-3.5" />
                                                    </div>
                                                    <p className="truncate text-xs font-medium text-slate-600 dark:text-slate-400">{settings.template_url.split('/').pop()}</p>
                                                </div>
                                                <Button asChild variant="ghost" size="icon" className="w-7 h-7 rounded-lg hover:bg-blue-50 hover:text-blue-600">
                                                    <a href={settings.template_url} target="_blank" download title="Download Template"><ExternalLink className="w-3.5 h-3.5" /></a>
                                                </Button>
                                            </div>
                                        )}
                                    </div>

                                    {/* Copyright Asset */}
                                    <div className="group/asset bg-slate-50/50 dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 transition-all hover:bg-white dark:hover:bg-slate-900 hover:shadow-xl">
                                        <div className="flex items-start justify-between mb-6">
                                            <div className="space-y-1">
                                                <Badge className="bg-indigo-100 text-indigo-700 hover:bg-indigo-100 border-none font-bold text-[8px] tracking-wider uppercase rounded-lg px-2 py-0.5">
                                                    Legal Covenant
                                                </Badge>
                                                <h4 className="text-sm font-bold text-slate-900 dark:text-white">Upload Copyright Form</h4>
                                            </div>
                                            <div className="w-10 h-10 rounded-lg bg-white dark:bg-slate-800 shadow-sm border border-slate-100 dark:border-slate-700 flex items-center justify-center text-indigo-600">
                                                <Shield className="w-5 h-5" />
                                            </div>
                                        </div>
                                        
                                        <div className={cn(
                                            "relative group/field h-28 border-2 border-dashed rounded-xl flex flex-col items-center justify-center gap-2 transition-all overflow-hidden",
                                            selectedCopyright ? "border-indigo-400 bg-indigo-50/50 dark:bg-indigo-900/10" : "border-slate-200 dark:border-slate-800 hover:border-indigo-300 hover:bg-indigo-50/30"
                                        )}>
                                            <Input
                                                type="file"
                                                name="copyright_url"
                                                onChange={(e) => setSelectedCopyright(e.target.files?.[0]?.name || null)}
                                                className="absolute inset-0 opacity-0 cursor-pointer z-20 h-full w-full"
                                            />
                                            {isSaving && selectedCopyright ? (
                                                <div className="flex flex-col items-center gap-2">
                                                    <Loader2 className="w-6 h-6 text-indigo-500 animate-spin" />
                                                    <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest animate-pulse">Uploading...</span>
                                                </div>
                                            ) : selectedCopyright ? (
                                                <div className="flex flex-col items-center gap-1">
                                                    <CheckCircle2 className="w-6 h-6 text-indigo-500" />
                                                    <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">Staged: {selectedCopyright}</span>
                                                </div>
                                            ) : (
                                                <>
                                                    <Upload className="w-6 h-6 text-slate-300 group-hover/field:text-indigo-500 group-hover/field:scale-110 transition-all" />
                                                    <span className="text-xs font-bold text-slate-500 group-hover/field:text-indigo-600 uppercase tracking-tighter">Select Asset</span>
                                                </>
                                            )}

                                            {isSaving && selectedCopyright && (
                                                <motion.div 
                                                    initial={{ width: 0 }}
                                                    animate={{ width: "100%" }}
                                                    transition={{ duration: 2, ease: "easeInOut" }}
                                                    className="absolute bottom-0 left-0 h-1 bg-indigo-500" 
                                                />
                                            )}
                                        </div>

                                        {settings.copyright_url && (
                                            <div className="mt-4 flex items-center justify-between p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                                                <div className="flex items-center gap-2 min-w-0">
                                                    <div className="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-900/20 flex items-center justify-center text-indigo-600 shrink-0">
                                                        <FileText className="w-3.5 h-3.5" />
                                                    </div>
                                                    <p className="truncate text-xs font-medium text-slate-600 dark:text-slate-400">{settings.copyright_url.split('/').pop()}</p>
                                                </div>
                                                <Button asChild variant="ghost" size="icon" className="w-7 h-7 rounded-lg hover:bg-indigo-50 hover:text-indigo-600">
                                                    <a href={settings.copyright_url} target="_blank" download title="Download Copyright Form"><ExternalLink className="w-3.5 h-3.5" /></a>
                                                </Button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div variants={itemVariants} className="lg:col-span-2">
                        <Card className="relative overflow-hidden bg-white/40 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-lg rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-8">
                            <div className="absolute top-0 left-0 w-1.5 h-full bg-purple-500/20" />
                            <div className="flex items-center gap-6">
                                <div className="w-16 h-16 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center shadow-xl border border-purple-100 shrink-0 rotate-3">
                                    <Sparkles className="w-8 h-8" />
                                </div>
                                <div className="space-y-1">
                                    <h3 className="text-slate-900 dark:text-white font-bold">Growth Protocol <span className="text-slate-400 text-xs ml-2">v2.4</span></h3>
                                    <p className="text-slate-600 dark:text-slate-400 text-xs max-w-md font-medium">Override global promotion modules for landing zones & user interfaces.</p>
                                </div>
                            </div>
                            <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
                                <select
                                    name="is_promotion_active"
                                    defaultValue={settings.is_promotion_active || "true"}
                                    aria-label="Promotion Module Status"
                                    className="h-12 w-full sm:w-56 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2 text-xs font-bold tracking-wider uppercase transition-all shadow-md text-slate-900 dark:text-white cursor-pointer outline-none ring-offset-background focus:ring-2 focus:ring-purple-200"
                                >
                                    <option value="true">Active Transmission</option>
                                    <option value="false">Silent Protocol</option>
                                </select>
                                <div className="hidden sm:flex flex-col text-right">
                                    <span className="text-[8px] font-bold tracking-widest uppercase text-purple-600">Auto-Saving Disabled</span>
                                    <span className="text-[8px] font-bold tracking-widest uppercase text-slate-400">Requires Sync</span>
                                </div>
                            </div>
                        </Card>
                    </motion.div>
                </div>
            </form>
        </motion.section>
    );
}
