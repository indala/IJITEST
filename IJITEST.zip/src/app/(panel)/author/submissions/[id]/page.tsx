import { getAuthorSubmission, checkResubmissionEligibility } from "@/actions/author-submissions";
import { notFound } from "next/navigation";
import { ResubmissionForm } from "../_components/ResubmissionForm";
import { CopyrightUpload } from "@/features/author/components/CopyrightUpload";
import { ZenodoDepositCard } from "@/features/author/components/ZenodoDepositCard";
import { getSettingsData } from "@/actions/settings";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Download, AlertTriangle, MessageSquare, CheckCircle, Bookmark, ThumbsUp, ThumbsDown, UserCheck, Mail } from "lucide-react";
import SendReceiptButton from "@/features/submissions/components/SendReceiptButton";
import Link from "next/link";
import dayjs from "@/lib/dayjs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { getSecureUrl } from "@/lib/utils";
import { SubmissionTimeline } from "@/features/submissions/components/SubmissionTimeline";
import { DownloadCertificateButton } from "@/features/archives/components/PaperActions";
import type { SubmissionFile, SubmissionIdParam } from "@/db/types";

export default async function AuthorSubmissionDetailsPage({ params }: { params: Promise<SubmissionIdParam> }) {
    const resolvedParams = await params;
    const submissionId = parseInt(resolvedParams.id);
    const [subResponse, settings] = await Promise.all([
        getAuthorSubmission(submissionId),
        getSettingsData()
    ]);
    if (!subResponse.success || !subResponse.data) return notFound();
    const sub = subResponse.data;

    const eligResponse = await checkResubmissionEligibility(submissionId);
    let eligibility = { eligible: false, daysRemaining: 0 };
    let eligError = "";
    if (eligResponse.success) {
        eligibility = eligResponse.data;
    } else {
        eligError = eligResponse.error;
    }

    const copyrightFile = sub.files.find((file: SubmissionFile) => file.fileType === 'copyrightForm');
    const isAcceptedOrPublished = ['accepted', 'paymentPending', 'published'].includes(sub.status);

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'accepted': return 'bg-green-100 text-green-700 border-green-200';
            case 'rejected': return 'bg-red-100 text-red-700 border-red-200';
            case 'underReview': return 'bg-blue-100 text-blue-700 border-blue-200';
            case 'revisionRequested': return 'bg-orange-100 text-orange-700 border-orange-200';
            default: return 'bg-gray-100 text-gray-700 border-gray-200';
        }
    };

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-5 duration-700">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-1">
                    <h1 className="font-black tracking-tight text-primary">Manuscript Details</h1>
                    <div className="flex items-center gap-3 text-label text-primary/40 font-bold uppercase tracking-widest leading-none">
                        <span>{sub.paperId}</span>
                        <div className="w-1.5 h-1.5 rounded-full bg-primary/20" />
                        <span>Submitted on {dayjs(sub.submittedAt).format("MMMM DD, YYYY")}</span>
                    </div>
                </div>
                <div className="flex flex-wrap items-center gap-2.5">
                    <Badge className={`px-5 py-2 rounded-xl border text-badge font-black uppercase tracking-widest ${getStatusColor(sub.status)} `}>
                        {sub.status.replace('_', ' ')}
                    </Badge>
                    {sub.section && (
                        <Badge variant="outline" className="px-3.5 py-1.5 rounded-xl border text-badge font-bold bg-primary/5 text-primary border-primary/20 flex items-center gap-1.5">
                            <Bookmark className="w-3.5 h-3.5" />
                            <span>{sub.section.title}</span>
                            {sub.section.abbrev && <span className="opacity-60 font-mono text-meta">({sub.section.abbrev})</span>}
                        </Badge>
                    )}
                </div>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
                {/* Main Details (Left Col) */}
                <div className="lg:col-span-2 space-y-8">
                    <Card className="border-primary/10 shadow-xl shadow-primary/5 overflow-hidden">
                        <CardHeader className="bg-primary/1 border-b border-primary/5">
                            <CardTitle className="font-black text-primary">Abstract & Metadata</CardTitle>
                            <CardDescription>Current version metadata for your manuscript.</CardDescription>
                        </CardHeader>
                        <CardContent className="pt-6 space-y-6">
                            <div className="space-y-2">
                                <h3 className="font-black text-primary leading-tight">{sub.title}</h3>
                                <p className="text-caption text-primary/60 italic leading-relaxed">{sub.abstract}</p>
                            </div>
                            
                            <div className="flex flex-wrap gap-2">
                                {sub.keywords?.split(',').map((kw: string) => (
                                    <Badge key={kw} variant="outline" className="px-3 py-1 rounded-lg border-primary/10 text-badge font-bold text-primary/50">
                                        {kw.trim()}
                                    </Badge>
                                ))}
                            </div>

                            <div className="pt-6 border-t border-primary/5 grid grid-cols-2 gap-6">
                                <div className="space-y-1">
                                    <span className="text-label font-black uppercase tracking-widest text-primary/30">Current Version</span>
                                    <p className="font-bold text-primary">v{sub.versionNumber}</p>
                                </div>
                                <div className="space-y-1 text-right">
                                    <span className="text-label font-black uppercase tracking-widest text-primary/30">Last Updated</span>
                                    <p className="font-bold text-primary">{dayjs(sub.updatedAt!).format("MMM DD, YYYY")}</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Peer Review Intelligence & Feedback */}
                    {['revisionRequested', 'rejected', 'accepted', 'published'].includes(sub.status) ? (
                        <Card className="border-primary/10 shadow-xl shadow-primary/5 overflow-hidden">
                            <CardHeader className="bg-primary/1 border-b border-primary/5">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center shrink-0">
                                        <MessageSquare className="w-5 h-5 text-primary" />
                                    </div>
                                    <div>
                                        <CardTitle className="font-black text-primary">Peer Review Feedback</CardTitle>
                                        <CardDescription>Evaluation notes and technical recommendations from the editorial board.</CardDescription>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="pt-6 space-y-6">
                                {!sub.reviewComments || sub.reviewComments.length === 0 ? (
                                    <div className="text-center py-8 bg-muted/10 rounded-2xl border border-dashed border-primary/10">
                                        <p className="text-label font-bold text-primary/40 uppercase tracking-widest">No review comments recorded for this decision round.</p>
                                    </div>
                                ) : (
                                    <div className="space-y-4">
                                        {sub.reviewComments.map((comment, index) => (
                                            <div key={index} className="p-5 rounded-2xl border border-primary/5 bg-primary/5 space-y-3">
                                                <div className="flex items-center justify-between gap-4">
                                                    <Badge className="bg-primary/5 text-primary border-none text-badge font-black uppercase tracking-widest px-3 py-1">
                                                        Evaluation Comment #{index + 1}
                                                    </Badge>
                                                    <span className="text-label font-bold text-primary/30 uppercase tracking-widest">
                                                        {dayjs(comment.submittedAt).format("MMM DD, YYYY")}
                                                    </span>
                                                </div>
                                                <p className="font-semibold text-primary/80 leading-relaxed whitespace-pre-wrap">
                                                    &ldquo;{comment.commentsToAuthor}&rdquo;
                                                </p>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    ) : (
                        <Card className="border-primary/10 shadow-xl shadow-primary/5 overflow-hidden">
                            <CardHeader className="bg-primary/1 border-b border-primary/5">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center shrink-0">
                                        <MessageSquare className="w-5 h-5 text-primary" />
                                    </div>
                                    <div>
                                        <CardTitle className="font-black text-primary">Peer Review Queue</CardTitle>
                                        <CardDescription>Status of technical and scientific peer assessment.</CardDescription>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="pt-6 text-center py-10 space-y-3">
                                <div className="w-12 h-12 bg-primary/5 rounded-2xl flex items-center justify-center mx-auto">
                                    <MessageSquare className="w-6 h-6 text-primary animate-pulse" />
                                </div>
                                <div className="space-y-1 max-w-sm mx-auto">
                                    <p className="text-label font-black uppercase tracking-widest text-primary">Undergoing Review</p>
                                    <p className="font-bold text-primary/40 leading-relaxed">
                                        Your manuscript is currently undergoing editorial screening and peer evaluation. Reviewer feedback will be presented here once the final decision has been processed.
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Resubmission Section / Copyright Upload Section */}
                    {eligibility.eligible ? (
                        <ResubmissionForm 
                            submissionId={submissionId} 
                            daysRemaining={eligibility.daysRemaining || 28} 
                        />
                    ) : isAcceptedOrPublished ? (
                        copyrightFile ? (
                            <Card className="border-emerald-200 bg-emerald-50/50 animate-in fade-in duration-500 rounded-2xl">
                                <CardContent className="p-6 flex items-center justify-between gap-4">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0">
                                            <CheckCircle className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <h4 className="font-black text-emerald-800">Copyright Agreement Verified</h4>
                                            <p className="text-emerald-600/70 font-bold">The signed consent form has been uploaded and validated.</p>
                                        </div>
                                    </div>
                                    <Button asChild size="sm" variant="outline" className="h-9 gap-2 border-emerald-500/20 text-emerald-600 hover:bg-emerald-500/10 rounded-xl font-bold uppercase">
                                        <a href={getSecureUrl(copyrightFile.fileUrl)} target="_blank" rel="noopener noreferrer">
                                            <Download className="w-3.5 h-3.5" />
                                            View Form
                                        </a>
                                    </Button>
                                </CardContent>
                            </Card>
                        ) : (
                            <CopyrightUpload 
                                submissionId={submissionId} 
                                copyrightUrl={settings['copyrightUrl']} 
                            />
                        )
                    ) : null}

                    {!eligibility.eligible && sub.status === 'revisionRequested' && (
                        <Alert className="bg-red-50 border-red-100 rounded-2xl">
                            <AlertTriangle className="w-4 h-4 text-red-600" />
                            <AlertTitle className="text-label font-black uppercase tracking-widest text-red-900">Window Expired</AlertTitle>
                            <AlertDescription className="text-body-sm text-red-700 font-bold">
                                {eligError || "Submission window (28 days) has expired."}
                            </AlertDescription>
                        </Alert>
                    )}

                    {/* Submission Event Timeline */}
                    <SubmissionTimeline submissionId={submissionId} />
                </div>

                {/* Sidebar (Right Col) */}
                <div className="space-y-8">
                    {/* File Links */}
                    <Card className="border-primary/10 shadow-xl shadow-primary/5">
                        <CardHeader className="bg-primary/5 border-b border-primary/5">
                            <CardTitle className="font-black text-primary uppercase tracking-widest">Submitted Files</CardTitle>
                        </CardHeader>
                        <CardContent className="pt-6 space-y-3">
                            {sub.files.map((file: SubmissionFile) => (
                                <Link 
                                    key={file.id} 
                                    href={getSecureUrl(file.fileUrl)} 
                                    target="_blank"
                                    className="flex items-center justify-between p-4 rounded-xl border border-primary/5 hover:bg-primary/5 hover:border-secondary transition-all group"
                                >
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-lg bg-primary/5 flex items-center justify-center text-primary/40 group-hover:text-secondary group-hover:bg-secondary/10 transition-all">
                                            <Download className="w-4 h-4" />
                                        </div>
                                        <div>
                                            <p className="font-black text-primary/60 truncate max-w-[120px]">{file.originalName}</p>
                                            <p className="text-label font-bold text-primary/30 uppercase tracking-widest">{file.fileType.replace('_', ' ')}</p>
                                        </div>
                                    </div>
                                    <Badge variant="outline" className="text-badge border-primary/5 text-primary/40">{file.fileSize ? (file.fileSize / 1024 / 1024).toFixed(1) : '0'}MB</Badge>
                                </Link>
                            ))}
                        </CardContent>
                    </Card>

                    {/* Authors List */}
                    <Card className="border-primary/10 shadow-xl shadow-primary/5">
                        <CardHeader className="bg-primary/1 border-b border-primary/5">
                            <CardTitle className="font-black text-primary uppercase tracking-widest">Research Authors</CardTitle>
                        </CardHeader>
                        <CardContent className="pt-6 space-y-4">
                            {sub.authors.map((author: { name: string; institution: string | null; isCorresponding: boolean }, idx: number) => (
                                <div key={idx} className="flex items-start gap-3">
                                    <div className="w-8 h-8 rounded-full bg-primary/5 flex items-center justify-center shrink-0 text-primary/40 font-black text-badge">
                                        {idx + 1}
                                    </div>
                                    <div className="space-y-0.5">
                                        <p className="font-black text-primary/80 leading-none">{author.name}</p>
                                        <p className="text-label font-bold text-primary/30 tracking-tight leading-none">{author.institution || 'No Institution'}</p>
                                        {author.isCorresponding && (
                                            <Badge className="mt-2 bg-secondary/10 text-secondary border-0 text-badge font-black tracking-widest h-4 px-1.5 uppercase leading-none">Corresponding</Badge>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </CardContent>
                    </Card>

                    {/* Reviewer Suggestions (if any were submitted) */}
                    {sub.reviewerSuggestions && sub.reviewerSuggestions.length > 0 && (
                        <Card className="border-primary/10 shadow-xl shadow-primary/5">
                            <CardHeader className="bg-primary/1 border-b border-primary/5">
                                <CardTitle className="font-black text-primary uppercase tracking-widest flex items-center gap-2">
                                    <UserCheck className="w-4 h-4 text-primary" />
                                    Reviewer Preferences
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="pt-6 space-y-3">
                                {sub.reviewerSuggestions.map((sug, idx) => (
                                    <div
                                        key={idx}
                                        className={`p-3 rounded-xl border text-body-sm space-y-1 ${
                                            sug.type === 'opposed'
                                                ? 'border-rose-200 bg-rose-50/40 dark:bg-rose-950/20'
                                                : 'border-emerald-200 bg-emerald-50/40 dark:bg-emerald-950/20'
                                        } `}
                                    >
                                        <div className="flex items-center justify-between font-bold">
                                            <span className="flex items-center gap-1.5">
                                                {sug.type === 'opposed' ? <ThumbsDown className="w-3.5 h-3.5 text-rose-600" /> : <ThumbsUp className="w-3.5 h-3.5 text-emerald-600" />}
                                                {sug.givenName} {sug.familyName || ""}
                                            </span>
                                            <span className={`text-label uppercase px-1.5 py-0.5 rounded font-black ${
                                                sug.type === 'opposed' ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'
                                            } `}>
                                                {sug.type}
                                            </span>
                                        </div>
                                        <p className="text-muted-foreground text-caption truncate m-0">{sug.email} {sug.affiliation ? `• ${sug.affiliation}` : ''}</p>
                                        {sug.suggestionReason && (
                                            <p className="text-muted-foreground italic text-caption m-0 border-t border-border/30 pt-1">
                                                &quot;{sug.suggestionReason}&quot;
                                            </p>
                                        )}
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    )}

                    {/* APC Remittance & Receipt */}
                    {sub.payment && (
                        <Card className="border-primary/10 shadow-xl shadow-primary/5">
                            <CardHeader className="bg-primary/5 border-b border-primary/5">
                                <div className="flex items-center justify-between">
                                    <CardTitle className="font-black text-primary uppercase tracking-widest">
                                        APC Remittance
                                    </CardTitle>
                                    <Badge className={`text-badge font-black uppercase tracking-wider px-2 py-0.5 ${
                                        ['paid', 'verified'].includes(sub.payment.status)
                                            ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
                                            : sub.payment.status === 'waived'
                                            ? 'bg-purple-100 text-purple-700 border-purple-200'
                                            : 'bg-amber-100 text-amber-700 border-amber-200'
                                    } `}>
                                        {sub.payment.status === 'verified' ? 'Verified' : sub.payment.status}
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent className="pt-6 space-y-4">
                                <div className="flex justify-between items-center text-body-sm">
                                    <span className="text-primary/50 font-bold uppercase tracking-wider">Fee Amount</span>
                                    <span className="font-black text-primary text-body-sm">{sub.payment.amount} {sub.payment.currency}</span>
                                </div>
                                {sub.payment.invoiceNumber && (
                                    <div className="flex justify-between items-center text-body-sm">
                                        <span className="text-primary/50 font-bold uppercase tracking-wider">Invoice No.</span>
                                        <span className="font-mono font-bold text-primary/70">{sub.payment.invoiceNumber}</span>
                                    </div>
                                )}
                                {sub.payment.transactionId && (
                                    <div className="flex justify-between items-center text-body-sm">
                                        <span className="text-primary/50 font-bold uppercase tracking-wider">Transaction ID</span>
                                        <span className="font-mono text-meta text-primary/60 truncate max-w-[150px]">{sub.payment.transactionId}</span>
                                    </div>
                                )}
                                {['paid', 'verified'].includes(sub.payment.status) ? (
                                    <SendReceiptButton
                                        paymentId={sub.payment.id}
                                        className="w-full h-10 gap-2 rounded-xl font-bold uppercase border-primary/20 hover:bg-primary/5"
                                    >
                                        <Mail className="w-4 h-4 text-primary" />
                                        Email Tax Invoice & Receipt
                                    </SendReceiptButton>
                                ) : sub.payment.status === 'pending' ? (
                                    <Button asChild className="w-full h-10 gap-2 rounded-xl font-bold uppercase bg-primary text-primary-foreground hover:bg-primary/90">
                                        <Link href={`/payment/${sub.paperId}`}>
                                            Proceed to APC Payment
                                        </Link>
                                    </Button>
                                ) : null}
                            </CardContent>
                        </Card>
                    )}

                    {/* Published Link & Certificate (if applicable) */}
                    {sub.publication && (
                        <div className="space-y-3">
                            <Link 
                                href={getSecureUrl(sub.publication.finalPdfUrl)}
                                target="_blank"
                                className="flex flex-col items-center justify-center gap-4 p-8 bg-primary rounded-3xl text-white text-center shadow-2xl shadow-primary/40 hover:scale-[1.02] transition-transform"
                            >
                                <Calendar className="w-12 h-12 text-secondary" />
                                <div className="space-y-1">
                                    <h3 className="font-black tracking-tight">Paper Published!</h3>
                                    <p className="text-label text-white/60 font-black uppercase tracking-widest">
                                        Volume {sub.publication.volumeNumber}, Issue {sub.publication.issueNumber}
                                    </p>
                                </div>
                                <Badge className="bg-white/20 text-white border-0 text-badge tracking-widest font-black h-8 px-5 rounded-full backdrop-blur-sm">VIEW ARCHIVE</Badge>
                            </Link>
                            {sub.paperId && (
                                <DownloadCertificateButton
                                    paperId={sub.paperId}
                                    className="w-full h-10 flex items-center justify-center gap-2 rounded-xl font-bold uppercase border border-primary/20 hover:bg-primary/5 text-primary text-sm transition-all cursor-pointer disabled:opacity-60"
                                >
                                    <Download className="w-4 h-4 text-primary" />
                                    <span>Download Certificate (PDF)</span>
                                </DownloadCertificateButton>
                            )}
                            <ZenodoDepositCard
                                submissionId={submissionId}
                                publication={sub.publication}
                                initialDeposit={sub.zenodoDeposit}
                            />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
