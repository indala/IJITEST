import { Suspense } from 'react';
import { getSettingsData } from '@/actions/settings';
import { getLatestPublishedIssue } from '@/actions/publications';
import { getLatestIssuePapers } from '@/actions/archives';
import { getAnnouncements } from '@/actions/announcements';
import type { Metadata } from 'next';
import HomeCarousel from '@/features/home/components/HomeCarousel';
import WelcomeSection from '@/features/home/components/WelcomeSection';
import AimAndScope from '@/features/home/components/AimAndScope';
import AnnouncementsWidget from '@/features/shared/widgets/AnnouncementsWidget';
import PublisherSection from '@/features/home/components/PublisherSection';
import TrackManuscriptWidget from '@/features/shared/widgets/TrackManuscriptWidget';
import CallForPapersWidget from '@/features/shared/widgets/CallForPapersWidget';
import ResourceDeskWidget from '@/features/shared/widgets/ResourceDeskWidget';
import EthicsWidget from '@/features/shared/widgets/EthicsWidget';
import AnnouncementBar from '@/features/home/components/AnnouncementBar';
import { Section } from '@/components/layout/Section';
import { SidebarLayout } from '@/components/layout/SidebarLayout';
import {
  AnnouncementBarSkeleton,
  AnnouncementsWidgetSkeleton,
} from '@/features/home/components/HomeSkeletons';

async function AnnouncementBarSection() {
  const latestPapersRes = await getLatestIssuePapers();
  const latestPaper = latestPapersRes.success ? latestPapersRes.data?.[0] : undefined;
  return <AnnouncementBar latestPaper={latestPaper} />;
}

async function AnnouncementsWidgetSection() {
  const [latestIssueRes, announcementsRes] = await Promise.all([
    getLatestPublishedIssue(),
    getAnnouncements({ limit: 3 }),
  ]);
  const latestIssue = latestIssueRes.success ? latestIssueRes.data : null;
  const announcements = announcementsRes.success ? (announcementsRes.data ?? []) : [];
  return <AnnouncementsWidget latestIssue={latestIssue} announcements={announcements} />;
}

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSettingsData();
  return {
    title: settings['journalName'],
    description: `Welcome to ${settings['journalName']} (${settings['journalShortName']}). We provide a global platform for breakthrough research in engineering, science, and technology with rapid, high-quality peer review.`,
    alternates: {
      canonical: '/',
    },
    openGraph: {
      title: settings['journalName'],
      description: `Advancing scientific excellence through innovative trends. Explore peer-reviewed research and elite academic publishing at ${settings['journalShortName']}.`,
      type: 'website',
      siteName: settings['journalName'],
      images: [
        {
          url: '/open_graph_img.png',
          width: 1200,
          height: 630,
          alt: `${settings['journalShortName']} - Global Research Platform`,
        },
      ],
    }
  };
}

export default async function Home() {
  const settings = await getSettingsData();

  return (
    <div className="flex flex-col overflow-hidden bg-background relative">
      <Suspense fallback={<AnnouncementBarSkeleton />}>
        <AnnouncementBarSection />
      </Suspense>
      
      <HomeCarousel />

      <Section className="relative z-10" padding={false}>
        <SidebarLayout
          className="my-6 sm:my-8 lg:my-10"
          sidebarClassName="space-y-4 sm:space-y-5"
          mainClassName="space-y-6 sm:space-y-8"
          sidebar={
            <div className="space-y-4 sm:space-y-5">
              <TrackManuscriptWidget />
              <CallForPapersWidget />
              <Suspense fallback={<AnnouncementsWidgetSkeleton />}>
                <AnnouncementsWidgetSection />
              </Suspense>
              <ResourceDeskWidget settings={settings} />
              <EthicsWidget />
            </div>
          }
        >
          <WelcomeSection settings={settings} />
          <AimAndScope settings={settings} shortName={settings['journalShortName']} />
          <PublisherSection settings={settings} embedded />
        </SidebarLayout>
      </Section>
    </div>
  );
}
