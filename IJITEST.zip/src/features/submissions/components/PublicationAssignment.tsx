'use client'

import { useState, useTransition, useActionState } from 'react'
import { Plus, Globe, Loader2, Layers } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from 'sonner'
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    DialogFooter
} from "@/components/ui/dialog"
import {
    useVolumesIssues
} from '@/hooks/queries/usePublications'
import {
    createVolumeIssue,
    assignPaperToIssue
} from '@/actions/publications'
import { useQueryClient } from '@tanstack/react-query'
import { type ActionResponse } from '@/db/types'

interface PublicationAssignmentProps {
    submissionId: number;
    currentIssueId?: number | null;
}

export default function PublicationAssignment({ submissionId, currentIssueId }: PublicationAssignmentProps) {
    const queryClient = useQueryClient();
    const { data: volumes = [], isLoading: loading } = useVolumesIssues();

    const [showCreateModal, setShowCreateModal] = useState(false);
    const [selectedIssueId, setSelectedIssueId] = useState<string>(currentIssueId?.toString() || "");
    const [startPage, setStartPage] = useState<string>("");
    const [endPage, setEndPage] = useState<string>("");
    const [isAssigning, startAssign] = useTransition();

    const [, createAction, isCreating] = useActionState(async (_prev: ActionResponse | null, formData: FormData) => {
        const res = await createVolumeIssue(formData);
        if (res.success) {
            setShowCreateModal(false);
            toast.success("Publication cycle initialized");
            queryClient.invalidateQueries({ queryKey: ['volumes-issues'] });
        } else {
            toast.error(res.error || "Failed to initialize cycle");
        }
        return res;
    }, null);

    async function handleAssign() {
        if (!selectedIssueId) {
            toast.error("Please select a target issue node");
            return;
        }

        startAssign(async () => {
            try {
                const res = await assignPaperToIssue(
                    submissionId,
                    parseInt(selectedIssueId),
                    startPage ? parseInt(startPage) : undefined,
                    endPage ? parseInt(endPage) : undefined
                );
                if (res.success) {
                    toast.success("Manuscript committed to archive");
                    queryClient.invalidateQueries({ queryKey: ['volumes-issues'] });
                    queryClient.invalidateQueries({ queryKey: ['submissions'] });
                } else {
                    toast.error(res.error || "Failed to assign paper to issue");
                }
            } catch {
                toast.error("Failed to assign paper to issue");
            }
        });
    }

    if (loading) return (
        <div className="h-11 bg-primary/5 rounded-xl animate-pulse flex items-center justify-center">
            <Loader2 className="w-4 h-4 text-primary/20 animate-spin" />
        </div>
    );

    return (
        <div className="space-y-4 pt-4 border-t border-emerald-500/10">
            <div className="space-y-4">
                <div className="space-y-2">
                    <div className="flex items-center justify-between px-1">
                        <label className="opacity-40 leading-none">Volume and Issue</label>
                        <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
                            <DialogTrigger asChild>
                                <button className="text-emerald-600 hover:text-emerald-700 flex items-center gap-1 transition-colors cursor-pointer">
                                    <Plus className="w-2.5 h-2.5" /> Add new
                                </button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-md rounded-xl p-8 bg-card border-primary/5 shadow-2xl overflow-hidden">
                                <div className="absolute top-0 left-0 w-full h-2 bg-emerald-500/10" />
                                <DialogHeader className="space-y-2">
                                    <DialogTitle className="text-2xl text-foreground">Quick Terminal</DialogTitle>
                                    <DialogDescription className="opacity-60 leading-relaxed">
                                        Instantly define a new publication node for immediate manuscript archival.
                                    </DialogDescription>
                                </DialogHeader>
                                <form action={createAction} className="space-y-5 mt-4">
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <Label className="opacity-40">Volume</Label>
                                            <Input
                                                name="volume"
                                                type="number"
                                                required
                                                className="h-12 bg-primary/5 border-none rounded-xl px-4"
                                                placeholder="e.g. 1"
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <Label className="opacity-40">Issue</Label>
                                            <Input
                                                name="issue"
                                                type="number"
                                                required
                                                className="h-12 bg-primary/5 border-none rounded-xl px-4"
                                                placeholder="e.g. 1"
                                            />
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="opacity-40">Year</Label>
                                        <Input
                                            name="year"
                                            type="number"
                                            required
                                            defaultValue={new Date().getFullYear()}
                                            className="h-12 bg-primary/5 border-none rounded-xl px-4"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="opacity-40">Month Range</Label>
                                        <Input
                                            name="monthRange"
                                            type="text"
                                            required
                                            placeholder="e.g. Jan - Mar"
                                            className="h-12 bg-primary/5 border-none rounded-xl px-4"
                                        />
                                    </div>
                                    <DialogFooter className="pt-2">
                                         <Button disabled={isCreating} type="submit" className="w-full h-12 bg-emerald-600 text-white rounded-xl shadow-lg shadow-emerald-600/10 cursor-pointer">
                                             {isCreating ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create'}
                                         </Button>
                                    </DialogFooter>
                                </form>
                            </DialogContent>
                        </Dialog>
                    </div>
                    <div className="relative">
                        <select
                            title="issueId"
                            value={selectedIssueId}
                            onChange={(e) => setSelectedIssueId(e.target.value)}
                            className="w-full h-11 bg-background border border-emerald-500/20 rounded-xl px-4 appearance-none outline-none focus:ring-4 focus:ring-emerald-500/5 transition-all text-emerald-900 cursor-pointer"
                        >
                            <option value="">Select Target Issue...</option>
                            {volumes.map((vi) => (
                                <option key={vi.id} value={vi.id}>
                                    VOL {vi.volumeNumber} ISSUE {vi.issueNumber} ({vi.year})
                                </option>
                            ))}
                        </select>
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none opacity-40">
                            <Layers className="w-4 h-4 text-emerald-600" />
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                        <label className="opacity-40 leading-none">Start Page</label>
                        <Input
                            type="number"
                            placeholder="e.g. 4"
                            value={startPage}
                            onChange={(e) => setStartPage(e.target.value)}
                            className="h-10 bg-background border-emerald-500/10 rounded-lg"
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="opacity-40 leading-none">End Page</label>
                        <Input
                            type="number"
                            placeholder="e.g. 8"
                            value={endPage}
                            onChange={(e) => setEndPage(e.target.value)}
                            className="h-10 bg-background border-emerald-500/10 rounded-lg"
                        />
                    </div>
                </div>
            </div>

            <Button
                onClick={handleAssign}
                disabled={isAssigning || !selectedIssueId}
                className="w-full h-12 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xl shadow-emerald-600/20 cursor-pointer transition-all active:scale-[0.98]"
            >
                {isAssigning ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                    <Globe className="w-4 h-4 mr-2" />
                )}
                {isAssigning ? 'INDEXING...' : 'Commit to Archive'}
            </Button>
        </div>
    );
}
