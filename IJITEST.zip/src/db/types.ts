import {
    users,
    userProfiles,
    submissions,
    submissionVersions,
    submissionFiles,
    submissionAuthors,
    reviewAssignments,
    reviews,
    payments,
    volumesIssues,
    publications,
    applications,
    applicationInterests,
    contactMessages,
    notifications,
    activityLogs,
    settings,
    chatMessages,
    pushSubscriptions,
    emailTemplates,
    sections,
    reviewerSuggestions,
    submissionEventLog,
    announcements,
    staticPages,
    usageStats,
    SUBMISSION_EVENT_TYPES,
    type SubmissionEventType
} from "./schema";
import { type InferSelectModel, type InferInsertModel } from "drizzle-orm";


// 📜 Re-export submission event types
export { SUBMISSION_EVENT_TYPES };
export type { SubmissionEventType };

// 🏷️ Global Literal Types (Enums derived from Schema)
export type UserRole = InferSelectModel<typeof users>['role'];
export type SubmissionStatus = InferSelectModel<typeof submissions>['status'];
export type ReviewStatus = InferSelectModel<typeof reviewAssignments>['status'];
export type ReviewDecision = InferSelectModel<typeof reviews>['decision'];
export type PaymentStatus = InferSelectModel<typeof payments>['status'];
export type ApplicationStatus = InferSelectModel<typeof applications>['status'];
export type ApplicationType = InferSelectModel<typeof applications>['type'];
export type ContactStatus = InferSelectModel<typeof contactMessages>['status'];
export type VolumeIssueStatus = InferSelectModel<typeof volumesIssues>['status'];
export type FileType = InferSelectModel<typeof submissionFiles>['fileType'];
export type FinalDecision = InferSelectModel<typeof submissions>['finalDecision'];
export type GalleyStatus = InferSelectModel<typeof submissions>['galleyStatus'];
export type NotificationType = InferSelectModel<typeof notifications>['type'];
export type DoiProvider = InferSelectModel<typeof publications>['doiProvider'];
export type DoiRegistrationStatus = InferSelectModel<typeof publications>['doiRegistrationStatus'];

// 👤 Users & Profiles
export type User = InferSelectModel<typeof users>;
export type NewUser = InferInsertModel<typeof users>;

export type UserProfile = InferSelectModel<typeof userProfiles>;
export type NewUserProfile = InferInsertModel<typeof userProfiles>;

export type UserWithProfile = User & {
    profile: UserProfile | null;
};

// 🔒 Safe types (excluding sensitive fields)
export type SafeUser = Omit<User, 'passwordHash'>;
export type SafeUserWithProfile = SafeUser & {
    profile: UserProfile | null;
};
export type ProfileData = Pick<User, 'id' | 'email'> &
    Omit<UserProfile, 'userId' | 'createdAt' | 'updatedAt' | 'fullName' | 'id'> & {
        name: UserProfile['fullName'];
        application?: {
            institute: Application['institute'];
            country: Application['nationality'];
            status: Application['status'];
            rejectionReason: string | null;
            reviewedAt: Application['reviewedAt'];
        };
        researchInterests: string[];
        history: Array<{
            title: Pick<Version, 'title'>['title'];
            submittedAt?: Submission['submittedAt'];
            updatedAt?: Submission['updatedAt'];
            status?: Submission['status'] | null;
            decision?: Review['decision'] | null;
        }>;
        completeness: {
            score: number;
            total: number;
            percentage: number;
            missing: string[];
        };
    };

// 📄 Submissions
export type Submission = InferSelectModel<typeof submissions>;
export type NewSubmission = InferInsertModel<typeof submissions>;

export type Version = InferSelectModel<typeof submissionVersions>;
export type NewVersion = InferInsertModel<typeof submissionVersions>;

export type SubmissionFile = InferSelectModel<typeof submissionFiles>;
export type Author = InferSelectModel<typeof submissionAuthors>;

export type SubmissionDetail = Submission & {
    correspondingAuthor?: UserWithProfile | undefined;
    versions: (Version & { files: SubmissionFile[] })[];
    authors: Author[];
    section?: Section | null | undefined;
    reviewerSuggestions?: ReviewerSuggestion[] | undefined;
    eventLogs?: (SubmissionEventLogEntry & { user?: UserWithProfile | null })[] | undefined;
    payment?: Payment | null | undefined;
    publication: Publication | null;
    issue: Issue | null;
    reviewAssignments: ReviewWithReviewer[];
};

export type SubmissionUI = SubmissionDetail &
    Pick<Version, 'title' | 'abstract' | 'keywords'> & {
        filePath: Pick<SubmissionFile, 'fileUrl'>['fileUrl'];
        pdfUrl: Pick<Publication, 'finalPdfUrl'>['finalPdfUrl'];
        authorName: Pick<Author, 'name'>['name'];
        authorEmail: Pick<Author, 'email'>['email'];
        coAuthors: Author[];
        doi?: Pick<Publication, 'doi'>['doi'] | undefined;
        volumeNumber?: Pick<Issue, 'volumeNumber'>['volumeNumber'] | undefined;
        issueNumber?: Pick<Issue, 'issueNumber'>['issueNumber'] | undefined;
        startPage?: Pick<Publication, 'startPage'>['startPage'] | undefined;
        endPage?: Pick<Publication, 'endPage'>['endPage'] | undefined;
        latestVersion?: (Version & { files: SubmissionFile[] }) | undefined;
        allFiles: SubmissionFile[];
        allReviews: ReviewWithReviewer[];
        completedReviews?: number | undefined;
    };

export type SubmissionStats = {
    total: number;
} & Record<Extract<SubmissionStatus, 'submitted' | 'underReview' | 'published' | 'rejected'>, number>;

// 🧪 Reviews
export type ReviewAssignment = InferSelectModel<typeof reviewAssignments>;
export type NewReviewAssignment = InferInsertModel<typeof reviewAssignments>;

export type Review = InferSelectModel<typeof reviews>;
export type NewReview = InferInsertModel<typeof reviews>;

export type ReviewWithReviewer = ReviewAssignment & {
    reviewer: UserWithProfile;
    review: Review | null;
};

// 💰 Payments
export type Payment = InferSelectModel<typeof payments>;
export type NewPayment = InferInsertModel<typeof payments>;

export type PaymentRow = Payment & {
    title: Pick<Version, 'title'>['title'];
    paperId: Submission['paperId'];
    authorName: UserProfile['fullName'];
    authorEmail: User['email'];
};

export type UnpaidPaperRow = Pick<Submission, 'id' | 'paperId'> & {
    title: Pick<Version, 'title'>['title'];
    authorName: UserProfile['fullName'];
};

// 📚 Publications
export type Publication = InferSelectModel<typeof publications>;
export type Issue = InferSelectModel<typeof volumesIssues>;

export type PaperWithPublication = Pick<Submission, 'id' | 'paperId' | 'status'> & {
    title: Version['title'];
    publication: Publication | null;
};

// 📩 Applications
export type Application = InferSelectModel<typeof applications> & {
    researchInterests?: string[] | undefined;
};
export type NewApplication = InferInsertModel<typeof applications>;

export type ApplicationInterest = InferSelectModel<typeof applicationInterests>;
export type NewApplicationInterest = InferInsertModel<typeof applicationInterests>;

// 📝 Author Dashboard / Details
export type AuthorDashboardSubmission = Pick<Submission, 'id' | 'paperId' | 'status' | 'submittedAt' | 'updatedAt'> & {
    title: Pick<Version, 'title'>['title'] | null;
    paymentStatus: PaymentStatus | null;
    paymentAmount: Pick<Payment, 'amount'>['amount'] | null;
    finalPdfUrl: Pick<Publication, 'finalPdfUrl'>['finalPdfUrl'] | null;
    volumeNumber: Pick<Issue, 'volumeNumber'>['volumeNumber'] | null;
    issueNumber: Pick<Issue, 'issueNumber'>['issueNumber'] | null;
    issueYear: Pick<Issue, 'year'>['year'] | null;
    views: Pick<Publication, 'views'>['views'] | null;
    downloads: Pick<Publication, 'downloads'>['downloads'] | null;
    citations: Pick<Publication, 'citations'>['citations'] | null;
};

export type AuthorSubmissionDetail = Pick<Submission, 'id' | 'paperId' | 'status' | 'submittedAt' | 'updatedAt'> &
    Pick<Version, 'versionNumber' | 'title' | 'abstract' | 'keywords' | 'subjectArea' | 'changelog'> & {
        versionId: Pick<Version, 'id'>['id'];
        files: SubmissionFile[];
        authors: Author[];
        section?: Section | null | undefined;
        reviewerSuggestions?: ReviewerSuggestion[] | undefined;
        reviewComments: Array<Pick<Review, 'commentsToAuthor' | 'decision' | 'submittedAt'> &
            Pick<ReviewAssignment, 'reviewRound' | 'deadline'>>;
        payment: Payment | null | undefined;
        publication: (Publication & Pick<Issue, 'volumeNumber' | 'issueNumber' | 'year'>) | null | undefined;
        zenodoDeposit?: {
            doi: string;
            recordUrl: string;
        } | null | undefined;
    };

// 📬 Correspondence
export type ContactMessage = InferSelectModel<typeof contactMessages>;
export type NewContactMessage = InferInsertModel<typeof contactMessages>;

export type ContactMessageRow = Pick<ContactMessage, 'id' | 'name' | 'email' | 'subject' | 'message' | 'status' | 'createdAt'>;

export type Notification = InferSelectModel<typeof notifications>;

// 📜 System
export type ActivityLog = InferSelectModel<typeof activityLogs>;
export type Setting = InferSelectModel<typeof settings>;
export type EmailTemplate = InferSelectModel<typeof emailTemplates>;
export type NewEmailTemplate = InferInsertModel<typeof emailTemplates>;

// 📰 UI / Public View Types
export type PublishedPaperUI = Pick<Submission, 'status' | 'updatedAt'> &
    Omit<Publication, 'submissionId' | 'issueId'> &
    Pick<Issue, 'volumeNumber' | 'issueNumber' | 'monthRange'> & {
        paperId: Pick<Submission, 'paperId'>['paperId'];
        title: Pick<Version, 'title'>['title'];
        abstract: Pick<Version, 'abstract'>['abstract'];
        keywords: Pick<Version, 'keywords'>['keywords'];
        authorName: Pick<Author, 'name'>['name'];
        authorEmail: Pick<Author, 'email'>['email'] | null;
        affiliation: Pick<Author, 'institution'>['institution'] | null;
        filePath: Pick<Publication, 'finalPdfUrl'>['finalPdfUrl'];
        pdfUrl: Pick<Publication, 'finalPdfUrl'>['finalPdfUrl'];
        pageRange: string | null; // Fully computed UI field (start-end)
        publicationYear: Pick<Issue, 'year'>['year'] | null;
        coAuthors: Author[];
        authorsList: string[];
        competingInterests?: string | null | undefined;
        fundingStatement?: string | null | undefined;
        ethicalApproval?: string | null | undefined;
        supplementaryFiles?: SubmissionFile[] | undefined;
        retractionReason?: string | null | undefined;
        retractionNoticeUrl?: string | null | undefined;
        retractedAt?: Date | string | null | undefined;
        submittedAt?: Date | string | null | undefined;
        acceptedAt?: Date | string | null | undefined;
        sectionTitle?: string | null | undefined;
        sectionIdentifyType?: string | null | undefined;
        issueDatePublished?: Date | string | null | undefined;
        issueTitle?: string | null | undefined;
    };

// 🗺️ Route Param Types (for Next.js [dynamic] pages — derived from schema)
// volume/issue use template literals over the schema integer types so the
// shape stays tied to Issue.volumeNumber / Issue.issueNumber.
export type PaperDetailParams = {
    volume: `volume${Issue['volumeNumber']}`;
    issue: `issue${Issue['issueNumber']}`;
    paperId: Submission['paperId'];
};

// Panel pages that receive a numeric submission ID as a URL string
export type SubmissionIdParam = {
    id: string;
};

export type TrackedManuscript = Pick<Submission, 'id' | 'paperId' | 'status' | 'submittedAt' | 'updatedAt'> & {
    title: Pick<Version, 'title'>['title'];
    authorName: Pick<Author, 'name'>['name'];
    authorEmail: Pick<Author, 'email'>['email'];
    reviewStartedAt: Pick<ReviewAssignment, 'assignedAt'>['assignedAt'] | null;
    reviewerFeedback?: (string | null)[] | undefined;
};

// 🏷️ CRediT (Contributor Roles Taxonomy) Standards
export const CREDIT_ROLES = [
    'Conceptualization',
    'Data Curation',
    'Formal Analysis',
    'Funding Acquisition',
    'Investigation',
    'Methodology',
    'Project Administration',
    'Resources',
    'Software',
    'Supervision',
    'Validation',
    'Visualization',
    'Writing – Original Draft',
    'Writing – Review & Editing',
] as const;

export type CreditRole = (typeof CREDIT_ROLES)[number];

export type ReviewerPerformanceMetrics = {
    userId: string;
    completedReviewsCount: number;
    averageRating: number | null;
    averageTurnaroundDays: number | null;
};

export type ActiveReview = Pick<ReviewAssignment, 'id' | 'status' | 'assignedAt' | 'deadline' | 'reviewRound' | 'submissionId'> &
    Pick<Review, 'decision' | 'commentsToAuthor' | 'submittedAt'> & {
        reviewId?: number | null | undefined;
        editorRating?: number | null | undefined;
        editorRatingRemarks?: string | null | undefined;
        paperId: Pick<Submission, 'paperId'>['paperId'];
        submissionStatus: SubmissionStatus;
        title: Pick<Version, 'title'>['title'];
        reviewerName: Pick<UserProfile, 'fullName'>['fullName'] | null;
        manuscriptPath: Pick<SubmissionFile, 'fileUrl'>['fileUrl'] | null;
        feedbackFilePath: Pick<SubmissionFile, 'fileUrl'>['fileUrl'] | null;
    };

export type UnassignedPaper = Pick<Submission, 'id' | 'paperId'> & {
    title: Pick<Version, 'title'>['title'];
    pdfUrl: Pick<SubmissionFile, 'fileUrl'>['fileUrl'] | null;
    isBlinded?: boolean | undefined;
    reviewerSuggestions?: ReviewerSuggestion[] | undefined;
    sectionTitle?: string | null | undefined;
};

// 🧪 Common Return Types (Re-exported from @/lib/action-response)
export type { ActionResponse, SuccessResponse, ErrorResponse } from "@/lib/action-response";

// ⚙️ Journal Settings
export interface JournalSettings {
    journalName?: string;
    journalShortName?: string;
    publisherName?: string;
    issnNumber?: string;
    apcInr?: string;
    apcUsd?: string;
    apcDescription?: string;
    startingYear?: string;
    publicationFrequency?: string;
    journalLanguage?: string;
    udyamRegistration?: string;
    journalSubject?: string;
    supportEmail?: string;
    supportPhone?: string;
    officeAddress?: string;
    templateUrl?: string;
    copyrightUrl?: string;
    publicationFormat?: string;
    journalWebsite?: string;
    isPromotionActive?: string;
    [key: string]: string | undefined;
}

// 💬 Live Chat Types
export type ChatMessage = InferSelectModel<typeof chatMessages>;
export type NewChatMessage = InferInsertModel<typeof chatMessages>;

export type ChatMessageRow = ChatMessage & {
    senderName?: UserProfile['fullName'] | null;
    receiverName?: UserProfile['fullName'] | null;
};

export type ChatUser = {
    id: User['id'];
    email: User['email'];
    fullName: UserProfile['fullName'];
    role: User['role'];
    lastMessageAt?: string | null;
};

// 🔌 WebSocket Event Types (Strongly coupled with NestJS chat.gateway.ts)
export interface ServerToClientEvents {
    authenticated: (data: { userId: User['id']; role: User['role'] }) => void;
    onlineUsers: (userIds: User['id'][]) => void;
    receiveMessage: (message: ChatMessageRow) => void;
}

export interface ClientToServerEvents {
    sendMessage: (message: ChatMessageRow) => void;
    getOnlineUsers: () => void;
}

// 🔀 Web Push Types
export type PushSubscriptionRow = InferSelectModel<typeof pushSubscriptions>;
export type NewPushSubscriptionRow = InferInsertModel<typeof pushSubscriptions>;

// 📚 Sections (OJS Parity)
export type Section = InferSelectModel<typeof sections>;
export type NewSection = InferInsertModel<typeof sections>;

// 👥 Reviewer Suggestions
export type ReviewerSuggestion = InferSelectModel<typeof reviewerSuggestions>;
export type NewReviewerSuggestion = InferInsertModel<typeof reviewerSuggestions>;

// 📜 Submission Event Log
export type SubmissionEventLogEntry = InferSelectModel<typeof submissionEventLog>;
export type NewSubmissionEventLogEntry = InferInsertModel<typeof submissionEventLog>;
export type SubmissionEventWithActor = SubmissionEventLogEntry & {
    actor: {
        id: string;
        fullName: string;
        role: string;
        photoUrl?: string | null;
    } | null;
};

// 📢 Announcements (OJS Parity)
export type AnnouncementType = InferSelectModel<typeof announcements>['type'];
export type Announcement = InferSelectModel<typeof announcements>;
export type NewAnnouncement = InferInsertModel<typeof announcements>;

// 📄 Static Pages (OJS Parity)
export type StaticPage = InferSelectModel<typeof staticPages>;
export type NewStaticPage = InferInsertModel<typeof staticPages>;

// 🔗 Related Articles (OJS Parity - recommendByAuthor / recommendBySimilarity)
export type RelatedArticle = PublishedPaperUI & {
    matchReason: string;
    matchScore: number;
};

// 📈 Usage Stats & COUNTER Release 5 / SUSHI Types
export type UsageStat = InferSelectModel<typeof usageStats>;
export type NewUsageStat = InferInsertModel<typeof usageStats>;
export type UsageMetricType =
    | 'total_item_investigations'
    | 'unique_item_investigations'
    | 'total_item_requests'
    | 'unique_item_requests';

export interface SushiStatusResponse {
    Description: string;
    Service_Active: boolean;
    Release: string;
}

export interface SushiReportDefinition {
    Report_Name: string;
    Report_ID: string;
    Release: string;
    Report_Description: string;
    Path: string;
}

export interface CounterReportHeader {
    Created: string;
    Created_By: string;
    Customer_ID: string;
    Report_ID: string;
    Release: string;
    Report_Name: string;
    Institution_Name: string;
    Report_Filters: { Name: string; Value: string }[];
    Report_Attributes?: { Name: string; Value: string }[] | undefined;
    Exceptions?: { Code: number; Severity: string; Message: string; Data?: string | undefined }[] | undefined;
}

export interface CounterPerformanceInstance {
    Metric_Type: string;
    Count: number;
}

export interface CounterPerformancePeriod {
    Period: {
        Begin_Date: string;
        End_Date: string;
    };
    Instance: CounterPerformanceInstance[];
}

export interface CounterReportItem {
    Title?: string | undefined;
    Item?: string | undefined;
    Platform: string;
    Publisher?: string | undefined;
    Item_ID: { Type: string; Value: string }[];
    Item_Contributors?: { Type: string; Name: string; Identifier?: string | undefined }[] | undefined;
    Item_Dates?: { Type: string; Value: string }[] | undefined;
    Item_Attributes?: { Type: string; Value: string }[] | undefined;
    Data_Type?: string | undefined;
    Section_Type?: string | undefined;
    YOP?: string | undefined;
    Performance: CounterPerformancePeriod[];
}

export interface CounterR5Response {
    Report_Header: CounterReportHeader;
    Report_Items: CounterReportItem[];
}



