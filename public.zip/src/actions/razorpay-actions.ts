"use server";
import "server-only"

import { razorpay } from "@/lib/razorpay";
import crypto from "crypto";
import { db } from "@/lib/db";
import { payments, submissions, journalSettings, userProfiles, users, submissionVersions } from "@/db/schema";
import { eq, desc, and, sql, inArray } from "drizzle-orm";
import { revalidatePath, updateTag } from "next/cache";
import { CACHE_TAGS } from "@/lib/cache-tags";
import { invalidateAuthorActionsCount, createNotification } from "./notifications";
import { sendEmail, emailTemplates } from "@/lib/mail";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";

type CreateOrderResponse =
    | { success: true; order: { id: string; amount: number; currency: string; key: string | undefined } }
    | { success: false; error: string };

export async function createRazorpayOrder(submissionId: number, paperId: string): Promise<CreateOrderResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user) return { success: false, error: "Authentication required" };

        // Verify the requesting user owns this submission (or is staff)
        const [subRecord] = await db.select({ correspondingAuthorId: submissions.correspondingAuthorId })
            .from(submissions)
            .where(eq(submissions.id, submissionId))
            .limit(1);

        if (!subRecord) return { success: false, error: "Submission not found." };

        const isAuthorized =
            session.user.role === 'admin' ||
            session.user.role === 'editor' ||
            session.user.id === subRecord.correspondingAuthorId;

        if (!isAuthorized) return { success: false, error: "Unauthorized." };

        // 1. Check if admin already initialized a payment record with a custom/discounted amount
        const [existingPaymentRecord] = await db.select({ amount: payments.amount })
            .from(payments)
            .where(eq(payments.submissionId, submissionId))
            .limit(1);

        // 2. Fall back to journal-wide APC only if no record exists
        const [journalRow] = await db.select({ apcInr: journalSettings.apcInr })
            .from(journalSettings)
            .where(eq(journalSettings.id, 1))
            .limit(1);

        // Priority: admin-set amount (discount scenario) → journal setting → hardcoded default
        const amountInINR = existingPaymentRecord?.amount?.toString() ?? journalRow?.apcInr ?? '2500';
        let parsedAmount = parseInt(amountInINR);
        if (isNaN(parsedAmount)) {
            parsedAmount = 2500;
        }
        const amount = parsedAmount * 100; // Razorpay expects amount in paise

        // 2. Create Razorpay order
        const options = {
            amount: amount,
            currency: "INR",
            receipt: `receipt_${paperId}_${Date.now()}`,
            notes: {
                submission_id: String(submissionId),
                paper_id: paperId
            }
        };

        const order = await razorpay.orders.create(options);

        // 3. Create/Update payment record in DB with the Razorpay order ID
        const existingPayments = await db.select()
            .from(payments)
            .where(eq(payments.submissionId, submissionId))
            .limit(1);
 
        if (existingPayments.length > 0) {
            await db.update(payments)
                .set({ 
                    transactionId: order.id, 
                    currency: 'INR', 
                    amount: amountInINR 
                })
                .where(eq(payments.submissionId, submissionId));
        } else {
            await db.insert(payments).values({
                submissionId: submissionId,
                amount: amountInINR,
                currency: 'INR',
                status: 'pending',
                transactionId: order.id
            });
        }

        return {
            success: true,
            order: {
                id: order.id,
                amount: order.amount as number,
                currency: order.currency,
                key: process.env['RAZORPAY_KEY_ID']
            }
        };
    } catch (error) {
        console.error("Create Razorpay Order Error:", error);
        return { success: false, error: "An unexpected error occurred. Please try again." };
    }
}

export async function verifyRazorpayPayment(data: {
    razorpayOrderId: string;
    razorpayPaymentId: string;
    razorpaySignature: string;
    submissionId: number;
}) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user) return { success: false, error: "Authentication required" };
 
        const { razorpayOrderId, razorpayPaymentId, razorpaySignature, submissionId } = data;
 
        const secret = process.env['RAZORPAY_KEY_SECRET'];
        if (!secret) {
            console.error("RAZORPAY_KEY_SECRET is not set");
            return { success: false, error: "Payment configuration error. Please contact support." };
        }
 
        const generatedSignature = crypto
            .createHmac("sha256", secret)
            .update(razorpayOrderId + "|" + razorpayPaymentId)
            .digest("hex");
 
        if (generatedSignature !== razorpaySignature) {
            return { success: false, error: "Invalid payment signature" };
        }
 
        // 1.5 Verify that this order actually belongs to this submission
        const existingPayment = await db.select()
            .from(payments)
            .where(and(
                eq(payments.transactionId, razorpayOrderId),
                eq(payments.submissionId, submissionId)
            ))
            .limit(1);

        if (existingPayment.length === 0) {
            return { success: false, error: "Payment record mismatch. Verification failed." };
        }

        let authorId: string | null = null;
        // 2. Update Payment Status & Submission Status in DB
        const invoiceNum = `INV-${new Date().getFullYear()}-${submissionId.toString().padStart(5, '0')}`;
        await db.transaction(async (tx) => {
            await tx.update(payments)
                .set({ 
                    status: 'paid', 
                    transactionId: razorpayPaymentId, 
                    paidAt: new Date(),
                    invoiceNumber: sql`COALESCE(${payments.invoiceNumber}, ${invoiceNum})`
                })
                .where(
                    and(
                        eq(payments.submissionId, submissionId),
                        eq(payments.status, 'pending')
                    )
                );

            const [submission] = await tx.select({ 
                status: submissions.status,
                correspondingAuthorId: submissions.correspondingAuthorId
            })
                .from(submissions)
                .where(eq(submissions.id, submissionId))
                .limit(1);

            if (submission) {
                authorId = submission.correspondingAuthorId;
                if (submission.status !== 'published' && submission.status !== 'retracted' && submission.status !== 'rejected') {
                    await tx.update(submissions)
                        .set({ 
                            status: 'accepted',
                            updatedAt: new Date()
                        })
                        .where(eq(submissions.id, submissionId));
                }
            }
        });

        if (authorId) {
            await invalidateAuthorActionsCount(authorId);
        }

        // 4. Notify Author
        try {
            const subData = await db.select({
                authorName: userProfiles.fullName,
                authorEmail: users.email,
                title: submissionVersions.title,
                paperId: submissions.paperId
            })
            .from(submissions)
            .innerJoin(users, eq(submissions.correspondingAuthorId, users.id))
            .innerJoin(userProfiles, eq(users.id, userProfiles.userId))
            .innerJoin(submissionVersions, eq(submissions.id, submissionVersions.submissionId))
            .where(eq(submissions.id, submissionId))
            .orderBy(desc(submissionVersions.versionNumber))
            .limit(1);

            const sub = subData[0];
            if (sub) {
                if (authorId) {
                    await createNotification({
                        userId: authorId,
                        createdByUserId: session.user.id,
                        type: "payment_verified",
                        priority: "high",
                        message: `Payment successful and verified for manuscript ${sub.paperId}. Your paper is cleared for publication.`,
                        actionLink: `/author/submissions/${submissionId}`,
                        metadata: { submissionId, paperId: sub.paperId }
                    });
                }

                const template = await emailTemplates.paymentVerified(sub.authorName, sub.title, sub.paperId);
                // Fire-and-forget — payment is already recorded, email failure is non-critical
                sendEmail({ to: sub.authorEmail, subject: template.subject, html: template.html })
                    .catch(e => console.error("Payment confirmation email failed:", e));

                // Notify Editorial & Finance Staff
                const [payRow] = await db.select({
                    amount: payments.amount,
                    currency: payments.currency,
                }).from(payments).where(eq(payments.submissionId, submissionId)).limit(1);

                const staff = await db.select({ email: users.email }).from(users).where(inArray(users.role, ['admin', 'editor']));
                const alertTemplate = await emailTemplates.paymentReceivedAlert(
                    sub.title || 'Untitled',
                    sub.paperId || '',
                    sub.authorName || 'Author',
                    payRow?.amount || '0.00',
                    payRow?.currency || 'INR',
                    razorpayPaymentId,
                    submissionId
                );
                await Promise.allSettled(staff.map(s => sendEmail({
                    to: s.email,
                    subject: alertTemplate.subject,
                    html: alertTemplate.html,
                })));
            }
        } catch (emailErr) {
            console.error("Failed to send payment verification email:", emailErr);
        }

        if (submissionId) {
            updateTag(CACHE_TAGS.SUBMISSION(submissionId));
        }
        updateTag(CACHE_TAGS.SUBMISSIONS);
        revalidatePath('/track');
        revalidatePath('/admin');
        revalidatePath('/admin/submissions');
        revalidatePath(`/admin/submissions/${submissionId}`);
        revalidatePath('/reviewer');
        revalidatePath('/editor');

        return { success: true };
    } catch (error) {
        console.error("Verify Razorpay Payment Error:", error);
        return { success: false, error: "An unexpected error occurred. Please try again." };
    }
}
