"use server";
import "server-only"

import { db } from "@/lib/db";
import {
    submissions,
    volumesIssues,
    publications,
    submissionVersions,
    submissionAuthors
} from "@/db/schema";
import {
    type Issue,
    type PaperWithPublication
} from "@/db/types";
import {
    type ActionResponse,
    actionSuccess,
    actionError,
    serverError
} from "@/lib/action-response";
import { eq, and, sql, desc, count, inArray, asc } from "drizzle-orm";
import { revalidatePath, updateTag, cacheLife, cacheTag } from "next/cache";
import { getSettingsData } from "./settings";
import { CACHE_TAGS } from "@/lib/cache-tags";
import { cacheLogger } from "@/lib/cache-logger";
import { sendEmail, emailTemplates } from "@/lib/mail";
import { downloadFileFromStorage, triggerPdfBranding } from "@/lib/fs-utils";
import { getSubmissionById } from "./submissions";
import { createNotification, invalidateAuthorActionsCount } from "./notifications";
import { logSubmissionEvent } from "./event-log";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { headers } from "next/headers";
import { checkRateLimit } from "@/lib/rate-limit";
import { submitToIndexNow } from "@/lib/indexnow";
import { isBot } from "@/lib/bot-detector";


/**
 * Create a new volume/issue
 */
export async function createVolumeIssue(formData: FormData): Promise<ActionResponse> {
    const session = await getServerSession(authOptions);
    if (!session?.user || session.user.role !== 'admin') {
        return actionError("Unauthorized");
    }

    const volume = parseInt(formData.get('volume') as string);
    const issue = parseInt(formData.get('issue') as string);
    const year = parseInt(formData.get('year') as string);
    const monthRange = formData.get('monthRange') as string;

    if (isNaN(volume) || isNaN(issue) || isNaN(year)) {
        return actionError("Volume, Issue, and Year must be valid numbers");
    }

    try {
        // 1. Check for duplicates
        const existing = await db.select().from(volumesIssues).where(and(
            eq(volumesIssues.volumeNumber, volume),
            eq(volumesIssues.issueNumber, issue),
            eq(volumesIssues.year, year)
        )).limit(1);

        if (existing.length > 0) {
            return actionError("Volume/Issue already exists for this year.");
        }

        await db.insert(volumesIssues).values({
            volumeNumber: volume,
            issueNumber: issue,
            year: year,
            monthRange: monthRange,
            status: 'open'
        });
        revalidatePath('/admin/publications');
        cacheLogger.invalidation(CACHE_TAGS.PUBLICATIONS, "createVolumeIssue");
        updateTag(CACHE_TAGS.PUBLICATIONS);
        updateTag(CACHE_TAGS.ARCHIVES);
        updateTag(CACHE_TAGS.LATEST_ISSUE);
        return actionSuccess();
    } catch (error) {
        console.error("Create Publication Error:", error);
        return serverError(error, "create publication");
    }
}

/**
 * Fetch all volumes and issues with paper counts (Admin / Editor panel)
 */
export async function getVolumesIssues(): Promise<ActionResponse<(Issue & { paperCount: number })[]>> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
            return actionError("Unauthorized");
        }

        const rows = await db.select({
            vi: volumesIssues,
            paperCount: count(submissions.id)
        })
            .from(volumesIssues)
            .leftJoin(submissions, eq(submissions.issueId, volumesIssues.id))
            .groupBy(volumesIssues.id)
            .orderBy(desc(volumesIssues.year), desc(volumesIssues.volumeNumber), desc(volumesIssues.issueNumber));

        const data = rows.map(r => ({
            ...r.vi,
            paperCount: r.paperCount
        }));
        return actionSuccess(data);
    } catch (error) {
        console.error("Fetch Volumes/Issues Error:", error);
        return serverError<(Issue & { paperCount: number })[]>(error, "fetch issues");
    }
}

/**
 * Get the latest published issue
 */
export async function getLatestPublishedIssue(): Promise<ActionResponse<Issue>> {
    'use cache'
    cacheLife('archive')
    cacheTag(CACHE_TAGS.PUBLICATIONS, CACHE_TAGS.LATEST_ISSUE)

    try {
        cacheLogger.miss(CACHE_TAGS.PUBLICATIONS, "getLatestPublishedIssue");
        const rows = await db.select()
            .from(volumesIssues)
            .where(eq(volumesIssues.status, 'published'))
            .orderBy(desc(volumesIssues.year), desc(volumesIssues.volumeNumber), desc(volumesIssues.issueNumber))
            .limit(1);
        if (!rows[0]) return actionError<Issue>("No published issues found");
        return actionSuccess(rows[0]);
    } catch (error) {
        cacheLogger.error(CACHE_TAGS.PUBLICATIONS, error);
        return serverError<Issue>(error, "fetch issue");
    }
}

/**
 * Assign a paper to an issue, brand its PDF, and update its status appropriately
 */
export async function assignPaperToIssue(
    submissionId: number,
    issueId: number,
    startPage?: number,
    endPage?: number,
    customDoi?: string | null,
    doiProviderInput?: 'none' | 'crossref' | 'zenodo' | 'custom'
): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return actionError("Unauthorized");
        }

        // 1. Fetch Composite Submission Details OUTSIDE transaction
        const subRes = await getSubmissionById(submissionId);
        if (!subRes.success || !subRes.data) {
            return actionError(subRes.error || "Submission not found");
        }
        const submission = subRes.data;

        // 2. Enforce status gate — only accepted/published papers can be assigned
        if (submission.status !== 'accepted' && submission.status !== 'published') {
            return actionError("Manuscript must be officially 'Accepted' before issue assignment.");
        }

        // 3. Resolve PDF & Issue details OUTSIDE transaction
        const latestPdf = submission.allFiles.find(f => f.fileType === 'pdfVersion') ||
                          submission.allFiles.find(f => f.fileType === 'mainManuscript');
        if (!latestPdf?.fileUrl) {
            return actionError("No valid manuscript file found for publication packaging.");
        }

        const [issue] = await db.select().from(volumesIssues).where(eq(volumesIssues.id, issueId));
        if (!issue) {
            return actionError("Target publication cycle not found.");
        }

        const isIssuePublished = issue.status === 'published';
        const settings = await getSettingsData();

        // 4. Auto-Page Numbering Logic (outside transaction)
        let finalStartPage = startPage;
        let finalEndPage = endPage;

        if (finalStartPage === undefined || finalEndPage === undefined) {
            const [maxPageRow] = await db.select({
                lastPage: sql<number>`MAX(${publications.endPage})`
            }).from(publications).where(eq(publications.issueId, issueId));

            const lastPage = maxPageRow?.lastPage || 0;
            if (finalStartPage === undefined) finalStartPage = lastPage + 1;
            const startNum = finalStartPage as number;
            if (finalEndPage === undefined) {
                try {
                    const pdfBytes = await downloadFileFromStorage(latestPdf.fileUrl);
                    const { PDFDocument } = await import('pdf-lib');
                    const pdfDoc = await PDFDocument.load(pdfBytes);
                    finalEndPage = startNum + pdfDoc.getPageCount() - 1;
                } catch (pdfErr) {
                    console.error("Failed to read PDF for page count:", pdfErr);
                    finalEndPage = startNum;
                }
            }
        }
        const confirmedStartPage = finalStartPage as number;
        const confirmedEndPage = finalEndPage as number;

        // 5. Selective DOI Resolution Logic
        const doiPrefix = settings['doiPrefix'] ? settings['doiPrefix'].trim() : "10.68139";
        const doiMode = settings['doiAssignmentMode'] || 'manual';

        let resolvedDoi: string | null = null;
        if (customDoi !== undefined) {
            // Admin explicitly provided or cleared DOI
            resolvedDoi = customDoi && customDoi.trim().length > 0 ? customDoi.trim() : null;
        } else if (doiMode === 'auto' && doiPrefix.startsWith("10.")) {
            // Auto mode fallback
            resolvedDoi = `${doiPrefix}/${submission.paperId}`;
        } else {
            // Manual / Selective mode: leave unassigned unless explicitly provided
            resolvedDoi = null;
        }

        let resolvedProvider: 'none' | 'crossref' | 'zenodo' | 'custom' = doiProviderInput || 'none';
        if (doiProviderInput) {
            resolvedProvider = doiProviderInput;
        } else if (resolvedDoi) {
            if (resolvedDoi.startsWith(doiPrefix)) {
                resolvedProvider = 'crossref';
            } else if (resolvedDoi.toLowerCase().includes('zenodo')) {
                resolvedProvider = 'zenodo';
            } else {
                resolvedProvider = 'custom';
            }
        } else {
            resolvedProvider = 'none';
        }

        // 6. Generate Branded PDF OUTSIDE transaction (IO operation)
        const brandedFileName = `${submission.paperId}-published.pdf`;
        const brandedRelativePath = `/api/files/published/${brandedFileName}`;
        const cleanInput = latestPdf.fileUrl;

        await triggerPdfBranding(cleanInput, brandedRelativePath, {
            journalName: settings['journalName'] || "IJITEST",
            journalShortName: "IJITEST",
            volume: issue.volumeNumber,
            issue: issue.issueNumber,
            year: issue.year,
            monthRange: issue.monthRange || "",
            issn: settings['issnNumber'] || "3139-6887",
            website: settings['journalWebsite'] || "https://ijitest.org",
            paperId: submission.paperId,
            startPage: confirmedStartPage,
            endPage: confirmedEndPage,
            doi: resolvedDoi,
            license: "Creative Commons Attribution 4.0 International (CC BY 4.0)"
        });

        // 7. Database transaction — only pure DB ops
        const publishedDate = isIssuePublished ? new Date() : null;
        const targetStatus = isIssuePublished ? 'published' : 'accepted';

        await db.transaction(async (tx) => {
            await tx.insert(publications).values({
                submissionId,
                issueId,
                finalPdfUrl: brandedRelativePath,
                startPage: confirmedStartPage,
                endPage: confirmedEndPage,
                doi: resolvedDoi,
                doiProvider: resolvedProvider,
                doiRegistrationStatus: 'none',
                publishedAt: publishedDate
            }).onDuplicateKeyUpdate({
                set: {
                    issueId,
                    finalPdfUrl: brandedRelativePath,
                    startPage: confirmedStartPage,
                    endPage: confirmedEndPage,
                    doi: resolvedDoi,
                    doiProvider: resolvedProvider,
                    publishedAt: publishedDate
                }
            });

            await tx.update(submissions)
                .set({ status: targetStatus, issueId })
                .where(eq(submissions.id, submissionId));
        });

        // 7. Notifications & Search Engine indexing (only if issue is already published)
        if (isIssuePublished) {
            const template = await emailTemplates.manuscriptPublished(
                submission.authorName,
                submission.title,
                submission.paperId,
                issue.volumeNumber,
                issue.issueNumber,
                issue.year
            );
            sendEmail({ to: submission.authorEmail, subject: template.subject, html: template.html })
                .catch(e => console.error("Publication email failed:", e));

            createNotification({
                userId: submission.correspondingAuthorId,
                createdByUserId: session.user.id,
                type: "paper_published",
                priority: "high",
                message: `Congratulations! Your manuscript ${submission.paperId} has been successfully published in Vol ${issue.volumeNumber}, Issue ${issue.issueNumber}.`,
                actionLink: `/article/${submission.paperId}`,
                metadata: { submissionId, paperId: submission.paperId }
            }).catch(e => console.error("In-app publication notification failed:", e));

            const baseUrl = (process.env['NEXT_PUBLIC_APP_URL'] || 'https://ijitest.org').replace(/\/$/, '');
            const paperUrl = `${baseUrl}/current-issue/volume${issue.volumeNumber}/issue${issue.issueNumber}/${submission.paperId}`;
            submitToIndexNow([paperUrl])
                .catch((e: unknown) => console.error("IndexNow submission failed:", e));

            await logSubmissionEvent({
                submissionId,
                eventType: 'paper_published',
                userId: session.user.id,
                description: `Paper published in Volume ${issue.volumeNumber}, Issue ${issue.issueNumber} (pp. ${confirmedStartPage}-${confirmedEndPage})${resolvedDoi ? ` with DOI: ${resolvedDoi}` : ''}.`,
                metadata: {
                    volume: issue.volumeNumber,
                    issue: issue.issueNumber,
                    doi: resolvedDoi,
                    pages: `${confirmedStartPage}-${confirmedEndPage}`,
                }
            });
        } else {
            createNotification({
                userId: submission.correspondingAuthorId,
                createdByUserId: session.user.id,
                type: "paper_accepted",
                priority: "medium",
                message: `Your manuscript ${submission.paperId} has been assigned to Volume ${issue.volumeNumber}, Issue ${issue.issueNumber} and scheduled for publication.`,
                actionLink: `/admin/submissions/${submissionId}`,
                metadata: { submissionId, paperId: submission.paperId }
            }).catch(e => console.error("In-app publication notification failed:", e));

            await logSubmissionEvent({
                submissionId,
                eventType: 'paper_scheduled',
                userId: session.user.id,
                description: `Manuscript assigned to Volume ${issue.volumeNumber}, Issue ${issue.issueNumber} (scheduled for issue release).`,
                metadata: {
                    volume: issue.volumeNumber,
                    issue: issue.issueNumber,
                    pages: `${confirmedStartPage}-${confirmedEndPage}`,
                }
            });
        }

        if (submission.correspondingAuthorId) {
            await invalidateAuthorActionsCount(submission.correspondingAuthorId);
        }
        revalidatePath('/admin/submissions');
        revalidatePath('/admin/publications');
        cacheLogger.invalidation(CACHE_TAGS.PUBLICATIONS, `assignPaperToIssue ${submissionId}`);
        updateTag(CACHE_TAGS.SUBMISSION(submissionId));
        if (submission?.paperId) {
            updateTag(CACHE_TAGS.PAPER(submission.paperId));
        }
        updateTag(CACHE_TAGS.SUBMISSIONS);
        updateTag(CACHE_TAGS.PUBLICATIONS);
        updateTag(CACHE_TAGS.ARCHIVES);
        updateTag(CACHE_TAGS.LATEST_ISSUE);
        return actionSuccess();
    } catch (error) {
        console.error("Assign Paper Error:", error);
        return serverError(error, "assign paper to issue");
    }
}



/**
 * Publish an entire issue and transition all assigned papers to published
 */
export async function publishIssue(id: number): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return actionError("Unauthorized");
        }

        // 1. Fetch the previous latest published issue before publishing the new one
        const prevLatestIssueRows = await db.select()
            .from(volumesIssues)
            .where(eq(volumesIssues.status, 'published'))
            .orderBy(desc(volumesIssues.year), desc(volumesIssues.volumeNumber), desc(volumesIssues.issueNumber))
            .limit(1);
        const prevLatestIssue = prevLatestIssueRows[0];

        const issueRows = await db.select().from(volumesIssues).where(eq(volumesIssues.id, id)).limit(1);
        const issue = issueRows[0];
        if (!issue) return actionError("Issue not found");

        // 2. Fetch papers for the newly published issue
        const issuePapers = await db.select({
            id: submissions.id,
            paperId: submissions.paperId,
            authorId: submissions.correspondingAuthorId
        })
            .from(submissions)
            .where(eq(submissions.issueId, id));

        // 3. Publish the issue and update all assigned papers
        await db.transaction(async (tx) => {
            await tx.update(volumesIssues)
                .set({ status: 'published' })
                .where(eq(volumesIssues.id, id));

            await tx.update(submissions)
                .set({ status: 'published' })
                .where(eq(submissions.issueId, id));

            await tx.update(publications)
                .set({ publishedAt: new Date() })
                .where(eq(publications.issueId, id));
        });

        const baseUrl = (process.env['NEXT_PUBLIC_APP_URL'] || 'https://ijitest.org').replace(/\/$/, '');
        const urlsToSubmit: string[] = [];

        // 4. Send email & in-app notifications and collect URLs for newly published papers
        if (issuePapers.length > 0) {
            for (const paper of issuePapers) {
                urlsToSubmit.push(`${baseUrl}/current-issue/volume${issue.volumeNumber}/issue${issue.issueNumber}/${paper.paperId}`);

                // Fetch full submission details asynchronously for email & notification delivery
                getSubmissionById(paper.id).then(async subRes => {
                    if (subRes.success && subRes.data) {
                        const sub = subRes.data;
                        const template = await emailTemplates.manuscriptPublished(
                            sub.authorName,
                            sub.title,
                            sub.paperId,
                            issue.volumeNumber,
                            issue.issueNumber,
                            issue.year
                        );
                        sendEmail({ to: sub.authorEmail, subject: template.subject, html: template.html })
                            .catch(e => console.error(`Publication email failed for ${paper.paperId}:`, e));

                        createNotification({
                            userId: sub.correspondingAuthorId,
                            createdByUserId: session.user.id,
                            type: "paper_published",
                            priority: "high",
                            message: `Congratulations! Your manuscript ${sub.paperId} has been successfully published in Vol ${issue.volumeNumber}, Issue ${issue.issueNumber}.`,
                            actionLink: `/article/${sub.paperId}`,
                            metadata: { submissionId: sub.id, paperId: sub.paperId }
                        }).catch(e => console.error(`In-app notification failed for ${paper.paperId}:`, e));
                    }
                }).catch(e => console.error(`Failed to fetch submission ${paper.id} for notifications:`, e));
            }
        }

        // 5. Fetch papers for the previous latest issue (which are now archived)
        if (prevLatestIssue && prevLatestIssue.id !== id) {
            const prevIssuePapers = await db.select({
                paperId: submissions.paperId
            })
                .from(submissions)
                .where(eq(submissions.issueId, prevLatestIssue.id));

            if (prevIssuePapers.length > 0) {
                prevIssuePapers.forEach(paper => {
                    urlsToSubmit.push(`${baseUrl}/archives/volume${prevLatestIssue.volumeNumber}/issue${prevLatestIssue.issueNumber}/${paper.paperId}`);
                });
            }
        }

        // 6. Submit all updated URLs to IndexNow (Bing, Yandex, Naver)
        if (urlsToSubmit.length > 0) {
            submitToIndexNow(urlsToSubmit)
                .catch((e: unknown) => console.error("IndexNow batch submission failed:", e));
        }

        revalidatePath('/admin/publications');
        revalidatePath('/admin/submissions');
        issuePapers.forEach(paper => {
            if (paper?.id) updateTag(CACHE_TAGS.SUBMISSION(paper.id));
            if (paper?.paperId) updateTag(CACHE_TAGS.PAPER(paper.paperId));
        });
        updateTag(CACHE_TAGS.SUBMISSIONS);
        updateTag(CACHE_TAGS.PUBLICATIONS);
        updateTag(CACHE_TAGS.ARCHIVES);
        updateTag(CACHE_TAGS.LATEST_ISSUE);
        return actionSuccess();
    } catch (error) {
        console.error("Publish Issue Error:", error);
        return serverError(error, "publish issue");
    }
}

/**
 * Get papers assigned to a specific issue
 */
export async function getPapersByIssueId(issueId: number): Promise<ActionResponse<PaperWithPublication[]>> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return actionError("Unauthorized");
        }

        // Return structured data for the issue listing
        const latestVersions = db.select({
            submissionId: submissionVersions.submissionId,
            maxVersion: sql<number>`MAX(${submissionVersions.versionNumber})`.as('max_version')
        })
            .from(submissionVersions)
            .groupBy(submissionVersions.submissionId)
            .as('lv');

        const rows = await db.select({
            id: submissions.id,
            paperId: submissions.paperId,
            status: submissions.status,
            publication: publications,
            latestVersion: submissionVersions
        })
            .from(submissions)
            .where(eq(submissions.issueId, issueId))
            .leftJoin(publications, eq(submissions.id, publications.submissionId))
            .leftJoin(latestVersions, eq(submissions.id, latestVersions.submissionId))
            .leftJoin(submissionVersions, and(
                eq(submissions.id, submissionVersions.submissionId),
                eq(submissionVersions.versionNumber, latestVersions.maxVersion)
            ));

        const data = rows.map(r => ({
            id: r.id,
            paperId: r.paperId,
            title: r.latestVersion?.title || "Untitled",
            status: r.status,
            publication: r.publication
        }));

        return actionSuccess(data);
    } catch (error) {
        console.error("Get Papers By Issue Error:", error);
        return serverError<PaperWithPublication[]>(error, "fetch papers for issue");
    }
}

/**
 * Unassign a paper from an issue
 */
export async function unassignPaperFromIssue(submissionId: number): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return actionError("Unauthorized");
        }

        const subRows = await db.select({
            id: submissions.id,
            paperId: submissions.paperId
        }).from(submissions).where(eq(submissions.id, submissionId)).limit(1);
        const sub = subRows[0];

        await db.transaction(async (tx) => {
            await tx.delete(publications).where(eq(publications.submissionId, submissionId));
            await tx.update(submissions)
                .set({ issueId: null, status: 'accepted' })
                .where(eq(submissions.id, submissionId));
        });

        revalidatePath('/admin/publications');
        revalidatePath('/admin/submissions');
        cacheLogger.invalidation(CACHE_TAGS.PUBLICATIONS, `unassignPaperFromIssue ${submissionId}`);
        updateTag(CACHE_TAGS.SUBMISSION(submissionId));
        if (sub?.paperId) {
            updateTag(CACHE_TAGS.PAPER(sub.paperId));
        }
        updateTag(CACHE_TAGS.SUBMISSIONS);
        updateTag(CACHE_TAGS.PUBLICATIONS);
        updateTag(CACHE_TAGS.ARCHIVES);
        updateTag(CACHE_TAGS.LATEST_ISSUE);
        return actionSuccess();
    } catch (error) {
        return serverError(error, "unassign paper from issue");
    }
}

/**
 * Update an existing volume/issue
 */
export async function updateVolumeIssue(id: number, formData: FormData): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return actionError("Unauthorized");
        }

        const volume = parseInt(formData.get('volume') as string);
        const issue = parseInt(formData.get('issue') as string);
        const year = parseInt(formData.get('year') as string);
        const monthRange = formData.get('monthRange') as string;

        if (isNaN(volume) || isNaN(issue) || isNaN(year)) {
            return actionError("Volume, Issue, and Year must be valid numbers");
        }

        await db.update(volumesIssues)
            .set({
                volumeNumber: volume,
                issueNumber: issue,
                year: year,
                monthRange: monthRange
            })
            .where(eq(volumesIssues.id, id));

        revalidatePath('/admin/publications');
        cacheLogger.invalidation(CACHE_TAGS.PUBLICATIONS, `updateVolumeIssue ${id}`);
        updateTag(CACHE_TAGS.PUBLICATIONS);
        updateTag(CACHE_TAGS.ARCHIVES);
        updateTag(CACHE_TAGS.LATEST_ISSUE);
        return actionSuccess();
    } catch (error) {
        console.error("Update Publication Error:", error);
        return serverError(error, "update publication");
    }
}

/**
 * Delete a volume/issue (unassigns papers first)
 */
export async function deleteVolumeIssue(id: number): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return actionError("Unauthorized: Admin access required.");
        }

        const papers = await db.select({
            id: submissions.id,
            paperId: submissions.paperId
        }).from(submissions).where(eq(submissions.issueId, id));

        await db.transaction(async (tx) => {
            // 1. Unassign all papers
            await tx.delete(publications).where(eq(publications.issueId, id));
            await tx.update(submissions)
                .set({ issueId: null, status: 'accepted' })
                .where(eq(submissions.issueId, id));

            // 2. Delete issue
            await tx.delete(volumesIssues).where(eq(volumesIssues.id, id));
        });

        papers.forEach(paper => {
            if (paper?.id) updateTag(CACHE_TAGS.SUBMISSION(paper.id));
            if (paper?.paperId) updateTag(CACHE_TAGS.PAPER(paper.paperId));
        });

        return actionSuccess();
    } catch (error) {
        return serverError(error, "delete publication");
    } finally {
        revalidatePath('/admin/publications');
        revalidatePath('/admin/submissions');
        cacheLogger.invalidation(CACHE_TAGS.PUBLICATIONS, `deleteVolumeIssue ${id}`);
        updateTag(CACHE_TAGS.SUBMISSIONS);
        updateTag(CACHE_TAGS.PUBLICATIONS);
        updateTag(CACHE_TAGS.ARCHIVES);
        updateTag(CACHE_TAGS.LATEST_ISSUE);
    }
}

/**
 * Increment view count for a published paper (COUNTER Compliant)
 */
export async function incrementPaperViews(submissionId: number): Promise<ActionResponse> {
    try {
        const headerList = await headers();
        const userAgent = headerList.get("user-agent") || "";
        if (isBot(userAgent)) {
            // COUNTER standard: silently ignore automated spiders and bots
            return actionSuccess();
        }

        const ip = headerList.get("x-forwarded-for") || "127.0.0.1";
        const limit = await checkRateLimit({
            key: `pub:views:${ip}:${submissionId}`,
            max: 5,
            windowMs: 60 * 1000
        });
        if (!limit.allowed) {
            return actionError("Too many view requests");
        }

        const pubRows = await db.select({ id: publications.id })
            .from(publications)
            .where(eq(publications.submissionId, submissionId))
            .limit(1);

        const pub = pubRows[0];
        if (!pub) {
            return actionError("Publication not found");
        }

        const pubId = pub.id;

        await db.update(publications)
            .set({ views: sql`views + 1` })
            .where(eq(publications.submissionId, submissionId));

        // COUNTER R5: Atomic UPSERT for Total Item Investigations
        await db.execute(sql`
            INSERT INTO usage_stats (publication_id, year, month, metric_type, metric_count)
            VALUES (${pubId}, YEAR(CURRENT_DATE), MONTH(CURRENT_DATE), 'total_item_investigations', 1)
            ON DUPLICATE KEY UPDATE metric_count = metric_count + 1
        `);

        // COUNTER R5: Check 24-hour unique investigation window
        const uniqueLimit = await checkRateLimit({
            key: `pub:uniq_view:${ip}:${submissionId}`,
            max: 1,
            windowMs: 24 * 60 * 60 * 1000
        });
        if (uniqueLimit.allowed) {
            await db.execute(sql`
                INSERT INTO usage_stats (publication_id, year, month, metric_type, metric_count)
                VALUES (${pubId}, YEAR(CURRENT_DATE), MONTH(CURRENT_DATE), 'unique_item_investigations', 1)
                ON DUPLICATE KEY UPDATE metric_count = metric_count + 1
            `);
        }

        return actionSuccess();
    } catch (error) {
        console.error("Increment Views Error:", error);
        return actionError("Failed to increment views");
    }
}

/**
 * Increment download count for a published paper (COUNTER Compliant)
 */
export async function incrementPaperDownloads(submissionId: number): Promise<ActionResponse> {
    try {
        const headerList = await headers();
        const userAgent = headerList.get("user-agent") || "";
        if (isBot(userAgent)) {
            // COUNTER standard: silently ignore automated spiders and bots
            return actionSuccess();
        }

        const ip = headerList.get("x-forwarded-for") || "127.0.0.1";
        const limit = await checkRateLimit({
            key: `pub:downloads:${ip}:${submissionId}`,
            max: 5,
            windowMs: 60 * 1000
        });
        if (!limit.allowed) {
            return actionError("Too many download requests");
        }

        const pubRows = await db.select({ id: publications.id })
            .from(publications)
            .where(eq(publications.submissionId, submissionId))
            .limit(1);

        const pub = pubRows[0];
        if (!pub) {
            return actionError("Publication not found");
        }

        const pubId = pub.id;

        await db.update(publications)
            .set({ downloads: sql`downloads + 1` })
            .where(eq(publications.submissionId, submissionId));

        // COUNTER R5: Atomic UPSERT for Total Item Requests
        await db.execute(sql`
            INSERT INTO usage_stats (publication_id, year, month, metric_type, metric_count)
            VALUES (${pubId}, YEAR(CURRENT_DATE), MONTH(CURRENT_DATE), 'total_item_requests', 1)
            ON DUPLICATE KEY UPDATE metric_count = metric_count + 1
        `);

        // COUNTER R5: Check 24-hour unique request window
        const uniqueLimit = await checkRateLimit({
            key: `pub:uniq_dl:${ip}:${submissionId}`,
            max: 1,
            windowMs: 24 * 60 * 60 * 1000
        });
        if (uniqueLimit.allowed) {
            await db.execute(sql`
                INSERT INTO usage_stats (publication_id, year, month, metric_type, metric_count)
                VALUES (${pubId}, YEAR(CURRENT_DATE), MONTH(CURRENT_DATE), 'unique_item_requests', 1)
                ON DUPLICATE KEY UPDATE metric_count = metric_count + 1
            `);
        }

        return actionSuccess();
    } catch (error) {
        console.error("Increment Downloads Error:", error);
        return actionError("Failed to increment downloads");
    }
}

/**
 * Re-runs the PDF branding for an already published paper using the latest settings.
 */
export async function rebrandPaperPdf(submissionId: number): Promise<ActionResponse> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || session.user.role !== 'admin') {
            return actionError("Unauthorized");
        }

        // 1. Fetch Publication & Issue Details
        const pubRows = await db.select({
            pub: publications,
            sub: submissions,
            issue: volumesIssues
        })
            .from(publications)
            .innerJoin(submissions, eq(publications.submissionId, submissions.id))
            .innerJoin(volumesIssues, eq(publications.issueId, volumesIssues.id))
            .where(eq(publications.submissionId, submissionId))
            .limit(1);

        const row = pubRows[0];
        if (!row) return actionError("Publication not found or not published yet.");
        const { pub, sub, issue } = row;

        // 2. Fetch Latest Versions of this submission to get the original unbranded pdf
        const subRes = await getSubmissionById(submissionId);
        if (!subRes.success || !subRes.data) {
            return actionError(subRes.error || "Submission details not found");
        }
        const submission = subRes.data;

        const latestPdf = submission.allFiles.find(f => f.fileType === 'pdfVersion');
        if (!latestPdf) {
            return actionError("Original styled PDF is missing from the submission version records.");
        }

        const settings = await getSettingsData();
        const cleanInput = latestPdf.fileUrl;
        const brandedRelativePath = pub.finalPdfUrl; // Reuse the existing published URL path

        // 3. Trigger branding again on NestJS backend
        await triggerPdfBranding(cleanInput, brandedRelativePath, {
            journalName: settings['journalName'] || "IJITEST",
            journalShortName: "IJITEST",
            volume: issue.volumeNumber,
            issue: issue.issueNumber,
            year: issue.year,
            monthRange: issue.monthRange || "",
            issn: settings['issnNumber'] || "XXXX-XXXX",
            website: settings['journalWebsite'] || "https://ijitest.org",
            paperId: sub.paperId,
            startPage: pub.startPage,
            endPage: pub.endPage,
            doi: pub.doi,
            license: "Creative Commons Attribution 4.0 International (CC BY 4.0)"
        });

        // 4. Update the published date/time in the db or just revalidate
        await db.update(publications)
            .set({ publishedAt: new Date() })
            .where(eq(publications.submissionId, submissionId));

        revalidatePath(`/admin/submissions/${submissionId}`);
        revalidatePath('/admin/submissions');
        cacheLogger.invalidation(CACHE_TAGS.SUBMISSION(submissionId), `rebrandPaperPdf ${submissionId}`);
        
        if (sub.paperId) {
            updateTag(CACHE_TAGS.PAPER(sub.paperId));
        }

        updateTag(CACHE_TAGS.SUBMISSION(submissionId));
        updateTag(CACHE_TAGS.PUBLICATIONS);
        updateTag(CACHE_TAGS.ARCHIVES);
        updateTag(CACHE_TAGS.LATEST_ISSUE);

        return actionSuccess();
    } catch (error) {
        console.error("Re-brand Paper Error:", error);
        return serverError(error, "re-brand paper");
    }
}

/**
 * Update, assign, or remove the DOI of a specific publication.
 * Re-brands the published PDF if it exists so the header/footer reflects the new DOI.
 */
export async function updatePublicationDoi(submissionId: number, doi: string | null): Promise<ActionResponse<{ doi: string | null }>> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
            return actionError("Unauthorized");
        }

        const cleanDoi = doi && doi.trim().length > 0 ? doi.trim() : null;

        // 1. Fetch Publication & Submission Details
        const pubRows = await db.select({
            pub: publications,
            sub: submissions,
            issue: volumesIssues
        })
            .from(publications)
            .innerJoin(submissions, eq(publications.submissionId, submissions.id))
            .innerJoin(volumesIssues, eq(publications.issueId, volumesIssues.id))
            .where(eq(publications.submissionId, submissionId))
            .limit(1);

        const row = pubRows[0];
        if (!row) {
            return actionError("Publication not found for this submission.");
        }
        const { pub, sub, issue } = row;

        // 2. Update DOI in database
        await db.update(publications)
            .set({ doi: cleanDoi })
            .where(eq(publications.submissionId, submissionId));

        // 3. If a published PDF exists, re-brand it with the updated DOI
        const subRes = await getSubmissionById(submissionId);
        if (subRes.success && subRes.data) {
            const latestPdf = subRes.data.allFiles.find(f => f.fileType === 'pdfVersion');
            if (latestPdf && pub.finalPdfUrl) {
                const settings = await getSettingsData();
                try {
                    await triggerPdfBranding(latestPdf.fileUrl, pub.finalPdfUrl, {
                        journalName: settings['journalName'] || "IJITEST",
                        journalShortName: "IJITEST",
                        volume: issue.volumeNumber,
                        issue: issue.issueNumber,
                        year: issue.year,
                        monthRange: issue.monthRange || "",
                        issn: settings['issnNumber'] || "3139-6887",
                        website: settings['journalWebsite'] || "https://ijitest.org",
                        paperId: sub.paperId,
                        startPage: pub.startPage,
                        endPage: pub.endPage,
                        doi: cleanDoi,
                        license: "Creative Commons Attribution 4.0 International (CC BY 4.0)"
                    });
                } catch (brandErr) {
                    console.error("Failed to re-brand PDF during DOI update:", brandErr);
                }
            }
        }

        await logSubmissionEvent({
            submissionId,
            eventType: 'doi_assigned',
            userId: session.user.id,
            description: cleanDoi ? `Official DOI assigned / updated: ${cleanDoi}` : 'DOI removed from paper.',
            metadata: { doi: cleanDoi }
        });

        revalidatePath(`/admin/submissions/${submissionId}`);
        revalidatePath('/admin/submissions');
        revalidatePath('/admin/publications');
        cacheLogger.invalidation(CACHE_TAGS.SUBMISSION(submissionId), `updatePublicationDoi ${submissionId}`);

        if (sub.paperId) {
            updateTag(CACHE_TAGS.PAPER(sub.paperId));
        }

        updateTag(CACHE_TAGS.SUBMISSION(submissionId));
        updateTag(CACHE_TAGS.PUBLICATIONS);
        updateTag(CACHE_TAGS.ARCHIVES);
        updateTag(CACHE_TAGS.LATEST_ISSUE);

        return actionSuccess({ doi: cleanDoi });
    } catch (error) {
        console.error("Update Publication DOI Error:", error);
        return serverError(error, "update publication DOI");
    }
}

/**
 * GENERATE COMPLETE ISSUE FULL-BOOK PDF
 * Concatenates all published papers in an issue with an official Table of Contents.
 */
export async function generateCompleteIssueBook(issueId: number): Promise<ActionResponse<{ fullBookPdfUrl: string; totalPages: number }>> {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user || (session.user.role !== 'admin' && session.user.role !== 'editor')) {
            return actionError("Unauthorized: Admin or Editor access required.");
        }

        const issueRows = await db.select().from(volumesIssues).where(eq(volumesIssues.id, issueId)).limit(1);
        const issue = issueRows[0];
        if (!issue) return actionError("Issue not found");

        // Fetch all publications in this issue
        const pubRows = await db.select({
            publication: publications,
            submission: submissions,
        })
        .from(publications)
        .innerJoin(submissions, and(
            eq(publications.submissionId, submissions.id),
            eq(submissions.status, 'published')
        ))
        .where(eq(publications.issueId, issueId))
        .orderBy(asc(publications.startPage), asc(submissions.paperId));

        if (!pubRows.length) {
            return actionError("No published articles found in this issue to compile.");
        }

        const subIds = pubRows.map(p => p.submission.id);
        const authorsList = await db.select().from(submissionAuthors)
            .where(inArray(submissionAuthors.submissionId, subIds))
            .orderBy(submissionAuthors.orderIndex);

        const versionsList = await db.select().from(submissionVersions)
            .where(inArray(submissionVersions.submissionId, subIds))
            .orderBy(desc(submissionVersions.versionNumber));

        const storageUrl = process.env["STORAGE_SERVICE_URL"] || 'http://localhost:3001';
        const apiKey = process.env["STORAGE_SERVICE_API_KEY"] || '';

        const articlesPayload = pubRows.map(p => {
            const authors = authorsList
                .filter(a => a.submissionId === p.submission.id)
                .map(a => a.name);

            const version = versionsList.find(v => v.submissionId === p.submission.id);

            return {
                paperId: p.submission.paperId,
                title: version?.title || "Untitled Paper",
                authors: authors.length > 0 ? authors : ["Contributing Author"],
                pdfPath: p.publication.finalPdfUrl,
                startPage: p.publication.startPage ?? undefined,
                endPage: p.publication.endPage ?? undefined,
                doi: p.publication.doi ?? undefined,
            };
        });

        const outputPath = `issues/volume-${issue.volumeNumber}-issue-${issue.issueNumber}-fullbook.pdf`;

        const response = await fetch(`${storageUrl}/process/issue-book?outputPath=${encodeURIComponent(outputPath)}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': apiKey,
            },
            body: JSON.stringify({
                journalName: "International Journal of Innovative Trends in Engineering Science and Technology",
                journalShortName: "IJITEST",
                volume: issue.volumeNumber,
                issue: issue.issueNumber,
                year: issue.year,
                monthRange: issue.monthRange || "",
                issn: "2584-XXXX",
                website: "https://ijitest.org",
                articles: articlesPayload,
            }),
        });

        if (!response.ok) {
            const errBody = await response.text();
            throw new Error(`Storage service error: ${errBody}`);
        }

        const result = await response.json();

        // Update database with generated full book PDF path
        await db.update(volumesIssues)
            .set({ fullBookPdfUrl: outputPath })
            .where(eq(volumesIssues.id, issueId));

        updateTag(CACHE_TAGS.PUBLICATIONS);
        updateTag(CACHE_TAGS.ARCHIVES);
        revalidatePath('/archives');
        revalidatePath(`/archives/volume${issue.volumeNumber}/issue${issue.issueNumber}`);
        revalidatePath('/admin/publications');

        return actionSuccess({ fullBookPdfUrl: outputPath, totalPages: result.totalPages });
    } catch (error) {
        console.error("Generate Complete Issue Book Error:", error);
        return serverError(error, "generate complete issue book");
    }
}


