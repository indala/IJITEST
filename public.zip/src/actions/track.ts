"use server";
import "server-only"
 
import { db } from "@/lib/db";
import { submissions, reviews, reviewAssignments, submissionVersions, userProfiles, users, payments } from "@/db/schema";
import { eq, and, min, desc } from "drizzle-orm";
import { type ActionResponse, type TrackedManuscript } from "@/db/types";
import { checkRateLimit } from "@/lib/rate-limit";
 
export async function trackManuscript(paperId: string, authorEmail?: string): Promise<ActionResponse<{ manuscript: TrackedManuscript }>> {
    try {
        const emailPart = (authorEmail || "anon").toLowerCase().trim();
        const rate = await checkRateLimit({
            key: `track:${paperId.toLowerCase().trim()}:${emailPart}`,
            max: 12,
            windowMs: 60_000,
        });
        if (!rate.allowed) {
            return { success: false, error: `Too many tracking requests. Please wait ${rate.retryAfterSeconds} seconds and try again.` };
        }

        // 1. Get the submission and its latest version
        const result = await db.select({
            id: submissions.id,
            paperId: submissions.paperId,
            status: submissions.status,
            submittedAt: submissions.submittedAt,
            updatedAt: submissions.updatedAt,
            title: submissionVersions.title,
            authorName: userProfiles.fullName,
            authorEmail: users.email,
        })
        .from(submissions)
        .innerJoin(submissionVersions, eq(submissions.id, submissionVersions.submissionId))
        .innerJoin(userProfiles, eq(submissions.correspondingAuthorId, userProfiles.userId))
        .innerJoin(users, eq(submissions.correspondingAuthorId, users.id))
        .where(eq(submissions.paperId, paperId))
        .orderBy(desc(submissionVersions.versionNumber))
        .limit(1);
 
        const manuscriptRow = result[0];
 
        if (!manuscriptRow) {
            return { success: false, error: "No manuscript found with these credentials. Please check your Paper ID." };
        }
 
        // Logic for email verification if provided
        if (authorEmail && manuscriptRow.authorEmail.toLowerCase() !== authorEmail.toLowerCase()) {
            return { success: false, error: "Email verification failed. Please check the registered correspondent email." };
        }
 
        // 2. Get the review start date (min assigned_at from assignments)
        const assignments = await db.select({
            reviewStartedAt: min(reviewAssignments.assignedAt)
        })
        .from(reviewAssignments)
        .where(eq(reviewAssignments.submissionId, manuscriptRow.id));

        // 3. Fetch payment record (for custom/discounted amount and status)
        const [paymentRecord] = await db.select({
            amount: payments.amount,
            currency: payments.currency,
            status: payments.status,
        })
        .from(payments)
        .where(eq(payments.submissionId, manuscriptRow.id))
        .limit(1);
 
        const manuscript: TrackedManuscript = {
            ...manuscriptRow,
            reviewStartedAt: assignments[0]?.reviewStartedAt ?? null,
            paymentAmount: paymentRecord?.amount ?? null,
            paymentCurrency: paymentRecord?.currency ?? null,
            paymentStatus: paymentRecord?.status ?? null,
        };
 
        // 3. If rejected, fetch reviewer feedback (commentsToAuthor)
        if (manuscript.status === 'rejected') {
            const feedbackRows = await db.select({ feedback: reviews.commentsToAuthor })
                .from(reviews)
                .innerJoin(reviewAssignments, eq(reviews.assignmentId, reviewAssignments.id))
                .where(
                    and(
                        eq(reviewAssignments.submissionId, manuscript.id),
                        eq(reviewAssignments.status, "completed")
                    )
                );
            manuscript.reviewerFeedback = feedbackRows.map(r => r.feedback).filter(Boolean);
        }
 
        return { success: true, data: { manuscript } };
    } catch (error) {
        console.error("Track Manuscript Error:", error);
        return { success: false, error: "An error occurred while fetching the status. Please try again later." };
    }
}
