"use server";
import "server-only"

import { db } from "@/lib/db";
import {
    submissions,
    submissionFiles,
    submissionVersions,
    submissionAuthors,
    users,
    userProfiles,
    settings,
    userInvitations,
    reviewerSuggestions
} from "@/db/schema";
import { z } from "zod";
import { revalidatePath, updateTag } from "next/cache";
import { invalidateSubmittedSubmissionsCount, createNotification } from "./notifications";
import { logSubmissionEvent } from "./event-log";
import { sendEmail, emailTemplates } from "@/lib/mail";
import { CACHE_TAGS } from "@/lib/cache-tags";
import { eq, inArray } from "drizzle-orm";
import crypto from 'crypto';
import { type ActionResponse, serverError } from "@/lib/action-response";
import { checkRateLimit } from "@/lib/rate-limit";
import { uploadFileToStorage, safeDeleteFile } from "@/lib/fs-utils";
import { MAX_MANUSCRIPT_SIZE, MAX_DOCUMENT_SIZE } from "@/lib/upload-limits";

const phoneRegex = /^[+]?[\d\s\-().]{7,25}$/;

const submissionSchema = z.object({
    authorName: z.string().min(2, "Author name is required").max(255, "Author name cannot exceed 255 characters"),
    authorEmail: z.string().email("Invalid email address").max(255, "Email address cannot exceed 255 characters"),
    authorPhone: z.string()
        .regex(phoneRegex, "Please enter a valid phone number (e.g., +91 9876543210)")
        .max(25, "Phone number cannot exceed 25 characters")
        .optional()
        .or(z.literal('')),
    authorDesignation: z.string().min(2, "Author designation is required").max(255, "Designation cannot exceed 255 characters"),
    affiliation: z.string().min(2, "Affiliation is required").max(500, "Institution name cannot exceed 500 characters"),
    title: z.string().min(10, "Title must be at least 10 characters").max(1000, "Title cannot exceed 1000 characters"),
    abstract: z.string().min(50, "Abstract must be at least 50 characters"),
    keywords: z.string().min(5, "Keywords are required").max(500, "Keywords cannot exceed 500 characters"),
    coAuthors: z.string().optional(), // Still receiving as string from FormData, will parse to Author[]
    termsAccepted: z.string().refine(val => val === "on", {
        message: "You must accept the terms and guidelines"
    }),
});

const coAuthorSchema = z.object({
    name: z.string().min(1).max(255),
    email: z.string().email().max(255),
    phone: z.string().max(25).optional().nullable().or(z.literal('')),
    designation: z.string().max(255).optional().nullable(),
    institution: z.string().max(500).optional().nullable(),
    orcidId: z.string().max(50).optional().nullable(),
    creditRoles: z.array(z.string()).optional().nullable(),
});

/**
 * Handles new manuscript submission with transactional DB-first logic.
 * Ensures data integrity by saving DB records before attempting file uploads.
 */
export async function submitPaper(formData: FormData): Promise<ActionResponse<{ paperId: string }>> {
    const fileCleanupList: string[] = [];
    let invitationToken: string | null = null;

    try {
        // 1. Validation (Mapping snake_case FormData to camelCase Schema)
        const rawData = {
            authorName: formData.get("authorName") as string,
            authorEmail: formData.get("authorEmail") as string,
            authorPhone: formData.get("authorPhone") as string,
            authorDesignation: formData.get("authorDesignation") as string,
            affiliation: formData.get("affiliation") as string,
            title: formData.get("title") as string,
            abstract: formData.get("abstract") as string,
            keywords: formData.get("keywords") as string,
            coAuthors: formData.get("coAuthors") as string,
            termsAccepted: formData.get("termsAccepted") as string,
        };

        const validated = submissionSchema.safeParse(rawData);
        if (!validated.success) return { success: false, error: validated.error?.issues[0]?.message || "Validation failed" };
        const submissionRate = await checkRateLimit({
            key: `submit:${validated.data.authorEmail.toLowerCase().trim()}`,
            max: 2,
            windowMs: 10 * 60_000,
        });
        if (!submissionRate.allowed) {
            return { success: false, error: `Too many submission attempts. Please wait ${submissionRate.retryAfterSeconds} seconds and try again.` };
        }

        const manuscriptFile = formData.get("manuscript") as File;
        const blindedFile = formData.get("blindedManuscript") as File | null;
        const authorOrcid = (formData.get("authorOrcid") as string || "").trim() || null;
        const competingInterests = (formData.get("competingInterests") as string || "").trim() || null;
        const fundingStatement = (formData.get("fundingStatement") as string || "").trim() || null;
        const ethicalApproval = (formData.get("ethicalApproval") as string || "").trim() || null;
        const sectionIdRaw = formData.get("sectionId") as string | null;
        const sectionId = sectionIdRaw ? parseInt(sectionIdRaw) : null;
        const validSectionId = sectionId && !isNaN(sectionId) ? sectionId : null;
        const reviewerSuggestionsRaw = formData.get("reviewerSuggestions") as string | null;
        let authorCreditRoles: string[] | null = null;
        try {
            const rawRoles = formData.get("authorCreditRoles") as string;
            if (rawRoles) {
                const parsed = JSON.parse(rawRoles);
                if (Array.isArray(parsed)) authorCreditRoles = parsed;
            }
        } catch {}

        if (!manuscriptFile || manuscriptFile.size === 0) return { success: false, error: "Manuscript file is mandatory" };

        // .docx ONLY Policy
        const docxMime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        const isDocx = (f: File) =>
            f.name.toLowerCase().endsWith(".docx") ||
            f.type === docxMime;

        if (!isDocx(manuscriptFile)) {
            return { success: false, error: "Strict Policy: Only .docx files are accepted for the Manuscript." };
        }
        if (manuscriptFile.size > MAX_MANUSCRIPT_SIZE) {
            return { success: false, error: "Manuscript file exceeds the 20MB size limit." };
        }
        if (blindedFile && blindedFile.size > 0 && blindedFile.size > MAX_DOCUMENT_SIZE) {
            return { success: false, error: "Blinded manuscript file exceeds the 10MB size limit." };
        }

        // 2. Transactional Database Operations (Save everything BUT don't upload files yet)
        const result = await db.transaction(async (tx) => {
            // A. User/Author Account Management
            const existingUsers = await tx.select().from(users).where(eq(users.email, validated.data.authorEmail)).limit(1);
            let userId: string;

            if (existingUsers.length === 0) {
                userId = crypto.randomUUID();
                invitationToken = crypto.randomBytes(32).toString('hex');
                const expires = new Date();
                expires.setHours(expires.getHours() + 168); // 7-day window for account setup

                await tx.insert(users).values({
                    id: userId,
                    email: validated.data.authorEmail,
                    role: "author",
                    passwordHash: null, // Force setup
                });

                await tx.insert(userProfiles).values({
                    userId,
                    fullName: validated.data.authorName,
                    institute: validated.data.affiliation,
                    phone: validated.data.authorPhone,
                    designation: validated.data.authorDesignation,
                    orcidId: authorOrcid,
                });

                await tx.insert(userInvitations).values({
                    email: validated.data.authorEmail,
                    role: "author",
                    token: invitationToken,
                    expiresAt: expires,
                });
            } else {
                const existingUser = existingUsers[0];
                if (!existingUser) throw new Error("Critical: User not found despite query results.");
                userId = existingUser.id;
                // Update profile with latest info
                await tx.update(userProfiles)
                    .set({
                        fullName: validated.data.authorName,
                        institute: validated.data.affiliation,
                        phone: validated.data.authorPhone,
                        designation: validated.data.authorDesignation,
                        ...(authorOrcid ? { orcidId: authorOrcid } : {})
                    })
                    .where(eq(userProfiles.userId, userId));
            }

            // B. Paper Metadata Generation (Gapless Sequential Locking)
            const currentYear = new Date().getFullYear().toString();
            const seqKey = `submission_sequence_${currentYear}`;

            // Ensure sequence entry exists (no-op on duplicate — preserve existing value)
            await tx.insert(settings)
                .values({ settingKey: seqKey, settingValue: '0' })
                .onDuplicateKeyUpdate({ set: { settingKey: seqKey } });

            // Lock and Fetch current sequence
            const seqResult = await tx.select({ value: settings.settingValue })
                .from(settings)
                .where(eq(settings.settingKey, seqKey))
                .for('update');
            const lastSeq = parseInt(seqResult[0]?.value || "0");
            const newSeq = lastSeq + 1;

            // Update sequence
            await tx.update(settings)
                .set({ settingValue: newSeq.toString() })
                .where(eq(settings.settingKey, seqKey));

            const paperId = `IJITEST-${currentYear}-${String(newSeq).padStart(3, "0")}`;
            const slug = paperId.toLowerCase().replace(/-/g, "");

            // C. Insert Core Submission
            const [submissionInsert] = await tx.insert(submissions).values({
                paperId,
                slug,
                sectionId: validSectionId,
                status: "submitted",
                correspondingAuthorId: userId,
            });
            const subId = submissionInsert.insertId;

            // D. Insert Version 1
            const [versionInsert] = await tx.insert(submissionVersions).values({
                submissionId: subId,
                versionNumber: 1,
                title: validated.data.title,
                abstract: validated.data.abstract,
                keywords: validated.data.keywords,
                competingInterests,
                fundingStatement,
                ethicalApproval,
            });
            const verId = versionInsert.insertId;

            // E. Authors (Lead + Co-authors)
            const authorsList: (typeof submissionAuthors.$inferInsert)[] = [{
                submissionId: subId,
                name: validated.data.authorName,
                email: validated.data.authorEmail,
                phone: validated.data.authorPhone,
                designation: validated.data.authorDesignation,
                institution: validated.data.affiliation,
                orcidId: authorOrcid,
                creditRoles: authorCreditRoles,
                isCorresponding: true,
                orderIndex: 0,
            }];

            if (validated.data.coAuthors) {
                try {
                    const coAuthors = JSON.parse(validated.data.coAuthors);
                    if (Array.isArray(coAuthors)) {
                    coAuthors.forEach((ca, idx) => {
                        const parsed = coAuthorSchema.safeParse(ca);
                        if (!parsed.success || !parsed.data.name || !parsed.data.email) return;
                        const d = parsed.data;
                        authorsList.push({
                            submissionId: subId,
                            name: d.name,
                            email: d.email,
                            phone: d.phone || null,
                            designation: d.designation || null,
                            institution: d.institution || null,
                            orcidId: d.orcidId ? String(d.orcidId).trim() : null,
                            creditRoles: Array.isArray(d.creditRoles) ? d.creditRoles : null,
                            isCorresponding: false,
                            orderIndex: idx + 1,
                        });
                    });
                    }
                } catch {
                    throw new Error("Invalid co-author data format. Please check your inputs.");
                }
            }
            await tx.insert(submissionAuthors).values(authorsList);

            // E.1 Reviewer Suggestions (Author preferred & opposed reviewers)
            if (reviewerSuggestionsRaw) {
                try {
                    const parsedSuggestions = JSON.parse(reviewerSuggestionsRaw);
                    if (Array.isArray(parsedSuggestions)) {
                        for (const sug of parsedSuggestions) {
                            if (!sug.givenName || !sug.email) continue;
                            await tx.insert(reviewerSuggestions).values({
                                submissionId: subId,
                                type: sug.type === 'opposed' ? 'opposed' : 'suggested',
                                givenName: String(sug.givenName).trim(),
                                familyName: sug.familyName ? String(sug.familyName).trim() : null,
                                email: String(sug.email).trim().toLowerCase(),
                                orcidId: sug.orcidId ? String(sug.orcidId).trim() : null,
                                affiliation: sug.affiliation ? String(sug.affiliation).trim() : null,
                                suggestionReason: sug.suggestionReason ? String(sug.suggestionReason).trim() : null,
                            });
                        }
                    }
                } catch (e) {
                    console.error("Failed to parse reviewer suggestions:", e);
                }
            }

            // F. Predictable File URLs (Saved to DB first as requested)
            const timestamp = Date.now();
            const mName = `manuscript_${subId}_${timestamp}.${manuscriptFile.name.split('.').pop()}`;
            const mUrl = `/api/files/submissions/${mName}`;

            const fileRecords: (typeof submissionFiles.$inferInsert)[] = [
                { versionId: verId, fileType: "mainManuscript", fileUrl: mUrl, originalName: manuscriptFile.name, fileSize: manuscriptFile.size }
            ];

            let bName: string | undefined = undefined;
            if (blindedFile && blindedFile.size > 0) {
                bName = `blinded_manuscript_${subId}_${timestamp}.${blindedFile.name.split('.').pop()}`;
                const bUrl = `/api/files/submissions/${bName}`;
                fileRecords.push({
                    versionId: verId,
                    fileType: "blindedManuscript",
                    fileUrl: bUrl,
                    originalName: blindedFile.name,
                    fileSize: blindedFile.size
                });
            }

            await tx.insert(submissionFiles).values(fileRecords);

            return { paperId, subId, mName, bName, cName: undefined, userId };
        });

        // 3. File Uploads (Happens post-transaction to strictly follow "DB First" rule)
        const relativeManuscriptPath = `submissions/${result.mName}`;
        try {
            const manuscriptBuffer = Buffer.from(await manuscriptFile.arrayBuffer());
            await uploadFileToStorage(relativeManuscriptPath, manuscriptBuffer, manuscriptFile.name);
            fileCleanupList.push(relativeManuscriptPath);

            if (result.bName && blindedFile && blindedFile.size > 0) {
                const relativeBlindedPath = `submissions/${result.bName}`;
                const blindedBuffer = Buffer.from(await blindedFile.arrayBuffer());
                await uploadFileToStorage(relativeBlindedPath, blindedBuffer, blindedFile.name);
                fileCleanupList.push(relativeBlindedPath);
            }
        } catch (uploadError) {
            console.error("Upload error:", uploadError);
            // File-system cleanup for orphaned files on storage service
            for (const filePath of fileCleanupList) {
                try { await safeDeleteFile(filePath); } catch { }
            }

            // DB-cleanup for zombie submission
            await db.delete(submissions).where(eq(submissions.id, result.subId));

            // Orphaned Account Cleanup (if user was newly created during this failed session)
            if (invitationToken) {
                const userRes = await db.select().from(users).where(eq(users.email, validated.data.authorEmail)).limit(1);
                const userToCleanup = userRes[0];
                if (userToCleanup && !userToCleanup.passwordHash) {
                    await db.delete(users).where(eq(users.id, userToCleanup.id));
                    await db.delete(userInvitations).where(eq(userInvitations.email, validated.data.authorEmail));
                }
            }
            throw new Error("File upload failed. Our servers might be busy. Please try again.");
        }

        // 4. Notifications
        const baseUrl = process.env['NEXT_PUBLIC_APP_URL'] || 'https://ijitest.org';
        const loginUrl = `${baseUrl}/login`;

        // Author Notification
        const authorTemplate = await emailTemplates.submissionReceived(
            validated.data.authorName,
            validated.data.title,
            result.paperId,
            invitationToken ? `${baseUrl}/auth/setup-password?token=${invitationToken}` : loginUrl
        );

        await sendEmail({
            to: validated.data.authorEmail,
            subject: authorTemplate.subject,
            html: authorTemplate.html
        });

        // Co-author Notifications
        if (validated.data.coAuthors) {
            const coAuthors = JSON.parse(validated.data.coAuthors);
            if (Array.isArray(coAuthors)) {
                await Promise.allSettled(coAuthors.map(async (ca: { name: string; email: string }) => {
                    const coTemplate = await emailTemplates.coAuthorNotification(
                        ca.name,
                        validated.data.title,
                        validated.data.authorName,
                        result.paperId
                    );
                    return sendEmail({
                        to: ca.email,
                        subject: coTemplate.subject,
                        html: coTemplate.html
                    });
                }));
            }
        }

        // Team Notification — role-specific links
        const staff = await db.select({ id: users.id, email: users.email, role: users.role, profile: userProfiles }).from(users)
            .innerJoin(userProfiles, eq(users.id, userProfiles.userId))
            .where(inArray(users.role, ['admin', 'editor']));

        await Promise.allSettled(staff.map(async (s) => {
            const dashboardLink = s.role === 'admin'
                ? `${baseUrl}/admin/submissions/${result.subId}`
                : `${baseUrl}/editor/submissions/${result.subId}`;

            const staffTemplate = await emailTemplates.newSubmissionEditorAlert(
                s.profile.fullName || 'Editor',
                validated.data.title,
                result.paperId,
                validated.data.authorName,
                new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' }),
                dashboardLink
            );

            // Dispatch in-app notification
            const localLink = s.role === 'admin'
                ? `/admin/submissions/${result.subId}`
                : `/editor/submissions/${result.subId}`;

            await createNotification({
                userId: s.id,
                createdByUserId: result.userId,
                type: "submission_created",
                priority: "medium",
                message: `New manuscript submitted: ${result.paperId} - "${validated.data.title}" by ${validated.data.authorName}`,
                actionLink: localLink,
                metadata: { submissionId: result.subId, paperId: result.paperId }
            });

            return sendEmail({
                to: s.email,
                subject: staffTemplate.subject,
                html: staffTemplate.html
            });
        }));

        // Log Typed Submission Event
        await logSubmissionEvent({
            submissionId: result.subId,
            eventType: 'submission_created',
            userId: result.userId,
            description: `Manuscript ${result.paperId} ("${validated.data.title}") submitted by ${validated.data.authorName}.`,
            metadata: {
                sectionId: validSectionId,
                title: validated.data.title,
                author: validated.data.authorName,
            }
        });

        await invalidateSubmittedSubmissionsCount();
        updateTag(CACHE_TAGS.SUBMISSIONS);
        updateTag(CACHE_TAGS.SUBMISSIONS_SUBMITTED_COUNT);
        revalidatePath('/admin/submissions');
        revalidatePath('/editor/submissions');
        return { success: true, data: { paperId: result.paperId } };

    } catch (error) {
        console.error("Submission Failure:", error);
        return serverError(error, "submit paper");
    }
}
