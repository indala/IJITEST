"use server";
import "server-only"

import { db } from "@/lib/db";
import {
    applications,
    users,
    userProfiles,
    userInvitations
} from "@/db/schema";
import {
    type Application
} from "@/db/types";
import {
    type ActionResponse,
    serverError
} from "@/lib/action-response";
import { eq } from "drizzle-orm";
import { revalidatePath, updateTag } from "next/cache";
import { CACHE_TAGS } from "@/lib/cache-tags";
import { emailTemplates, sendEmail, sendEmailWithRetry } from "@/lib/mail";
import crypto from "crypto";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { getAuthorizedSession } from "@/lib/auth/guards";
import { findApplicationById, listApplications } from "@/features/applications/server/application.repository";
import type { ApplicationFilters } from "@/features/applications/types/application.types";
import { getRejectionReasonError } from "@/features/applications/lib/application-decision";

/**
 * Fetch all applications with optional filters
 */
export async function getApplications(filters?: ApplicationFilters): Promise<ActionResponse<Application[]>> {
    try {
        const session = await getAuthorizedSession(["admin", "editor"]);
        if (!session) {
            return { success: false, error: "Unauthorized" };
        }

        return { success: true, data: await listApplications(filters) };
    } catch (error) {
        console.error("Get Applications Error:", error);
        return serverError(error, "fetch applications");
    }
}

export async function getApplicationById(id: number): Promise<ActionResponse<Application>> {
    try {
        const session = await getAuthorizedSession(["admin", "editor"]);
        if (!session) return { success: false, error: "Unauthorized" };

        const application = await findApplicationById(id);
        if (!application) return { success: false, error: "Application not found" };

        return { success: true, data: application };
    } catch (error) {
        console.error("Get Application Error:", error);
        return serverError(error, "fetch application");
    }
}

/**
 * Approve an application and create a user account
 */
export async function approveApplication(id: number): Promise<ActionResponse> {
    const session = await getServerSession(authOptions);
    if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
        return { success: false, error: "Unauthorized: Admin or Editor session required." };
    }
    const adminId = session.user.id;

    try {
        const result = await db.transaction(async (tx) => {
            const appRows = await tx.select().from(applications).where(eq(applications.id, id)).limit(1);
            const app = appRows[0];

            if (!app) return { success: false, error: "Application not found" };
            if (app.status !== 'pending') return { success: false, error: `Application is already ${app.status}` };

            const role = (app.type || 'reviewer') as 'editor' | 'reviewer';
            const invitationToken = crypto.randomBytes(32).toString('hex');
            const expires = new Date();
            expires.setHours(expires.getHours() + 168); // 7-day window for account setup

            const userId = crypto.randomUUID();

            // 1. Create User
            await tx.insert(users).values({
                id: userId,
                email: app.email,
                role: role,
            });

            await tx.insert(userProfiles).values({
                userId: userId,
                fullName: app.fullName,
                designation: app.designation,
                institute: app.institute,
                nationality: app.nationality || 'India',
                photoUrl: app.photoUrl || null,
            });

            // 3. Create Invitation
            await tx.insert(userInvitations).values({
                email: app.email,
                role: role,
                token: invitationToken,
                expiresAt: expires,
                invitedBy: adminId,
            });

            // 4. Update Application Status
            await tx.update(applications)
                .set({
                    status: 'approved',
                    reviewedAt: new Date(),
                    reviewedBy: adminId
                })
                .where(eq(applications.id, id));

            return { success: true, app, role, invitationToken };
        });

        if (!result.success) return result as ActionResponse;

        const { app, role, invitationToken } = result as { app: Application, role: string, invitationToken: string };

        // 5. Send Invitation Email
        const baseUrl = process.env['NEXT_PUBLIC_APP_URL'] || 'https://ijitest.org';
        const setupUrl = `${baseUrl}/auth/setup-password?token=${invitationToken}&ctx=setup`;

        const template = await emailTemplates.boardInvitation(app.fullName, role, setupUrl);

        await sendEmail({
            to: app.email,
            subject: template.subject,
            html: template.html
        });

        updateTag(CACHE_TAGS.EDITORIAL_BOARD);
        revalidatePath("/admin/applications");
        revalidatePath(`/admin/applications/${id}`);
        revalidatePath("/editor/applications");
        revalidatePath(`/editor/applications/${id}`);
        revalidatePath("/admin/users");
        revalidatePath("/editorial-board");
        return { success: true };
    } catch (error) {
        console.error("Approve Application Error:", error);
        return serverError(error, "approve application");
    }
}

/**
 * Reject an application
 */
export async function rejectApplication(id: number, reason: string): Promise<ActionResponse> {
    const session = await getServerSession(authOptions);
    if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
        return { success: false, error: "Unauthorized: Admin or Editor session required." };
    }
    const adminId = session.user.id;

    const reasonError = getRejectionReasonError(reason);
    if (reasonError) {
        return { success: false, error: reasonError };
    }

    try {
        const appRows = await db.select().from(applications).where(eq(applications.id, id)).limit(1);
        const app = appRows[0];
        if (!app) return { success: false, error: "Application not found" };

        if (app.status !== 'pending') {
            return { success: false, error: `Application is already ${app.status}` };
        }

        const role = app.type || 'reviewer';

        // 1. Update status to rejected first (DB is source of truth)
        await db.update(applications)
            .set({
                status: 'rejected',
                reviewedAt: new Date(),
                reviewedBy: adminId
            })
            .where(eq(applications.id, id));

        // 2. Send Rejection Email (fire-and-forget — DB already committed)
        const template = await emailTemplates.boardRejection(app.fullName, role, reason);
        sendEmailWithRetry({
            to: app.email,
            subject: template.subject,
            html: template.html
        }, "board rejection");

        revalidatePath("/admin/applications");
        revalidatePath(`/admin/applications/${id}`);
        revalidatePath("/editor/applications");
        revalidatePath(`/editor/applications/${id}`);
        return { success: true };
    } catch (error) {
        console.error("Reject Application Error:", error);
        return { success: false, error: "Failed to reject application" };
    }
}

/**
 * Bulk approve applications
 */
export async function bulkApproveApplications(ids: number[]): Promise<ActionResponse<{ successCount: number, failCount: number, errors: string[] }>> {
    const session = await getServerSession(authOptions);
    if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
        return { success: false, error: "Unauthorized" };
    }

    const results = { successCount: 0, failCount: 0, errors: [] as string[] };

    for (const id of ids) {
        try {
            const res = await approveApplication(id);
            if (res.success) {
                results.successCount++;
            } else {
                results.failCount++;
                results.errors.push(`ID ${id}: ${res.error}`);
            }
        } catch (e) {
            results.failCount++;
            const message = e instanceof Error ? e.message : String(e);
            results.errors.push(`ID ${id}: ${message}`);
        }
    }

    revalidatePath("/admin/applications");
    revalidatePath("/admin/users");
    return { success: true, data: results };
}

/**
 * Bulk reject applications
 */
export async function bulkRejectApplications(ids: number[], reason: string): Promise<ActionResponse<{ successCount: number, failCount: number, errors: string[] }>> {
    const session = await getServerSession(authOptions);
    if (!session?.user || !['admin', 'editor'].includes(session.user.role)) {
        return { success: false, error: "Unauthorized" };
    }

    const reasonError = getRejectionReasonError(reason);
    if (reasonError) {
        return { success: false, error: reasonError };
    }

    const results = { successCount: 0, failCount: 0, errors: [] as string[] };

    for (const id of ids) {
        try {
            const res = await rejectApplication(id, reason);
            if (res.success) {
                results.successCount++;
            } else {
                results.failCount++;
                results.errors.push(`ID ${id}: ${res.error}`);
            }
        } catch (e) {
            results.failCount++;
            const message = e instanceof Error ? e.message : String(e);
            results.errors.push(`ID ${id}: ${message}`);
        }
    }

    revalidatePath("/admin/applications");
    return { success: true, data: results };
}
