"use client";

import { useCallback, useState, useEffect } from "react";
import {
    FilePlus2,
    UserCheck,
    Users,
    ClipboardCheck,
    RefreshCcw,
    UploadCloud,
    Gavel,
    FileText,
    CheckCircle2,
    ShieldCheck,
    Globe,
    Calendar,
    Tag,
    AlertOctagon,
    FileSignature,
    CircleDot,
    RefreshCw,
    Loader2,
    Clock,
    XCircle,
    AlertCircle,
    CreditCard
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getSubmissionEvents } from "@/actions/event-log";
import type { SubmissionEventWithActor } from "@/db/contracts";
import type { SubmissionEventType, SubmissionEventMetadata } from "@/db/types";

interface SubmissionTimelineProps {
    submissionId: number;
    initialEvents?: SubmissionEventWithActor[];
    className?: string;
}

interface EventConfig {
    label: string;
    icon: React.ElementType;
    color: string;
    bgBadge: string;
}

const EVENT_CONFIGS: Partial<Record<SubmissionEventType, EventConfig>> = {
    submission_created: {
        label: "Manuscript Submitted",
        icon: FilePlus2,
        color: "text-blue-500 border-blue-200 bg-blue-50",
        bgBadge: "bg-blue-500/10 text-blue-700",
    },
    editor_assigned: {
        label: "Editor Assigned",
        icon: UserCheck,
        color: "text-indigo-500 border-indigo-200 bg-indigo-50",
        bgBadge: "bg-indigo-500/10 text-indigo-700",
    },
    reviewer_assigned: {
        label: "Reviewer Assigned",
        icon: Users,
        color: "text-purple-500 border-purple-200 bg-purple-50",
        bgBadge: "bg-purple-500/10 text-purple-700",
    },
    review_submitted: {
        label: "Peer Review Submitted",
        icon: ClipboardCheck,
        color: "text-emerald-500 border-emerald-200 bg-emerald-50",
        bgBadge: "bg-emerald-500/10 text-emerald-700",
    },
    revision_requested: {
        label: "Revision Requested",
        icon: RefreshCcw,
        color: "text-amber-500 border-amber-200 bg-amber-50",
        bgBadge: "bg-amber-500/10 text-amber-700",
    },
    revision_submitted: {
        label: "Revision Submitted",
        icon: UploadCloud,
        color: "text-cyan-500 border-cyan-200 bg-cyan-50",
        bgBadge: "bg-cyan-500/10 text-cyan-700",
    },
    decision_recorded: {
        label: "Editorial Decision",
        icon: Gavel,
        color: "text-violet-500 border-violet-200 bg-violet-50",
        bgBadge: "bg-violet-500/10 text-violet-700",
    },
    paper_accepted: {
        label: "Manuscript Accepted",
        icon: CheckCircle2,
        color: "text-emerald-500 border-emerald-200 bg-emerald-50",
        bgBadge: "bg-emerald-500/10 text-emerald-700",
    },
    paper_rejected: {
        label: "Manuscript Rejected",
        icon: XCircle,
        color: "text-rose-500 border-rose-200 bg-rose-50",
        bgBadge: "bg-rose-500/10 text-rose-700",
    },
    galley_requested: {
        label: "Galley Proof Dispatched",
        icon: FileText,
        color: "text-sky-500 border-sky-200 bg-sky-50",
        bgBadge: "bg-sky-500/10 text-sky-700",
    },
    galley_approved: {
        label: "Galley Proof Approved",
        icon: CheckCircle2,
        color: "text-emerald-500 border-emerald-200 bg-emerald-50",
        bgBadge: "bg-emerald-500/10 text-emerald-700",
    },
    galley_corrections_requested: {
        label: "Galley Corrections Requested",
        icon: AlertCircle,
        color: "text-amber-500 border-amber-200 bg-amber-50",
        bgBadge: "bg-amber-500/10 text-amber-700",
    },
    galley_proof_requested: {
        label: "Galley Proof Dispatched",
        icon: FileText,
        color: "text-sky-500 border-sky-200 bg-sky-50",
        bgBadge: "bg-sky-500/10 text-sky-700",
    },
    galley_proof_responded: {
        label: "Galley Proof Approved",
        icon: CheckCircle2,
        color: "text-emerald-500 border-emerald-200 bg-emerald-50",
        bgBadge: "bg-emerald-500/10 text-emerald-700",
    },
    copyright_uploaded: {
        label: "Copyright Agreement Uploaded",
        icon: ShieldCheck,
        color: "text-teal-500 border-teal-200 bg-teal-50",
        bgBadge: "bg-teal-500/10 text-teal-700",
    },
    payment_verified: {
        label: "Payment Verified",
        icon: CreditCard,
        color: "text-emerald-600 border-emerald-300 bg-emerald-50",
        bgBadge: "bg-emerald-600/15 text-emerald-800 font-bold",
    },
    paper_published: {
        label: "Manuscript Published",
        icon: Globe,
        color: "text-emerald-600 border-emerald-300 bg-emerald-50",
        bgBadge: "bg-emerald-600/15 text-emerald-800 font-bold",
    },
    paper_scheduled: {
        label: "Scheduled for Publication",
        icon: Calendar,
        color: "text-indigo-600 border-indigo-200 bg-indigo-50",
        bgBadge: "bg-indigo-600/10 text-indigo-700",
    },
    doi_assigned: {
        label: "DOI Allocated",
        icon: Tag,
        color: "text-blue-600 border-blue-200 bg-blue-50",
        bgBadge: "bg-blue-600/10 text-blue-700",
    },
    paper_retracted: {
        label: "Paper Retracted",
        icon: AlertOctagon,
        color: "text-rose-600 border-rose-300 bg-rose-50",
        bgBadge: "bg-rose-600/15 text-rose-800 font-bold",
    },
    retraction_issued: {
        label: "Retraction Notice Issued",
        icon: AlertOctagon,
        color: "text-rose-600 border-rose-300 bg-rose-50",
        bgBadge: "bg-rose-600/15 text-rose-800 font-bold",
    },
    corrigendum_issued: {
        label: "Corrigendum Issued",
        icon: FileSignature,
        color: "text-amber-600 border-amber-300 bg-amber-50",
        bgBadge: "bg-amber-600/15 text-amber-800 font-bold",
    },
};

const DEFAULT_EVENT_CONFIG: EventConfig = {
    label: "Editorial Event",
    icon: CircleDot,
    color: "text-muted-foreground border-border bg-muted/40",
    bgBadge: "bg-muted text-muted-foreground",
};

export function SubmissionTimeline({
    submissionId,
    initialEvents,
    className = "",
}: SubmissionTimelineProps) {
    const [events, setEvents] = useState<SubmissionEventWithActor[]>(initialEvents || []);
    const [isLoading, setIsLoading] = useState(!initialEvents);
    const [isRefreshing, setIsRefreshing] = useState(false);

    const handleRefresh = useCallback(async () => {
        setIsRefreshing(true);
        try {
            const res = await getSubmissionEvents(submissionId);
            if (res.success && res.data) {
                setEvents(res.data);
            }
        } catch (error) {
            console.error("Refresh submission events error:", error);
        } finally {
            setIsRefreshing(false);
        }
    }, [submissionId]);

    useEffect(() => {
        if (initialEvents) return;
        let isMounted = true;
        void getSubmissionEvents(submissionId)
            .then((res) => {
                if (!isMounted) return;
                if (res.success && res.data) {
                    setEvents(res.data);
                }
                setIsLoading(false);
            })
            .catch((error) => {
                console.error("Fetch submission events error:", error);
                if (isMounted) setIsLoading(false);
            });

        return () => {
            isMounted = false;
        };
    }, [submissionId, initialEvents]);

    const formatEventTime = (dateInput: Date | string | null | undefined) => {
        if (!dateInput) return "Recently";
        const d = new Date(dateInput);
        return d.toLocaleDateString(undefined, {
            month: "short",
            day: "numeric",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
        });
    };

    return (
        <Card className={`border-border/60 shadow-xs bg-card ${className} `}>
            <CardHeader className="p-5 pb-3 border-b border-border/40 flex flex-row items-center justify-between">
                <div className="space-y-0.5">
                    <CardTitle className="font-bold flex items-center gap-2">
                        <Clock className="w-4 h-4 text-primary" />
                        Submission History & Audit Timeline
                    </CardTitle>
                    <CardDescription className="text-body-sm">
                        Chronological record of editorial workflows, author submissions, peer reviews, and status changes.
                    </CardDescription>
                </div>
                <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleRefresh}
                    disabled={isRefreshing || isLoading}
                    className="h-8 px-2 text-caption text-muted-foreground hover:text-foreground"
                    title="Refresh Timeline"
                >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""} `} />
                </Button>
            </CardHeader>

            <CardContent className="p-5 pt-6">
                {isLoading ? (
                    <div className="py-12 flex flex-col items-center justify-center text-muted-foreground gap-2">
                        <Loader2 className="w-6 h-6 animate-spin text-primary" />
                        <p className="font-medium">Loading event timeline...</p>
                    </div>
                ) : events.length === 0 ? (
                    <div className="py-8 text-center text-muted-foreground space-y-1">
                        <Clock className="w-8 h-8 mx-auto opacity-30 mb-2" />
                        <p className="font-semibold">No timeline events recorded yet.</p>
                        <p className="text-caption opacity-70">
                            Milestone events such as reviews, editorial decisions, and revisions will be displayed here.
                        </p>
                    </div>
                ) : (
                    <div className="relative pl-6 space-y-6 before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-border/60">
                        {events.map((evt, idx) => {
                            const config = EVENT_CONFIGS[evt.eventType] || DEFAULT_EVENT_CONFIG;
                            const IconComponent = config.icon;

                            return (
                                <div key={evt.id || idx} className="relative group">
                                    {/* Timeline Marker Dot / Icon */}
                                    <div className={`absolute -left-6 top-0.5 w-6 h-6 rounded-full border flex items-center justify-center shadow-xs transition-transform group-hover:scale-110 ${config.color} `}>
                                        <IconComponent className="w-3 h-3" />
                                    </div>

                                    {/* Event Body */}
                                    <div className="space-y-1 bg-muted/20 border border-border/40 rounded-xl p-3.5 transition-colors hover:bg-muted/40">
                                        <div className="flex flex-wrap items-center justify-between gap-2">
                                            <div className="flex items-center gap-2">
                                                <Badge variant="outline" className={`text-badge font-bold tracking-tight px-2 py-0.5 ${config.bgBadge} `}>
                                                    {config.label}
                                                </Badge>
                                                {evt.actor?.role ? (
                                                    <span className="text-label font-semibold text-muted-foreground uppercase tracking-wider">
                                                        [{evt.actor.role}]
                                                    </span>
                                                ) : null}
                                            </div>
                                            <span className="text-meta text-muted-foreground font-mono">
                                                {formatEventTime(evt.createdAt)}
                                            </span>
                                        </div>

                                        <p className="text-foreground font-medium m-0 leading-relaxed pt-1">
                                            {evt.description}
                                        </p>

                                        {/* Actor Name if present */}
                                        {evt.actor?.fullName ? (
                                            <p className="text-caption text-muted-foreground m-0">
                                                By: <span className="font-semibold text-foreground/80">{evt.actor.fullName}</span>
                                            </p>
                                        ) : null}

                                        {/* Metadata attributes if any */}
                                        {Boolean(evt.metadata) && typeof evt.metadata === 'object' && Object.keys(evt.metadata as object).length > 0 ? (
                                            <div className="flex flex-wrap gap-1.5 pt-1.5 border-t border-border/30 mt-2">
                                                {Object.entries(evt.metadata as SubmissionEventMetadata).map(([key, val]) => {
                                                    if (val === null || val === undefined || typeof val === 'object') return null;
                                                    return (
                                                        <span
                                                            key={key}
                                                            className="text-meta font-mono px-1.5 py-0.5 rounded bg-card border border-border/50 text-muted-foreground"
                                                        >
                                                            {key}: <strong className="text-foreground">{String(val)}</strong>
                                                        </span>
                                                    );
                                                })}
                                            </div>
                                        ) : null}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
