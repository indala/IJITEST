"use client";

import { Trash2, Loader2, AlertTriangle, XCircle } from "lucide-react";
import { deleteSubmission } from "@/actions/submissions";
import { useActionState, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import type { ActionResponse } from "@/db/contracts";

interface DeleteSubmissionButtonProps {
    submissionId: number;
    status?: string;
    variant?: "icon" | "full";
}

export default function DeleteSubmissionButton({ submissionId, status, variant = "icon" }: DeleteSubmissionButtonProps) {
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [errorOpen, setErrorOpen] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");

    const isRestricted = status === 'paid' || status === 'published';

    const [, deleteAction, isDeleting] = useActionState<ActionResponse, FormData>(
        async (_prev, _formData) => {
            if (isRestricted) {
                setErrorMessage("This submission is marked as paid or published and cannot be deleted from the active registry.");
                setErrorOpen(true);
                return { success: false, error: "Restricted" };
            }

            const res = await deleteSubmission(submissionId);
            if (res.success) {
                if (variant === "full") {
                    router.push("/admin/submissions");
                } else {
                    router.refresh();
                }
                setOpen(false);
            } else {
                setErrorMessage(res.error || "Failed to terminate the submission node.");
                setErrorOpen(true);
            }
            return res;
        },
        { success: false, error: "" }
    );

    const loading = isDeleting;

    const trigger = variant === "full" ? (
        <Button
            variant="outline"
            disabled={loading || isRestricted}
            className="w-full h-14 gap-3 border-destructive/20 text-destructive font-black tracking-[0.2em] rounded-2xl hover:bg-destructive/10 transition-all shadow-inner cursor-pointer"
        >
            {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
                <Trash2 className="w-5 h-5" />
            )}
            {isRestricted ? 'Termination Restricted' : 'Terminate Submission'}
        </Button>
    ) : (
        <Button
            variant="ghost"
            size="icon"
            disabled={loading || isRestricted}
            className="w-12 h-12 bg-destructive/10 text-destructive rounded-xl hover:bg-destructive/20 transition-all disabled:opacity-50 shadow-inner cursor-pointer"
            title={isRestricted ? "Termination Restricted" : "Terminate Node"}
            aria-label={isRestricted ? "Termination Restricted" : "Terminate Node"}
        >
            {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
                <Trash2 className="w-5 h-5" />
            )}
        </Button>
    );

    return (
        <>
            <AlertDialog open={open} onOpenChange={(v) => setOpen(v)}>
                <AlertDialogTrigger asChild>
                    {trigger}
                </AlertDialogTrigger>
                <AlertDialogContent className="rounded-[2.5rem] p-8 bg-white border-red-500/10 shadow-2xl">
                    <AlertDialogHeader className="space-y-4">
                        <div className="w-16 h-16 rounded-2xl bg-red-500/5 border border-red-500/10 flex items-center justify-center text-red-500 shadow-inner mb-2">
                            <AlertTriangle className="w-8 h-8" />
                        </div>
                        <AlertDialogTitle className="text-label font-black text-red-600 tracking-widerer">Critical Termination Protocol</AlertDialogTitle>
                        <AlertDialogDescription className="text-label font-medium text-foreground/80 leading-relaxed tracking-widest">
                            DANGER: This action will permanently erase this manuscript node and all associated technical dossiers from the global server. This operation is irreversible.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter className="pt-6 gap-4">
                        <AlertDialogCancel className="h-14 px-8 rounded-2xl font-black tracking-widest border-border text-foreground/80 hover:bg-muted hover:text-foreground cursor-pointer">
                            Abort Protocol
                        </AlertDialogCancel>
                        <form action={deleteAction}>
                            <AlertDialogAction
                                type="submit"
                                className="h-14 px-8 rounded-2xl bg-red-600 text-white font-black tracking-widest hover:bg-red-700 shadow-xl shadow-red-600/20 cursor-pointer"
                            >
                                Authorize Termination
                            </AlertDialogAction>
                        </form>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <AlertDialog open={errorOpen} onOpenChange={(v) => setErrorOpen(v)}>
                <AlertDialogContent className="rounded-[2.5rem] p-8 bg-white border-primary/5 shadow-2xl">
                    <AlertDialogHeader className="space-y-4">
                        <div className="w-16 h-16 rounded-2xl bg-amber-500/5 border border-amber-500/10 flex items-center justify-center text-amber-500 shadow-inner mb-2">
                            <XCircle className="w-8 h-8" />
                        </div>
                        <AlertDialogTitle className="text-label font-black text-primary tracking-widerer">Access Restricted</AlertDialogTitle>
                        <AlertDialogDescription className="text-label font-medium text-foreground/80 leading-relaxed tracking-widest">
                            {errorMessage}
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter className="pt-6">
                        <Button onClick={() => setErrorOpen(false)} className="w-full h-14 font-black tracking-widest shadow-xl shadow-primary/20 rounded-2xl cursor-pointer">
                            Acknowledge
                        </Button>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
}
