"use client";

import { FileStack, MessageSquareDot } from 'lucide-react';
import Link from 'next/link';
import { getNotificationCounts } from '@/actions/notifications';
import { useSession } from 'next-auth/react';
import { useQuery } from '@tanstack/react-query';
import { notificationKeys } from '@/features/notifications';
import {
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
} from "@/components/ui/tooltip";

const Badge = ({ count }: { count: number }) => (
    <>
        {count > 0 && (
            <span className="absolute -top-1 -right-1 flex h-5 w-5 2xl:h-7 2xl:w-7 items-center justify-center rounded-full bg-primary text-badge font-bold text-white shadow-sm ring-2 ring-background z-20">
                {count > 9 ? '9+' : count}
            </span>
        )}
    </>
);

export default function NotificationCenter() {
    const { data: session } = useSession();
    const userRole = (session?.user as { role?: string })?.role;

    const { data: counts = { messages: 0, submissions: 0 } } = useQuery({
        queryKey: notificationKeys.counts(),
        queryFn: getNotificationCounts,
        enabled: !!session?.user,
        select: (res) => res.success ? res.data : { messages: 0, submissions: 0 },
        refetchInterval: 30000, 
        staleTime: 30000,
    });

    if (!userRole || (userRole !== 'admin' && userRole !== 'editor' && userRole !== 'reviewer' && userRole !== 'author')) return null;

    const submissionLink = userRole === 'reviewer' 
        ? '/reviewer/reviews' 
        : userRole === 'editor' 
            ? '/editor/submissions' 
            : userRole === 'author'
                ? '/author/submissions'
                : '/admin/submissions';
            
    const submissionTooltip = userRole === 'reviewer' 
        ? 'Assignments Pending Feedback' 
        : userRole === 'editor'
            ? 'Submissions Managed by You'
            : userRole === 'author'
                ? 'Submissions Requiring Action'
                : 'New Submissions Pending Screening';

    return (
        <TooltipProvider>
            <div className="flex items-center gap-3">
                {/* Submission Notifications */}
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Link href={submissionLink} className="relative group">
                            <div className="h-10 w-10 2xl:h-12 2xl:w-12 rounded-xl flex items-center justify-center bg-primary/5 text-primary hover:bg-primary/10 transition-all border border-border/50">
                                <FileStack className="w-5 h-5 2xl:w-6 2xl:h-6" />
                                <Badge count={counts.submissions} />
                            </div>
                        </Link>
                    </TooltipTrigger>
                    <TooltipContent className="bg-background border border-primary/10 text-foreground text-body-sm p-3 rounded-xl shadow-2xl">
                        <p className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-secondary animate-pulse" />
                            {counts.submissions} {submissionTooltip}
                        </p>
                    </TooltipContent>
                </Tooltip>

                {/* Message Notifications - Admins/Editors Only */}
                {(userRole === 'admin' || userRole === 'editor') && (
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Link href={`/${userRole}/messages`} className="relative group">
                                <div className="h-10 w-10 2xl:h-12 2xl:w-12 rounded-xl flex items-center justify-center bg-primary/5 text-primary hover:bg-primary/10 transition-all border border-border/50">
                                    <MessageSquareDot className="w-5 h-5 2xl:w-6 2xl:h-6" />
                                    <Badge count={counts.messages} />
                                </div>
                            </Link>
                        </TooltipTrigger>
                        <TooltipContent className="bg-emerald-600 text-white font-bold p-3 rounded-xl shadow-2xl border-none">
                            <p className="flex items-center gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                                {counts.messages} Unread Contact Inquiries
                            </p>
                        </TooltipContent>
                    </Tooltip>
                )}
            </div>
        </TooltipProvider>
    );
}
