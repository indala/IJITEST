import type { ReactNode } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import TopBar from "@/components/layout/TopBar";
import PromotionPopup from "@/features/home/components/PromotionPopup";
import ScrollToTop from "@/components/common/ScrollToTop";


export default async function MainLayout({
    children,
}: {
    children: ReactNode;
}) {
    return (
        <>
            <PromotionPopup />
            <TopBar />
            <Navbar />
            <main className="min-h-screen">
                {children}
            </main>
            <Footer />
            <ScrollToTop />
        </>
    );
}
