import PageHeader from "@/components/layout/PageHeader";
import type { Metadata } from 'next';
import { getPublishedPapers } from '@/actions/archives';
import { getSettingsData } from '@/actions/settings';
import { JsonLd } from '@/components/shared/JsonLd';
import { notFound } from 'next/navigation';
import PaperCard from '@/features/archives/components/PaperCard';
import TrackManuscriptWidget from '@/features/tracking/components/TrackManuscriptWidget';
import { BookOpen, Download } from 'lucide-react';
import { Section } from '@/components/layout/Section';
import { SidebarLayout } from '@/components/layout/SidebarLayout';

export async function generateStaticParams() {
    try {
        const res = await getPublishedPapers();
        if (!res.success || !res.data) {
            return [{ volume: 'volume1', issue: 'issue1' }];
        }
        
        const params = res.data
            .filter(paper => paper.volumeNumber && paper.issueNumber)
            .map(paper => ({
                volume: `volume${paper.volumeNumber}`,
                issue: `issue${paper.issueNumber}`,
            }));

        return params.length > 0 ? params : [{ volume: 'volume1', issue: 'issue1' }];
    } catch (error) {
        console.error("Generate Static Params Error:", error);
        return [{ volume: 'volume1', issue: 'issue1' }];
    }
}

export async function generateMetadata({ params }: { params: Promise<{ volume: string, issue: string }> }): Promise<Metadata> {
    const { volume, issue } = await params;
    const volNumber = parseInt(volume.replace("volume", ""), 10);
    const issueNumber = parseInt(issue.replace("issue", ""), 10);
    const settings = await getSettingsData();
    const baseUrl = settings['journalWebsite'] || 'https://ijitest.org';
    
    if (isNaN(volNumber) || isNaN(issueNumber)) {
        return { title: "Issue Not Found | IJITEST Archives" };
    }
    return {
        title: `Volume ${volNumber}, Issue ${issueNumber} | ${settings['journalName'] || 'IJITEST'} Archives`,
        description: `Browse all peer-reviewed research papers published in Volume ${volNumber}, Issue ${issueNumber} of the ${settings['journalName'] || 'IJITEST'}.`,
        alternates: {
            canonical: `/archives/${volume}/${issue}`,
        },
        openGraph: {
            title: `Volume ${volNumber}, Issue ${issueNumber} - ${settings['journalShortName'] || 'IJITEST'} Archives`,
            description: `Browse peer-reviewed research papers published in Volume ${volNumber}, Issue ${issueNumber}.`,
            url: `${baseUrl}/archives/${volume}/${issue}`,
            type: 'website',
        }
    };
}

export default async function IssuePage({ params }: { params: Promise<{ volume: string, issue: string }> }) {
    const { volume, issue } = await params;
    const volNumber = parseInt(volume.replace("volume", ""), 10);
    const issueNumber = parseInt(issue.replace("issue", ""), 10);

    if (isNaN(volNumber) || isNaN(issueNumber)) notFound();

    const [papersRes, settings] = await Promise.all([
        getPublishedPapers(),
        getSettingsData(),
    ]);
    const papers = papersRes.success && papersRes.data ? papersRes.data : [];

    // Filter papers for this volume and issue
    const issuePapers = papers.filter(p => p.volumeNumber === volNumber && p.issueNumber === issueNumber);

    const activeIssue = issuePapers[0];
    if (!activeIssue) notFound();
    const monthRange = activeIssue.monthRange || "";
    const year = activeIssue.publicationYear || "";
    const hasFullBook = Boolean(activeIssue.fullBookPdfUrl);

    return (
        <div className="bg-background min-h-screen pb-8">
            <PageHeader
                title={`Volume ${volNumber}, Issue ${issueNumber}`}
                description={`Research articles published in ${monthRange} ${year}`}
                breadcrumbs={[
                    { name: 'Home', href: '/' },
                    { name: 'Archives', href: '/archives' },
                    { name: `Volume ${volNumber}`, href: `/archives/${volume}` },
                    { name: `Issue ${issueNumber}`, href: `/archives/${volume}/${issue}` },
                ]}
                scrollOnComplete={true}
            />

            <Section>
                <SidebarLayout
                    sidebarClassName="space-y-4 lg:sticky lg:top-24 h-fit"
                    sidebar={
                        <>
                            {hasFullBook && activeIssue.fullBookPdfUrl && (
                                <div className="bg-card p-5 rounded-2xl border border-border/70 shadow-2xs space-y-3">
                                    <div className="flex items-center gap-2.5">
                                        <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary shrink-0">
                                            <BookOpen className="w-4 h-4" />
                                        </div>
                                        <div>
                                            <h3 className="font-bold text-foreground m-0">Complete Issue</h3>
                                            <p className="text-caption text-muted-foreground m-0">Full Book with Table of Contents</p>
                                        </div>
                                    </div>
                                    <a
                                        href={`/api/files/${activeIssue.fullBookPdfUrl.replace(/^\/+/, '')}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white py-2.5 px-4 rounded-xl font-bold text-body-sm shadow-xs transition-all"
                                    >
                                        <Download className="w-3.5 h-3.5" /> Download Complete Issue (PDF)
                                    </a>
                                </div>
                            )}

                            <div className="bg-card p-1 rounded-2xl border border-border/70 shadow-2xs">
                                <TrackManuscriptWidget />
                            </div>
                        </>
                    }
                >
                    <div className="space-y-4">
                        <div className="flex items-center gap-2 border-l-4 border-secondary pl-3">
                            <h2 className="m-0">Table of Contents</h2>
                        </div>

                        <div className="grid grid-cols-1 gap-3.5 animate-in fade-in slide-in-from-bottom-2 duration-300">
                            {issuePapers.map((paper) => (
                                <PaperCard key={paper.paperId} paper={paper} basePath="/archives" />
                            ))}
                        </div>
                    </div>
                </SidebarLayout>
            </Section>

            <JsonLd
                id="issue-schema"
                data={{
                    "@context": "https://schema.org",
                    "@type": "PublicationIssue",
                    "issueNumber": issueNumber.toString(),
                    "datePublished": year ? `${year}` : undefined,
                    "isPartOf": {
                        "@type": "PublicationVolume",
                        "volumeNumber": volNumber.toString(),
                        "isPartOf": {
                            "@type": "Periodical",
                            "name": settings['journalName'] || "IJITEST",
                            "issn": settings['issnNumber'] || "",
                            "url": settings['journalWebsite'] || "https://ijitest.org"
                        }
                    },
                    "url": `${settings['journalWebsite'] || "https://ijitest.org"}/archives/${volume}/${issue}`
                }}
            />
        </div>
    );
}
