import { getPaperById } from "@/actions/archives";
import PageHeader from "@/components/layout/PageHeader";
import PaperDetailClient from "@/features/archives/components/PaperDetailClient";
import { notFound, redirect } from "next/navigation";
import type { Metadata } from 'next';
import { getSettingsData } from '@/actions/settings';
import { getLatestIssuePapers } from "@/actions/archives";
import { JsonLd } from "@/components/shared/JsonLd";

import type { PublishedPaperUI, PaperDetailParams } from "@/db/types";

export async function generateStaticParams() {
    try {
        const res = await getLatestIssuePapers();
        if (!res.success || !res.data) {
            return [{ volume: 'volume1', issue: 'issue1', paperId: 'placeholder' }];
        }

        const params = res.data
            .filter((paper: PublishedPaperUI) => Boolean(paper.paperId))
            .map((paper: PublishedPaperUI) => ({
                volume: `volume${paper.volumeNumber}`,
                issue: `issue${paper.issueNumber}`,
                paperId: paper.paperId,
            }));

        return params.length > 0 ? params : [{ volume: 'volume1', issue: 'issue1', paperId: 'placeholder' }];
    } catch (error) {
        console.error("Generate Static Params Error:", error);
        return [{ volume: 'volume1', issue: 'issue1', paperId: 'placeholder' }];
    }
}

export async function generateMetadata({ params }: { params: Promise<PaperDetailParams> }): Promise<Metadata> {
    const { volume, issue, paperId } = await params;
    const canonicalPaperId = paperId.toUpperCase();
    const [paperRes, settings] = await Promise.all([
        getPaperById(canonicalPaperId),
        getSettingsData()
    ]);

    const paper = paperRes.success ? paperRes.data : null;

    if (!paper) return { title: 'Article Not Found | IJITEST' };

    const baseUrl = settings['journalWebsite'] || 'https://ijitest.org';
    const allAuthors = paper.authorsList || [];

    const pubYearStr = paper.publicationYear ? String(paper.publicationYear) : '';
    const formattedDate: string = (paper.publishedAt
        ? new Date(paper.publishedAt).toISOString().split('T')[0]
        : pubYearStr) as string;

    const description = paper.abstract ? paper.abstract.substring(0, 160) : '';

    return {
        title: `${paper.title} | IJITEST Current Issue`,
        description: description,
        keywords: paper.keywords,
        openGraph: {
            title: paper.title,
            description: description,
            type: 'article',
            authors: allAuthors,
        },
        other: {
            'citation_title': paper.title,
            'citation_author': allAuthors,
            'citation_publication_date': formattedDate.replace(/-/g, '/'),
            'citation_journal_title': settings['journalName'] || 'IJITEST',
            'citation_issn': settings['issnNumber'] || '',
            'citation_abstract': paper.abstract || '',
            'citation_doi': paper.doi || '',
            'citation_volume': paper.volumeNumber ? String(paper.volumeNumber) : '',
            'citation_issue': paper.issueNumber ? String(paper.issueNumber) : '',
            'citation_firstpage': paper.startPage ? String(paper.startPage) : '',
            'citation_lastpage': paper.endPage ? String(paper.endPage) : '',
            'citation_pdf_url': paper.pdfUrl ? (paper.pdfUrl.startsWith('http') ? paper.pdfUrl : `${baseUrl}${paper.pdfUrl}`) : '',
            'dc.title': paper.title || '',
            'dc.creator': allAuthors,
            'dc.date': formattedDate,
            'dc.subject': paper.keywords || '',
            'dc.description': paper.abstract || '',
            'dc.identifier': paper.doi || '',
            'dc.language': 'en',
            'dc.type': 'Research Article',
        },
        alternates: {
            canonical: `${baseUrl}/current-issue/${volume}/${issue}/${canonicalPaperId}`
        },
        twitter: {
            card: 'summary_large_image',
            title: paper.title,
            description: paper.abstract?.substring(0, 160)
        }
    };
}

export default async function PaperDetailPage({ params }: { params: Promise<PaperDetailParams> }) {
    const { volume, issue, paperId } = await params;

    const canonicalPaperId = paperId.toUpperCase();
    if (canonicalPaperId !== paperId) {
        redirect(`/current-issue/${volume}/${issue}/${canonicalPaperId}`);
    }

    const [paperRes, settings] = await Promise.all([
        getPaperById(canonicalPaperId),
        getSettingsData()
    ]);

    const paper = paperRes.success ? paperRes.data : null;

    if (!paper) notFound();

    const rawBaseUrl = settings['journalWebsite'] || 'https://ijitest.org';
    const baseUrl = rawBaseUrl.startsWith('http') ? rawBaseUrl.replace(/\/$/, '') : `https://${rawBaseUrl.replace(/\/$/, '')}`;
    const allAuthors = paper.authorsList || [];

    return (
        <div className="bg-muted/15 min-h-screen pb-12">
            <PageHeader
                disableBreadcrumbJsonLd
                title="Article Details"
                description={`Volume ${paper.volumeNumber || 1}, Issue ${paper.issueNumber || 1} • Current Issue`}
                breadcrumbs={[
                    { name: 'Home', href: '/' },
                    { name: 'Current Issue', href: '/current-issue' },
                    { name: `Vol. ${paper.volumeNumber || 1}, Issue ${paper.issueNumber || 1}`, href: `/current-issue/${volume}/${issue}` },
                    { name: paper.paperId, href: `/current-issue/${volume}/${issue}/${paperId}` },
                ]}
            />
            <PaperDetailClient paper={paper} mode="current" />

            <JsonLd
                id="scholarly-article"
                data={{
                    "@context": "https://schema.org",
                    "@type": "ScholarlyArticle",
                    "headline": paper.title,
                    "description": paper.abstract,
                    "author": allAuthors.map(author => ({
                        "@type": "Person",
                        "name": author
                    })),
                    "datePublished": paper.publishedAt ? new Date(paper.publishedAt).toISOString() : (paper.publicationYear?.toString() || ""),
                    "publisher": {
                        "@type": "Organization",
                        "name": settings['journalName'] || "IJITEST",
                        "logo": {
                            "@type": "ImageObject",
                            "url": `${baseUrl}/favicon_io/apple-touch-icon.png`
                        }
                    },
                    "isPartOf": {
                        "@type": "ScholarlyJournal",
                        "name": settings['journalName'] || "IJITEST"
                    },
                    "pageStart": paper.startPage?.toString(),
                    "pageEnd": paper.endPage?.toString(),
                    "volumeNumber": paper.volumeNumber?.toString(),
                    "issueNumber": paper.issueNumber?.toString(),
                    "keywords": paper.keywords,
                    "url": `${baseUrl}/current-issue/${volume}/${issue}/${paperId}`,
                    "mainEntityOfPage": {
                        "@type": "WebPage",
                        "@id": `${baseUrl}/current-issue/${volume}/${issue}/${paperId}`
                    }
                }}
            />

            <JsonLd
                id="breadcrumb"
                data={{
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    "itemListElement": [
                        {
                            "@type": "ListItem",
                            "position": 1,
                            "name": "Home",
                            "item": `${baseUrl}`
                        },
                        {
                            "@type": "ListItem",
                            "position": 2,
                            "name": "Current Issue",
                            "item": `${baseUrl}/current-issue`
                        },
                        {
                            "@type": "ListItem",
                            "position": 3,
                            "name": paper.paperId,
                            "item": `${baseUrl}/current-issue/${volume}/${issue}/${paperId}`
                        }
                    ]
                }}
            />
        </div>
    );
}
