"use client";

import Link from 'next/link';
import { ChevronLeft, ChevronRight, Layers, LogOut, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
    Sidebar,
    SidebarContent,
    SidebarFooter,
    SidebarHeader,
    SidebarMenu,
    SidebarMenuButton,
    SidebarMenuItem,
    useSidebar,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import {
    Tooltip,
    TooltipContent,
    TooltipTrigger,
} from "@/components/ui/tooltip";

import type { Session } from "next-auth";
import { useSocket } from '@/components/providers/SocketProvider';

interface PanelSidebarProps {
    pathname: string;
    user: Session['user'] | null;
    filteredItems: { name: string; fullHref: string; icon?: React.ReactNode; labelOverrides?: Record<string, string> }[];
    handleLogout: () => Promise<void>;
}

export function PanelSidebar({
    pathname,
    user,
    filteredItems,
    handleLogout,
}: PanelSidebarProps) {
    const { state, isMobile, setOpenMobile, toggleSidebar } = useSidebar();
    const isCollapsed = state === "collapsed";
    const { unreadCount } = useSocket();

    return (
        <Sidebar collapsible="icon" className={cn("border-r border-border/50 backdrop-blur-xl transition-all duration-300", isMobile ? "bg-card" : "bg-card/30")}>
            {/* Custom Toggle Button in the middle-right */}
            {!isMobile && (
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
                            className={cn("absolute -right-4 top-1/2 -translate-y-1/2 z-50 rounded-full border border-border bg-background shadow-lg hover:bg-accent transition-all hidden lg:flex items-center justify-center cursor-pointer", isCollapsed ? "bg-primary text-white" : "bg-primary text-white")}
                            onClick={toggleSidebar}
                        >
                            {isCollapsed ? (
                                <ChevronRight className="size-6" />
                            ) : (
                                <ChevronLeft className="size-6" />
                            )}
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="font-bold bg-primary text-white border-none">
                        {isCollapsed ? "Expand" : "Collapse"}
                    </TooltipContent>
                </Tooltip>
            )}

            <SidebarHeader className="h-16 flex flex-row items-center justify-between px-6 border-b border-border/70 overflow-hidden">
                <Link href="/" className="flex items-center gap-3 group cursor-pointer shrink-0" onClick={() => setOpenMobile(false)}>
                    <div className="bg-primary size-8 rounded-lg flex items-center justify-center shadow-lg shadow-primary/10 group-hover:scale-105 transition-transform shrink-0">
                        <Layers className="size-5 text-white stroke-2"/>
                    </div>
                    {!isCollapsed && (
                        <div className="space-y-0.5 whitespace-nowrap opacity-100 transition-opacity duration-300">
                            <span className="font-serif font-bold text-primary text-label leading-none block tracking-tight">IJITEST</span>
                            <span className="text-label uppercase font-semibold tracking-wider text-muted-foreground block">Portal</span>
                        </div>
                    )}
                </Link>

                {/* Mobile Close Button */}
                {isMobile && (
                    <Button
                        variant="ghost"
                        size="icon"
                        aria-label="Close sidebar"
                        className="size-10 text-muted-foreground hover:text-foreground cursor-pointer"
                        onClick={() => setOpenMobile(false)}
                    >
                        <X className="size-6" />
                    </Button>
                )}
            </SidebarHeader>

            <SidebarContent className="px-3 py-6">
                <SidebarMenu className="space-y-2">
                    {filteredItems.map((item) => {
                        const isActive = pathname === item.fullHref;
                        return (
                            <SidebarMenuItem key={item.name}>
                                <SidebarMenuButton
                                    asChild
                                    isActive={isActive}
                                    size="lg"
                                    tooltip={item.name}
                                    className={cn(
                                        "h-11 2xl:h-12 w-full px-3.5 rounded-xl transition-all",
                                        isActive ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-muted/50",
                                        isCollapsed && "px-0 justify-center h-12"
                                    )}
                                >
                                    <Link href={item.fullHref} className="flex items-center gap-3.5 w-full relative" onClick={() => setOpenMobile(false)}>
                                        <div className={cn(
                                            "size-8 2xl:size-9 rounded-lg flex items-center justify-center transition-all shrink-0 relative",
                                            isActive ? "bg-primary text-white shadow-lg shadow-primary/20" : "bg-muted/50 text-muted-foreground group-hover:bg-muted"
                                        )}>
                                            {item.icon && (
                                                <div className="[&>svg]:size-4 2xl:[&>svg]:size-5">
                                                    {item.icon}
                                                </div>
                                            )}
                                            {isCollapsed && item.name === 'Messages' && unreadCount > 0 && (
                                                <span className="absolute -top-1 -right-1 size-3 bg-secondary rounded-full border border-card animate-pulse" />
                                            )}
                                        </div>
                                        {!isCollapsed && (
                                            <span className="font-medium text-body-sm flex-1 flex items-center justify-between">
                                                <span>{item.labelOverrides?.[user?.role || ''] || item.name}</span>
                                                {item.name === 'Messages' && unreadCount > 0 && (
                                                    <span className="bg-secondary text-secondary-foreground text-badge font-black tracking-normal px-2 py-0.5 rounded-full shrink-0 min-w-5 text-center mr-2 shadow-xs">
                                                        {unreadCount}
                                                    </span>
                                                )}
                                            </span>
                                        )}
                                    </Link>
                                </SidebarMenuButton>
                            </SidebarMenuItem>
                        );
                    })}
                </SidebarMenu>
            </SidebarContent>

            <SidebarFooter className="p-4 border-t border-border/70 mt-auto">
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            className={cn(
                                "w-full justify-start gap-4 h-12 px-4 text-rose-600 hover:bg-rose-500/10 rounded-lg transition-all font-medium cursor-pointer",
                                isCollapsed && "justify-center px-0"
                            )}
                            onClick={handleLogout}
                        >
                            <LogOut className="size-5 shrink-0" />
                            {!isCollapsed && <span>Logout</span>}
                        </Button>
                    </TooltipTrigger>
                    {isCollapsed && (
                        <TooltipContent side="right" className="font-bold bg-rose-600 text-white border-none">
                            Logout
                        </TooltipContent>
                    )}
                </Tooltip>
            </SidebarFooter>
        </Sidebar>
    );
}

