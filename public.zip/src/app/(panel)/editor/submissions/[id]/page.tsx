import { getSubmissionById, decideSubmission } from "@/actions/submissions";
import { waivePayment } from "@/actions/payments";
import DeleteSubmissionButton from "@/features/submissions/components/DeleteSubmissionButton";
import AdminPdfUpload from "@/features/submissions/components/AdminPdfUpload";
import PublicationAssignment from "@/features/submissions/components/PublicationAssignment";
import {
    User,
    Mail,
    FileText,
    Download,
    CheckCircle,
    XCircle,
    Calendar,
    Shield,
    AlertCircle,
    Globe,
    MessageSquare,
    ExternalLink,
    Tag,
    ChevronLeft
} from "lucide-react";
import Link from "next/link";
import type { Metadata } from 'next';
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { PdfViewer } from "@/components/reviewer/PdfViewer";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
    const { id } = await params;
    const response = await getSubmissionById(parseInt(id));
    if (!response.success || !response.data) return { title: 'Submission Not Found | Editor' };

    const submission = response.data;

    return {
        title: `Editorial: ${submission.paper_id} | IJITEST`,
        description: `Editorial management for manuscript ${submission.paper_id}: ${submission.title}`,
    };
}

export default async function SubmissionDetails({ params }: { params: Promise<{ id: string }> }) {
    const { id: idStr } = await params;
    const id = parseInt(idStr);

    if (isNaN(id)) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[50vh] p-6 text-center">
                <AlertCircle className="w-12 h-12 text-muted-foreground/20 mb-4" />
                <h2 className=" font-semibold text-foreground tracking-wider mb-2">Invalid Identification</h2>
                <p className="text-xs font-medium text-muted-foreground mb-6">The manuscript reference provided is not in a valid numerical format.</p>
                <Button asChild variant="outline" className="h-10 px-6 font-semibold text-[10px]  tracking-widest rounded-xl cursor-pointer">
                    <Link className="cursor-pointer" href="/editor/submissions">Return to Queue</Link>
                </Button>
            </div>
        );
    }

    const response = await getSubmissionById(id);

    if (!response.success || !response.data) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[50vh] p-6 text-center">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-6">
                    <FileText className="w-8 h-8 text-muted-foreground/30" />
                </div>
                <h2 className=" font-semibold text-foreground tracking-wider mb-2">Manuscript Not Found</h2>
                <p className="text-xs font-medium text-muted-foreground mb-6 max-w-sm">The requested manuscript (Ref: {id}) could not be located in the current sector.</p>
                <Button asChild variant="outline" className="h-10 px-6 font-semibold text-[10px]  tracking-widest rounded-xl cursor-pointer">
                    <Link className="cursor-pointer" href="/editor/submissions">Back to Queue</Link>
                </Button>
            </div>
        );
    }

    const submission = response.data;

    const getStatusVariant = (status: string) => {
        switch (status) {
            case 'submitted': return 'bg-indigo-500/10 text-indigo-600 border-none';
            case 'under_review': return 'bg-amber-500/10 text-amber-600 border-none';
            case 'accepted': return 'bg-purple-500/10 text-purple-600 border-none';
            case 'paid': return 'bg-emerald-500/10 text-emerald-600 border-none';
            case 'published': return 'bg-cyan-500/10 text-cyan-600 border-none';
            case 'rejected': return 'bg-rose-500/10 text-rose-600 border-none';
            default: return 'bg-muted text-muted-foreground border-none';
        }
    };

    return (
        <section className="space-y-6 pb-20">
            {/* Breadcrumb / Top Bar */}
            <div className="flex items-center justify-between gap-4">
                <Button asChild variant="ghost" size="sm" className="h-9 gap-2 text-muted-foreground hover:text-primary font-semibold text-[10px] tracking-widest -ml-2 cursor-pointer capitalize">
                    <Link className="cursor-pointer" href="/editor/submissions">
                        <ChevronLeft className="w-4 h-4" /> Editorial queue
                    </Link>
                </Button>
            </div>

            <Card className="border-border/50 shadow-lg overflow-hidden bg-background">
                <CardHeader className="p-8 bg-muted/20 border-b border-border/50">
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                        <div className="space-y-3 max-w-2xl">
                            < Badge className={`h-5 px-1.5 text-[9px] font-semibold tracking-widest whitespace-nowrap capitalize ${getStatusVariant(submission.status)}`}>
                                {submission.status.replace('_', ' ')}
                            </Badge>
                            <h1 className="font-serif text-xl xl:text-2xl 2xl:text-3xl font-semibold text-foreground tracking-tight leading-tight capitalize">
                                {submission.title}
                            </h1>
                            <div className="flex flex-wrap items-center gap-6 text-[10px] xl:text-[11px] font-semibold text-muted-foreground tracking-widest capitalize">
                                <div className="flex items-center gap-2">
                                    <Calendar className="w-3.5 h-3.5 opacity-50" />
                                    <span>{submission.submitted_at ? new Date(submission.submitted_at).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' }) : 'Unknown Date'}</span>
                                </div>
                                <div className="flex items-center gap-2 text-primary/80">
                                    <Shield className="w-3.5 h-3.5" />
                                    <span className="uppercase">{submission.paper_id}</span>
                                </div>
                                {submission.keywords && (
                                    <div className="flex items-center gap-2">
                                        <Tag className="w-3.5 h-3.5 opacity-50" />
                                        <span className="truncate max-w-[200px]">{submission.keywords}</span>
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="flex flex-col gap-2 shrink-0">
                            {submission.file_path && (
                                <Button asChild className="h-10 px-6 gap-2 bg-primary text-white font-semibold text-[10px] xl:text-[11px] tracking-widest rounded-xl shadow-lg shadow-primary/20 hover:scale-[1.02] transition-all cursor-pointer capitalize">
                                    <a href={submission.file_path} download>
                                        <Download className="w-4 h-4" /> Download manuscript
                                    </a>
                                </Button>
                            )}
                            <p className="text-[9px] font-semibold text-muted-foreground text-center tracking-widest opacity-60 capitalize">Authored by {submission.author_name}</p>
                        </div>
                    </div>
                </CardHeader>

                <CardContent className="p-0">
                    <div className="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-border/50">
                        {/* Main Content (8 cols) */}
                        <div className="lg:col-span-8 p-8 space-y-12">
                            <div className="space-y-4">
                                <div className="flex items-center gap-2 text-[10px] font-semibold text-muted-foreground tracking-widest opacity-60 capitalize">
                                    <FileText className="w-4 h-4" /> Abstract overview
                                </div>
                                <div className="p-6 bg-muted/5 rounded-xl border border-border/30">
                                    <p className="text-[13px] 2xl:text-sm text-foreground leading-relaxed text-justify font-medium selection:bg-primary/20 ">
                                        {submission.abstract || "No abstract provided."}
                                    </p>
                                </div>
                            </div>

                            {submission.pdf_url && (
                                <div className="space-y-4 pt-4 border-t border-border/30">
                                    <div className="flex items-center gap-2 text-[10px] font-semibold text-muted-foreground tracking-widest opacity-60 capitalize">
                                        <Shield className="w-4 h-4" /> Secure manuscript preview
                                    </div>
                                    <div className="rounded-2xl border border-border/50 overflow-hidden shadow-vip-hover h-[100vh] bg-muted/10 relative group">
                                        <PdfViewer
                                            pdfUrl={submission.pdf_url}
                                            title={submission.title}
                                        />
                                        <div className="absolute inset-0 pointer-events-none ring-1 ring-inset ring-black/5" />
                                    </div>
                                </div>
                            )}

                            {submission.status !== 'submitted' && (
                                <div className="space-y-6 pt-4 border-t border-border/30">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2 text-[10px] font-semibold text-muted-foreground tracking-widest opacity-60 capitalize">
                                            <MessageSquare className="w-4 h-4" /> Reviewer intelligence
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-1 gap-4">
                                        {submission.allReviews?.length === 0 ? (
                                            <div className="p-8 text-center bg-muted/10 rounded-xl border border-dashed border-border/50">
                                                <p className="text-[10px] font-semibold text-muted-foreground tracking-widest capitalize">Awaiting technical evaluation from assigned reviewers</p>
                                            </div>
                                        ) : (
                                            submission.allReviews?.map((r, i) => (
                                                <Card key={r.id} className="border-border/50 shadow-none bg-muted/5 overflow-hidden">
                                                    <CardHeader className="p-4 bg-muted/20 border-b border-border/30 flex flex-row items-center justify-between">
                                                        <div className="flex items-center gap-2">
                                                            <Badge variant="outline" className="h-5 px-1.5 text-[8px] font-semibold tracking-widest bg-background border-border text-primary capitalize">Technical reviewer {i + 1}</Badge>
                                                            <span className="text-[10px] font-semibold text-muted-foreground tracking-widest opacity-60 capitalize">{r.reviewer?.profile?.fullName || "Assigned Reviewer"}</span>
                                                        </div>
                                                        {r.status === 'completed' && <CheckCircle className="w-4 h-4 text-emerald-500" />}
                                                    </CardHeader>
                                                    <CardContent className="p-4">
                                                        <p className="text-xs text-muted-foreground font-medium  leading-relaxed whitespace-pre-wrap">"{r.review?.commentsToAuthor || "Feedback in progress..."}"</p>
                                                    </CardContent>
                                                </Card>
                                            ))
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Sidebar (4 cols) */}
                        <div className="lg:col-span-4 p-8 bg-muted/20 space-y-10">
                            <div className="space-y-4">
                                <h3 className="text-[10px] font-semibold text-muted-foreground tracking-widest opacity-60 capitalize">Author credentials</h3>
                                <Card className="border-border/50 shadow-sm bg-background">
                                    <CardContent className="p-5 space-y-4">
                                        <div className="flex items-start gap-3">
                                            <div className="w-8 h-8 rounded-lg bg-primary/5 flex items-center justify-center shrink-0">
                                                <User className="w-4 h-4 text-primary" />
                                            </div>
                                            <div className="min-w-0">
                                                <p className="text-[9px] font-semibold  tracking-widest text-muted-foreground opacity-60 mb-0.5">Author Name</p>
                                                <p className="font-semibold text-xs text-foreground tracking-wider">{submission.author_name}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-start gap-3">
                                            <div className="w-8 h-8 rounded-lg bg-primary/5 flex items-center justify-center shrink-0">
                                                <Mail className="w-4 h-4 text-primary" />
                                            </div>
                                            <div className="min-w-0">
                                                <p className="text-[9px] font-semibold  tracking-widest text-muted-foreground opacity-60 mb-0.5">Email Address</p>
                                                <p className="font-semibold text-xs text-foreground tracking-wider truncate">{submission.author_email}</p>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>

                            <Separator className="bg-border/50" />

                            <div className="space-y-4">
                                <div className="flex flex-col gap-1">
                                    <h3 className="text-[10px] font-semibold text-muted-foreground uppercase tracking-[0.2em] opacity-60">Manuscript Processing & PDF Management</h3>
                                    <p className="text-[9px] font-medium text-muted-foreground/50 leading-relaxed uppercase tracking-wider">
                                        Upload the final PDF after applying journal styles, formatting, and manual metadata.
                                    </p>
                                </div>
                                <Card className="border-border/50 shadow-sm bg-background">
                                    <CardContent className="p-5 space-y-4">
                                        <AdminPdfUpload submissionId={submission.id} currentUrl={submission.pdf_url} />
                                        {submission.pdf_url ? (
                                            <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/10">
                                                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                                                <span className="text-[9px] font-semibold text-emerald-600 uppercase tracking-widest">Active Asset</span>
                                            </div>
                                        ) : (
                                            <div className="flex items-center gap-2 p-3 rounded-lg bg-rose-500/5 border border-rose-500/10">
                                                <div className="w-2 h-2 rounded-full bg-rose-500" />
                                                <span className="text-[9px] font-semibold text-rose-600 uppercase tracking-widest">Missing Asset</span>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </div>

                            <Separator className="bg-border/50" />

                            <div className="space-y-4">
                                <h3 className="text-[10px] font-semibold text-muted-foreground tracking-[0.2em] opacity-60">Decision Pipeline</h3>
                                <div className="space-y-3">
                                    {submission.status === 'submitted' && (
                                        <div className="space-y-3">
                                            <div className="p-4 bg-orange-500/5 border border-orange-500/20 rounded-xl space-y-2">
                                                <p className="text-[10px] font-semibold  text-orange-600 tracking-widest">Initial Assessment</p>
                                                <p className="text-[10px] font-medium text-orange-600/70">Manuscript is ready for reviewer assignment.</p>
                                            </div>
                                            <Button asChild className="w-full h-11 gap-2 bg-orange-600 hover:bg-orange-700 text-white font-semibold text-[11px]  tracking-widest rounded-xl shadow-lg shadow-orange-600/10 cursor-pointer">
                                                <Link className="cursor-pointer" href={`/editor/reviews?assign=${submission.id}`}>
                                                    Assign to Reviewer
                                                </Link>
                                            </Button>
                                        </div>
                                    )}

                                    {submission.status === 'under_review' && (
                                        <div className="space-y-4">
                                            <div className="p-4 bg-primary/5 border border-primary/20 rounded-xl space-y-1">
                                                <p className="text-[10px] font-semibold  text-primary tracking-widest">Editorial Threshold</p>
                                                <p className="text-[10px] font-medium text-primary/70 ">Final authorization required</p>
                                            </div>
                                            <div className="grid grid-cols-1 gap-2">
                                                <form action={async () => {
                                                    'use server';
                                                    await decideSubmission(submission.id, 'accepted');
                                                }}>
                                                    <Button className="w-full h-11 gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px]  tracking-widest rounded-xl shadow-xl shadow-emerald-600/20 cursor-pointer">
                                                        <CheckCircle className="w-4 h-4" /> Authorize Acceptance
                                                    </Button>
                                                </form>
                                                <form action={async () => {
                                                    'use server';
                                                    await decideSubmission(submission.id, 'rejected');
                                                }}>
                                                    <Button variant="outline" className="w-full h-11 gap-2 border-red-500/20 text-red-600 font-semibold text-[11px]  tracking-widest rounded-xl cursor-pointer">
                                                        <XCircle className="w-4 h-4" /> Final Rejection
                                                    </Button>
                                                </form>
                                            </div>
                                        </div>
                                    )}

                                    {submission.status === 'accepted' && (
                                        <div className="space-y-4">
                                            <div className="p-6 bg-emerald-500/5 border border-emerald-500/20 rounded-xl text-center space-y-3">
                                                <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center mx-auto">
                                                    <CheckCircle className="w-5 h-5 text-emerald-600" />
                                                </div>
                                                <div className="space-y-1">
                                                    <p className="text-[10px] font-semibold  text-emerald-600 tracking-widest">Authorized</p>
                                                    <p className="text-[10px] font-medium text-muted-foreground  tracking-widest ">Awaiting author remittance...</p>
                                                </div>
                                                <form action={async () => {
                                                    'use server';
                                                    await waivePayment(submission.id);
                                                }}>
                                                    <Button variant="outline" className="w-full h-9 gap-2 border-emerald-500/30 text-emerald-600 font-semibold text-[9px]  tracking-widest rounded-lg hover:bg-emerald-500 cursor-pointer">
                                                        Waive Transaction Fee
                                                    </Button>
                                                </form>
                                            </div>
                                        </div>
                                    )}

                                    {submission.status === 'published' && (
                                        <div className="space-y-4">
                                            <Card className="bg-emerald-950 text-white border-none overflow-hidden rounded-xl shadow-2xl">
                                                <CardContent className="p-8 space-y-6 relative">
                                                    <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-400 opacity-10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
                                                    <div className="flex items-center gap-4">
                                                        <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center shrink-0 border border-white/10">
                                                            <Globe className="w-5 h-5 text-emerald-400" />
                                                        </div>
                                                        <div className="space-y-0.5">
                                                            <p className="text-[9px] font-semibold text-emerald-400  tracking-widest">In Archive</p>
                                                            <h3 className=" font-semibold tracking-wider ">Live Index</h3>
                                                        </div>
                                                    </div>
                                                    <Separator className="bg-white/10" />
                                                    <div className="space-y-3">
                                                        <div className="flex items-center justify-between">
                                                            <p className="text-[10px] font-semibold  text-white/40 tracking-widest">Volume Node</p>
                                                            <p className="text-xs font-semibold">{submission.volume_number && `Vol ${submission.volume_number}, Issue ${submission.issue_number}`}</p>
                                                        </div>
                                                        <Button asChild variant="ghost" className="w-full h-10 gap-2 bg-white/5 hover:bg-white/10 text-white font-semibold text-[10px]  tracking-widest border border-white/10 rounded-xl cursor-pointer">
                                                            <Link className="cursor-pointer" href="/archives">
                                                                <ExternalLink className="w-3.5 h-3.5" /> View Public Archive
                                                            </Link>
                                                        </Button>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        </div>
                                    )}

                                    {submission.payment?.status === 'paid' && (
                                        <div className="space-y-4">
                                            <div className="p-6 bg-emerald-500/5 border border-emerald-500/20 rounded-xl space-y-6">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 bg-white border border-emerald-100 rounded-xl flex items-center justify-center shrink-0">
                                                        <CheckCircle className="w-5 h-5 text-emerald-600" />
                                                    </div>
                                                    <div className="space-y-0.5">
                                                        <p className="text-[10px] font-semibold text-emerald-600  tracking-widest">Ready for Indexing</p>
                                                        <p className="text-[10px] font-medium text-muted-foreground ">Payment Verified</p>
                                                    </div>
                                                </div>

                                                <PublicationAssignment
                                                    submissionId={submission.id}
                                                    currentIssueId={submission.issue_id}
                                                />
                                            </div>
                                        </div>
                                    )}

                                    <div className="pt-4 mt-6 border-t border-border/50">
                                        {submission.payment?.status !== 'paid' && submission.status !== 'published' ? (
                                            <div className="space-y-3">
                                                <h4 className="text-[10px] font-semibold text-muted-foreground tracking-widest opacity-50 px-1">Infrastructure Control</h4>
                                                <DeleteSubmissionButton submissionId={submission.id} status={submission.status} variant="full" />
                                            </div>
                                        ) : (
                                            <div className="bg-muted p-4 rounded-xl border border-border/50  text-[9px] text-muted-foreground/60 font-semibold  tracking-widest text-center">
                                                Records Locked (Archived)
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </section>
    );
}
