import { redirect, notFound } from "next/navigation";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { checkResubmissionEligibility, getAuthorSubmission } from "@/actions/author-submissions";
import { RevisionResubmitForm } from "@/features/submissions/components/RevisionResubmitForm";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { XCircle, ArrowLeft } from "lucide-react";
import Link from "next/link";
import type { SubmissionIdParam } from "@/db/types";

export default async function ResubmitPage({ params }: { params: Promise<SubmissionIdParam> }) {
    const session = await getServerSession(authOptions);
    if (!session?.user) redirect('/login');
    if (session.user.role !== 'author') redirect(`/${session.user.role}`);

    const resolvedParams = await params;
    const submissionId = parseInt(resolvedParams.id);
    if (isNaN(submissionId)) notFound();

    const [submissionRes, eligibilityRes] = await Promise.all([
        getAuthorSubmission(submissionId),
        checkResubmissionEligibility(submissionId),
    ]);

    if (!submissionRes.success || !submissionRes.data) notFound();
    const submission = submissionRes.data;
    let eligibility = { eligible: false, daysRemaining: 0 };
    let eligError = "";
    if (eligibilityRes.success && eligibilityRes.data) {
        eligibility = eligibilityRes.data;
    } else if (!eligibilityRes.success) {
        eligError = eligibilityRes.error;
    } else {
        eligError = "Eligibility response returned no data.";
    }

    return (
        <section className="max-w-2xl mx-auto space-y-6 pb-20">
            <header className="flex items-center gap-4 border-b border-primary/5 pb-6">
                <Button asChild variant="ghost" size="sm" className="rounded-lg">
                    <Link href={`/author/submissions/${submissionId}`} className="flex items-center gap-2 text-label font-bold uppercase">
                        <ArrowLeft className="w-3.5 h-3.5" /> Back
                    </Link>
                </Button>
                <div>
                    <h1 className="font-black text-foreground tracking-widest uppercase">Submit Revision</h1>
                    <p className="text-caption text-muted-foreground font-medium">Upload your revised manuscript and copyright form</p>
                </div>
            </header>

            {!eligibility.eligible ? (
                <Card className="border-rose-200 bg-rose-50/50">
                    <CardContent className="p-10 flex flex-col items-center gap-4 text-center">
                        <XCircle className="w-12 h-12 text-rose-500" />
                        <h3 className="font-black uppercase tracking-widest text-foreground">Not Eligible</h3>
                        <p className="text-caption text-muted-foreground max-w-sm">{eligError || "Window Expired"}</p>
                        <Button asChild variant="outline" size="sm" className="rounded-xl font-bold uppercase">
                            <Link href="/author">Back to Dashboard</Link>
                        </Button>
                    </CardContent>
                </Card>
            ) : (
                <RevisionResubmitForm
                    submissionId={submissionId}
                    paperId={submission.paperId}
                    title={submission.title}
                    daysRemaining={eligibility.daysRemaining || 0}
                    currentStatus={submission.status}
                />
            )}
        </section>
    );
}
