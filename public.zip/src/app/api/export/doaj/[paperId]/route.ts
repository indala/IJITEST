import { NextRequest, NextResponse } from "next/server";
import { getPaperById } from "@/actions/archives";
import { getSettingsData } from "@/actions/settings";
import { generateDoajXml } from "@/lib/doaj-generator";

export async function GET(
    _request: NextRequest,
    { params }: { params: Promise<{ paperId: string }> }
) {
    try {
        const { paperId } = await params;
        if (!paperId) {
            return new NextResponse("Paper ID is required", { status: 400 });
        }

        const [paperRes, settings] = await Promise.all([
            getPaperById(paperId.toUpperCase()),
            getSettingsData()
        ]);

        if (!paperRes.success || !paperRes.data) {
            return new NextResponse("Paper not found", { status: 404 });
        }

        const paper = paperRes.data;
        const xml = generateDoajXml({
            settings,
            papers: [paper],
        });

        return new NextResponse(xml, {
            status: 200,
            headers: {
                "Content-Type": "application/xml; charset=utf-8",
                "Content-Disposition": `attachment; filename="doaj-${paper.paperId}.xml"`,
                "Cache-Control": "public, max-age=3600",
            },
        });
    } catch (error) {
        console.error("DOAJ export error:", error);
        return new NextResponse("Internal Server Error", { status: 500 });
    }
}
