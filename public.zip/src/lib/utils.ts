import { clsx, type ClassValue } from "clsx"
import { extendTailwindMerge } from "tailwind-merge"

const twMerge = extendTailwindMerge({
    extend: {
        theme: {
            text: ["lead", "body", "body-sm", "meta", "label", "badge", "caption"],
        },
    },
});

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Ensures a file URL is routed through the secure API endpoint.
 * @param url The stored file URL (e.g., /uploads/submissions/file.pdf or /api/files/...)
 */
export function getSecureUrl(url: string | null | undefined) {
    if (!url) return "";
    if (url.startsWith('/api/files/')) return url;
    if (url.startsWith('/uploads/')) {
        return `/api/files${url}`;
    }
    return url;
}

/**
 * Deterministic date formatter to prevent Next.js SSR hydration mismatches.
 * Formats dates in UTC (DD/MM/YYYY) to remain consistent across timezone scopes.
 */
export function formatDate(dateInput: Date | string | number | null | undefined): string {
    if (!dateInput) return "";
    const d = new Date(dateInput);
    if (isNaN(d.getTime())) return "";
    const day = String(d.getUTCDate()).padStart(2, '0');
    const month = String(d.getUTCMonth() + 1).padStart(2, '0');
    const year = d.getUTCFullYear();
    return `${day}/${month}/${year}`;
}

/**
 * Replace {{variableName}} placeholders with dynamic runtime values
 */
export function renderTemplateText(templateText: string, data: Record<string, string | number | undefined | null>): string {
    return templateText.replace(/\{\{([a-zA-Z0-9_-]+)\}\}/g, (match, varName) => {
        const val = data[varName];
        return val !== undefined && val !== null ? String(val) : match;
    });
}

/**
 * Safely extracts human-readable error messages from unknown catch targets.
 */
export function getErrorMessage(error: unknown): string {
    if (error instanceof Error) return error.message;
    if (typeof error === 'string') return error;
    return String(error);
}

