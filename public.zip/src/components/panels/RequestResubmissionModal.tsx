"use client";

import { useState } from "react";
import { requestResubmissionWithComments } from "@/actions/submissions";
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, Loader2, RotateCcw } from "lucide-react";
import { useRouter } from "next/navigation";

interface Props {
    submissionId: number;
    paperId: string;
    paperTitle: string;
}

export function RequestResubmissionModal({ submissionId, paperId, paperTitle }: Props) {
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [comments, setComments] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [done, setDone] = useState(false);

    async function handleSubmit() {
        if (comments.trim().length < 20) {
            setError("Please provide meaningful feedback (at least 20 characters).");
            return;
        }
        setError(null);
        setLoading(true);
        const result = await requestResubmissionWithComments(submissionId, comments);
        setLoading(false);
        if (!result.success) {
            setError(result.error);
        } else {
            setDone(true);
            setTimeout(() => {
                setOpen(false);
                setDone(false);
                setComments("");
                router.refresh();
            }, 2000);
        }
    }

    return (
        <>
            <Button
                onClick={() => setOpen(true)}
                variant="outline"
                size="sm"
                className="h-9 text-label font-bold uppercase rounded-xl border-orange-300 text-orange-700 hover:bg-orange-50 transition-all"
            >
                <RotateCcw className="w-3.5 h-3.5 mr-2" /> Request Resubmission
            </Button>

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="max-w-lg rounded-2xl">
                    <DialogHeader>
                        <DialogTitle className="font-black uppercase tracking-widest text-foreground">Request Revision</DialogTitle>
                        <DialogDescription className="text-caption text-muted-foreground">
                            Your feedback will be emailed to the author with a link to their Author Portal.
                        </DialogDescription>
                    </DialogHeader>

                    {done ? (
                        <div className="py-10 flex flex-col items-center gap-3 text-center">
                            <CheckCircle className="w-10 h-10 text-emerald-500" />
                            <p className="font-bold text-foreground uppercase tracking-wider text-label">Revision Requested</p>
                            <p className="text-caption text-muted-foreground">Author has been notified via email.</p>
                        </div>
                    ) : (
                        <>
                            <div className="space-y-4 py-2">
                                <div className="p-3 rounded-xl bg-muted/30 border border-border/50 text-body-sm space-y-1">
                                    <p className="font-bold text-foreground">{paperTitle}</p>
                                    <Badge variant="outline" className="text-badge font-mono">{paperId}</Badge>
                                </div>

                                <div className="space-y-2">
                                    <Label className="form-label-brand font-bold uppercase tracking-widest">
                                        Reviewer Comments / Required Changes <span className="text-rose-500">*</span>
                                    </Label>
                                    <Textarea
                                        value={comments}
                                        onChange={(e) => setComments(e.target.value)}
                                        placeholder="Describe the required revisions, specific sections to address, formatting issues, missing references, etc."
                                        className="min-h-[150px] text-body-sm resize-none rounded-xl border-border/60 focus:border-primary/40"
                                    />
                                    <p className="text-caption text-muted-foreground">{comments.length} characters (min. 20)</p>
                                </div>

                                {error && (
                                    <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 text-body-sm font-medium">
                                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                                        {error}
                                    </div>
                                )}

                                <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 text-body-sm">
                                    <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                                    The author will have <strong>28 days</strong> to resubmit. If they don&apos;t act, their account will be auto-deactivated.
                                </div>
                            </div>

                            <DialogFooter className="gap-2">
                                <Button variant="ghost" onClick={() => setOpen(false)} className="rounded-xl font-bold uppercase">
                                    Cancel
                                </Button>
                                <Button
                                    onClick={handleSubmit}
                                    disabled={loading}
                                    className="bg-orange-500 hover:bg-orange-600 text-white font-bold uppercase text-label rounded-xl"
                                >
                                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Send Request"}
                                </Button>
                            </DialogFooter>
                        </>
                    )}
                </DialogContent>
            </Dialog>
        </>
    );
}
