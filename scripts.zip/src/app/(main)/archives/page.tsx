"use client";

import { Calendar, FileText, ChevronRight, Download, Search } from 'lucide-react';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import PaperCard from '@/features/archives/components/PaperCard';
import PageHeader from "@/components/layout/PageHeader";
import TrackManuscriptWidget from '@/features/shared/widgets/TrackManuscriptWidget';
import { getPublishedPapers } from '@/actions/archives'; // Need to create this action

export default function Archives() {
    const [papers, setPapers] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');

    useEffect(() => {
        async function load() {
            setLoading(true);
            const data = await getPublishedPapers();
            setPapers(data);
            setLoading(false);
        }
        load();
    }, []);

    const filteredPapers = papers.filter(p =>
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.author_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.keywords?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.paper_id.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (loading) return (
        <div className="bg-white min-h-screen">
            <PageHeader
                title="Journal Archives"
                description="Explore our digital repository of peer-reviewed research."
                breadcrumbs={[{ name: 'Home', href: '/' }, { name: 'Archives', href: '/archives' }]}
                scrollOnComplete={true}
            />
            <div className="p-20 text-center font-black text-gray-300 uppercase tracking-[0.3em] animate-pulse">
                Accessing Digital Repository...
            </div>
        </div>
    );

    return (
        <div className="bg-white min-h-screen">
            <PageHeader
                title="Journal Archives"
                description="Explore our digital repository of peer-reviewed research, technical reports, and scientific breakthroughs."
                breadcrumbs={[
                    { name: 'Home', href: '/' },
                    { name: 'Archives', href: '/archives' },
                ]}
                scrollOnComplete={true}
            />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
                {/* Search Bar */}
                <div className="mb-12 relative max-w-2xl">
                    <div className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400">
                        <Search className="w-5 h-5" />
                    </div>
                    <input
                        type="text"
                        placeholder="Search by Title, Author, or Paper ID..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-gray-50 border-2 border-transparent focus:border-primary/20 focus:bg-white focus:ring-4 focus:ring-primary/5 rounded-2xl pl-16 pr-8 py-6 font-bold text-gray-900 shadow-sm transition-all outline-none"
                    />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
                    {/* Main Content */}
                    <div className="lg:col-span-2">
                        {filteredPapers.length > 0 ? (
                            <section className="space-y-12">
                                <div className="flex flex-col md:flex-row md:items-center justify-between bg-gray-900 p-8 md:p-10 rounded-2xl text-white overflow-hidden relative">
                                    <div className="relative z-10">
                                        <h2 className="text-xl sm:text-2xl font-sans font-black">Published Research</h2>
                                        <p className="text-white/50 text-[10px] font-black uppercase tracking-[0.2em] mt-1">Total Manuscripts: {filteredPapers.length}</p>
                                    </div>
                                    <div className="flex items-center gap-4 relative z-10 mt-4 md:mt-0">
                                        <div className="text-right hidden sm:block">
                                            <p className="text-[10px] font-black uppercase text-secondary tracking-widest">Latest Update</p>
                                            <p className="text-xs font-bold font-sans text-white/80">Volume 1 (2026)</p>
                                        </div>
                                        <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                            <FileText className="w-6 h-6 text-secondary" />
                                        </div>
                                    </div>
                                    <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-primary/20 rounded-full blur-3xl" />
                                </div>

                                <div className="space-y-8">
                                    {filteredPapers.map((paper: any) => (
                                        <PaperCard key={paper.paper_id} paper={paper} />
                                    ))}
                                </div>
                            </section>
                        ) : (
                            <div className="bg-gray-50 p-20 rounded-2xl border border-gray-100 text-center relative overflow-hidden">
                                <div className="absolute top-0 right-0 p-12 text-primary/5">
                                    <Calendar className="w-32 h-32" />
                                </div>
                                <div className="bg-white w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-sm border border-gray-100 relative z-10">
                                    <FileText className="w-8 h-8 text-gray-300" />
                                </div>
                                <h2 className="text-xl sm:text-2xl font-sans font-black text-gray-400 mb-4 relative z-10">Inaugural Volume in Progress</h2>
                                <p className="text-gray-400 max-w-sm mx-auto font-medium relative z-10 mb-6">
                                    IJITEST is currently curating its inaugural 2026 volume. Accepted articles will be published online first, followed by formal issue assignment.
                                </p>
                                <div className="relative z-10 mb-10 text-left bg-white/50 p-6 rounded-2xl border border-gray-100">
                                    <h4 className="text-[10px] font-black uppercase tracking-widest text-primary mb-2">What to expect here</h4>
                                    <p className="text-[10px] text-gray-500 font-medium leading-relaxed">
                                        Once published, papers will be organized by Volume and Issue, each featuring a dedicated DOI, full citation metadata, and open-access download links.
                                    </p>
                                </div>
                                <Link href="/submit" className="inline-flex flex-col items-center gap-3 relative z-10 group">
                                    <div className="px-8 py-4 bg-primary text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/20 group-hover:scale-105 transition-all flex items-center gap-3">
                                        Submit Your Research <ChevronRight className="w-4 h-4" />
                                    </div>
                                    <span className="text-[9px] text-primary font-bold uppercase tracking-tighter opacity-0 group-hover:opacity-100 transition-opacity">Early submissions receive priority homepage visibility</span>
                                </Link>
                            </div>
                        )}
                    </div>

                    {/* Sidebar Utilities */}
                    <div className="space-y-10">
                        {/* Status Check */}
                        <TrackManuscriptWidget />

                        {/* Call for Papers */}
                        <div className="bg-primary/5 p-10 rounded-2xl border border-primary/10">
                            <h3 className="text-xl font-sans font-black text-primary mb-2">Call for Papers</h3>
                            <p className="text-xs text-gray-500 mb-8 font-medium leading-relaxed">Be part of our inaugural edition. Early submissions may receive priority visibility on the home page and in launch communications.</p>
                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-primary/5">
                                    <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Submission Deadline</span>
                                    <span className="text-[10px] font-black text-primary">Rolling 2026</span>
                                </div>
                                <Link href="/submit" className="block w-full py-4 bg-primary text-white rounded-xl text-center text-[10px] font-black uppercase tracking-widest shadow-lg shadow-primary/10">
                                    Submit Manuscript
                                </Link>
                            </div>
                        </div>

                        {/* Resource Desk */}
                        <div className="bg-secondary p-8 rounded-2xl text-white shadow-xl shadow-secondary/20 group">
                            <Download className="w-8 h-8 mb-6 group-hover:rotate-12 transition-transform" />
                            <h3 className="text-xl font-sans font-black mb-2">Author Toolkit</h3>
                            <p className="text-xs text-white/70 mb-8 font-medium">Download our professional IEEE standard templates and copyright forms.</p>
                            <Link href="/guidelines" className="flex items-center justify-between p-4 bg-white/10 rounded-2xl border border-white/10 hover:bg-white/20 transition-all">
                                <span className="text-[10px] font-black uppercase tracking-widest">View Guidelines</span>
                                <ChevronRight className="w-4 h-4" />
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
