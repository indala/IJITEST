
import ReviewerApplicationForm from "@/features/reviewer/components/ReviewerApplicationForm";
import PageHeader from "@/components/layout/PageHeader";
import { CheckCircle2, Globe, Users, Award } from 'lucide-react';

export const metadata = {
    title: 'Join Us | IJITEST',
    description: 'Apply to become a reviewer or editor for the International Journal of Innovative Trends in Engineering Science and Technology.',
};

export default function JoinUsPage() {
    return (
        <div className="bg-white min-h-screen">
            <PageHeader
                title="Join Us"
                description="Join our global network of experts and contribute to the advancement of engineering and technology."
                breadcrumbs={[
                    { name: "Home", href: "/" },
                    { name: "Join Us", href: "/join-us" }
                ]}
            />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
                <div className="grid lg:grid-cols-12 gap-16">
                    {/* Left Column: Benefits & Info */}
                    <div className="lg:col-span-5 space-y-12">
                        <div>
                            <span className="inline-block px-3 py-1 bg-primary/10 text-primary font-black text-[10px] uppercase tracking-widest rounded-full mb-4">
                                Why Join Us?
                            </span>
                            <h2 className="text-3xl font-serif font-black text-slate-900 mb-6">
                                Elevate Your Academic Profile
                            </h2>
                            <p className="text-slate-600 leading-relaxed font-medium">
                                Joining the Board of IJITEST is a prestigious opportunity to stay at the forefront of research, influence the direction of your field, and gain global recognition for your expertise and academic leadership.
                            </p>
                        </div>

                        <div className="space-y-8">
                            {[
                                {
                                    icon: Globe,
                                    title: "Global Recognition",
                                    desc: "Your name will be listed on our website and in our annual printed journal as a distinguished board member of our global network."
                                },
                                {
                                    icon: Users,
                                    title: "Peer Networking",
                                    desc: "Connect with other leading experts, editors, and researchers in your domain to foster collaborative innovation."
                                },
                                {
                                    icon: Award,
                                    title: "Certification",
                                    desc: "Receive an official certificate of appreciation for your contributions to the journal's peer-review and editorial excellence."
                                }
                            ].map((benefit, i) => (
                                <div key={i} className="flex gap-4">
                                    <div className="w-12 h-12 bg-blue-50 border border-blue-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                                        <benefit.icon className="w-6 h-6 text-primary" />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-slate-900 mb-1">{benefit.title}</h3>
                                        <p className="text-slate-500 text-sm font-medium leading-relaxed">{benefit.desc}</p>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="p-8 bg-blue-50 rounded-[2rem] border border-blue-100 relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:bg-primary/10 transition-colors" />
                            <div className="relative z-10">
                                <h3 className="font-serif font-bold text-xl mb-2 text-primary">Eligibility Criteria</h3>
                                <ul className="space-y-3 mt-4">
                                    {[
                                        "Ph.D. degree in a relevant Engineering or Technology field",
                                        "Minimum 2 years of active research or teaching experience",
                                        "Proven publication record (at least 5 research papers)",
                                        "Associated with a recognized academic or industrial institution"
                                    ].map((item, i) => (
                                        <li key={i} className="flex items-start gap-3 text-sm font-bold text-slate-600">
                                            <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                                            {item}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>

                    {/* Right Column: Application Form */}
                    <div className="lg:col-span-7">
                        <ReviewerApplicationForm />
                    </div>
                </div>
            </div>
        </div>
    );
}
