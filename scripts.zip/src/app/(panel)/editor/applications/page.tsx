"use client";

import { useEffect, useState } from 'react';
import { getApplications, approveApplication, rejectApplication } from '@/actions/applications';
import {
    User,
    FileText,
    Mail,
    Building2,
    CheckCircle2,
    XCircle,
    ExternalLink,
    Search,
    Filter,
    Clock,
    UserCheck,
    Briefcase
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function ManageApplicationsPage() {
    const [applications, setApplications] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterRole, setFilterRole] = useState<'all' | 'reviewer' | 'editor'>('all');
    const [processingId, setProcessingId] = useState<number | null>(null);

    useEffect(() => {
        loadApplications();
    }, []);

    const loadApplications = async () => {
        setLoading(true);
        const data = await getApplications();
        setApplications(data);
        setLoading(false);
    };

    const handleApprove = async (id: number) => {
        if (!confirm('Are you sure you want to APPROVE this application?\nThis will automatically create a user account and send an invitation.')) return;

        setProcessingId(id);
        const result = await approveApplication(id);
        if (result.success) {
            loadApplications();
        } else {
            alert(result.error);
        }
        setProcessingId(null);
    };

    const handleReject = async (id: number) => {
        if (!confirm('Are you sure you want to REJECT this application?\nThis will delete the record and send a rejection email.')) return;

        setProcessingId(id);
        const result = await rejectApplication(id);
        if (result.success) {
            loadApplications();
        } else {
            alert(result.error);
        }
        setProcessingId(null);
    };

    const filteredApps = applications.filter(app => {
        const matchesSearch = app.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            app.email.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRole = filterRole === 'all' || app.application_type === filterRole;
        return matchesSearch && matchesRole;
    });

    return (
        <div className="space-y-10 pb-20">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div>
                    <h2 className="text-3xl font-serif font-black text-slate-900 mb-2 tracking-tight">Reviewer & Editor Applications</h2>
                    <p className="text-slate-500 font-medium tracking-tight max-w-lg">Assess incoming talent. Approve applications to automatically create their system credentials.</p>
                </div>

                <div className="flex bg-blue-50 p-1.5 rounded-2xl border border-blue-100">
                    <button
                        onClick={() => setFilterRole('all')}
                        className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${filterRole === 'all' ? 'bg-white text-primary shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                        All
                    </button>
                    <button
                        onClick={() => setFilterRole('reviewer')}
                        className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${filterRole === 'reviewer' ? 'bg-white text-primary shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                        Reviewers
                    </button>
                    <button
                        onClick={() => setFilterRole('editor')}
                        className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${filterRole === 'editor' ? 'bg-white text-primary shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                        Editors
                    </button>
                </div>
            </div>

            {/* Filter Bar */}
            <div className="bg-white p-6 rounded-[2rem] border border-blue-50 shadow-xl shadow-blue-900/5 flex flex-col md:flex-row gap-4 items-center">
                <div className="relative flex-1 group w-full">
                    <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-primary transition-colors" />
                    <input
                        type="text"
                        placeholder="Search by name or email..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-slate-50 border-none rounded-2xl pl-14 pr-6 py-4 text-sm font-bold text-slate-700 focus:ring-2 focus:ring-primary/20 transition-all placeholder:text-slate-300"
                    />
                </div>
                <div className="flex items-center gap-3 px-4 py-2 bg-blue-50/50 rounded-2xl border border-blue-100/50">
                    <Clock className="w-4 h-4 text-primary" />
                    <span className="text-xs font-black text-slate-500 uppercase tracking-widest">{filteredApps.length} Pending</span>
                </div>
            </div>

            {/* Applications List */}
            <div className="grid grid-cols-1 gap-6">
                {loading ? (
                    <div className="py-20 flex flex-col items-center justify-center gap-4 text-slate-300">
                        <div className="w-12 h-12 border-4 border-blue-100 border-t-primary rounded-full animate-spin" />
                        <p className="font-black text-xs uppercase tracking-widest">Initialising Talent Portal...</p>
                    </div>
                ) : filteredApps.length === 0 ? (
                    <div className="bg-white rounded-[3rem] p-20 border border-slate-100 text-center space-y-4">
                        <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-200">
                            <Filter className="w-10 h-10" />
                        </div>
                        <h3 className="text-xl font-serif font-black text-slate-900">No Applications Found</h3>
                        <p className="text-slate-400 font-medium max-w-xs mx-auto text-sm">There are no pending applications matching your criteria at this time.</p>
                    </div>
                ) : (
                    <AnimatePresence mode="popLayout">
                        {filteredApps.map((app, index) => (
                            <motion.div
                                key={app.id}
                                layout
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.9 }}
                                className="bg-white rounded-[2.5rem] border border-blue-50 shadow-xl shadow-blue-900/5 overflow-hidden group hover:border-primary/20 transition-all"
                            >
                                <div className="flex flex-col lg:flex-row">
                                    {/* Left Info Area */}
                                    <div className="p-8 lg:p-10 flex-1 flex flex-col md:flex-row gap-8 items-center md:items-start text-center md:text-left">
                                        <div className="w-24 h-24 rounded-3xl bg-blue-50 border-4 border-white shadow-xl flex-shrink-0 overflow-hidden">
                                            {app.photo_url ? (
                                                <img src={app.photo_url} alt="" className="w-full h-full object-cover" />
                                            ) : (
                                                <div className="w-full h-full flex items-center justify-center">
                                                    <User className="w-10 h-10 text-blue-300" />
                                                </div>
                                            )}
                                        </div>

                                        <div className="space-y-4 flex-1">
                                            <div>
                                                <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 mb-2">
                                                    <h3 className="text-2xl font-serif font-black text-slate-900">{app.full_name}</h3>
                                                    <span className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border italic ${app.application_type === 'editor'
                                                        ? 'bg-purple-50 text-purple-600 border-purple-100'
                                                        : 'bg-emerald-50 text-emerald-600 border-emerald-100'
                                                        }`}>
                                                        {app.application_type}
                                                    </span>
                                                </div>
                                                <div className="flex flex-wrap items-center justify-center md:justify-start gap-x-6 gap-y-2 text-slate-500 text-sm font-medium">
                                                    <p className="flex items-center gap-2"><Mail className="w-4 h-4 text-blue-400" /> {app.email}</p>
                                                    <p className="flex items-center gap-2"><Building2 className="w-4 h-4 text-blue-400" /> {app.institute}</p>
                                                    <p className="flex items-center gap-2"><Briefcase className="w-4 h-4 text-blue-400" /> {app.designation}</p>
                                                </div>
                                            </div>

                                            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4">
                                                <a
                                                    href={app.cv_url}
                                                    target="_blank"
                                                    className="flex items-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] hover:bg-black transition-all shadow-lg shadow-black/10"
                                                >
                                                    <FileText className="w-4 h-4" /> View CV
                                                </a>
                                                <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">
                                                    Submitted: {new Date(app.created_at).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Action Area */}
                                    <div className="bg-slate-50 lg:w-80 p-8 lg:p-10 border-t lg:border-t-0 lg:border-l border-slate-100 flex flex-col justify-center gap-4">
                                        <button
                                            disabled={processingId !== null}
                                            onClick={() => handleApprove(app.id)}
                                            className="w-full group/btn flex items-center justify-between p-5 bg-white rounded-2xl border border-emerald-100 text-emerald-600 font-black text-xs uppercase tracking-widest shadow-sm hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-all disabled:opacity-50"
                                        >
                                            {processingId === app.id ? "Processing..." : (
                                                <>
                                                    Approve & Invite
                                                    <CheckCircle2 className="w-5 h-5 group-hover/btn:scale-110 transition-transform" />
                                                </>
                                            )}
                                        </button>
                                        <button
                                            disabled={processingId !== null}
                                            onClick={() => handleReject(app.id)}
                                            className="w-full group/btn flex items-center justify-between p-5 bg-white rounded-2xl border border-red-100 text-red-500 font-black text-xs uppercase tracking-widest shadow-sm hover:bg-red-500 hover:text-white hover:border-red-500 transition-all disabled:opacity-50"
                                        >
                                            {processingId === app.id ? "Processing..." : (
                                                <>
                                                    Reject Application
                                                    <XCircle className="w-5 h-5 group-hover/btn:scale-110 transition-transform" />
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                )}
            </div>
        </div>
    );
}
