import { getSubmissionById } from "@/actions/submissions";
import { getSession } from "@/actions/session";
import pool from "@/lib/db";
import {
    Calendar,
    User,
    Mail,
    FileText,
    Download,
    ArrowLeft,
    Clock,
    Shield,
    BookOpen,
    Eye,
    Lock
} from "lucide-react";
import Link from "next/link";
import { redirect, notFound } from "next/navigation";
import type { Metadata } from 'next';

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
    const { id } = await params;
    const submission = await getSubmissionById(parseInt(id));
    if (!submission) return { title: 'Manuscript Not Found | Reviewer' };

    return {
        title: `Review: ${submission.paper_id} | IJITEST`,
        description: `Reviewer evaluation for manuscript ${submission.paper_id}`,
    };
}

export default async function ReviewerSubmissionView({ params }: { params: Promise<{ id: string }> }) {
    const { id: idStr } = await params;
    const id = parseInt(idStr);
    const session = await getSession();

    if (!session || session.role !== 'reviewer' && session.role !== 'admin' && session.role !== 'editor') {
        redirect('/login');
    }

    if (isNaN(id)) return notFound();

    const submission = await getSubmissionById(id);
    if (!submission) return notFound();

    // Verify assignment for reviewers
    if (session.role === 'reviewer') {
        const [assignment]: any = await pool.execute(
            'SELECT id FROM reviews WHERE submission_id = ? AND reviewer_id = ?',
            [id, session.id]
        );
        if (assignment.length === 0) {
            return (
                <div className="p-20 text-center bg-white rounded-[2.5rem] border border-gray-100 shadow-sm max-w-2xl mx-auto">
                    <Lock className="w-16 h-16 text-rose-200 mx-auto mb-6" />
                    <h2 className="text-2xl font-serif font-black text-gray-900 mb-2">Access Restricted</h2>
                    <p className="text-gray-500 mb-8">You do not have permission to view this manuscript. It has not been assigned to you for review.</p>
                    <Link href="/reviewer/reviews" className="bg-primary text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-primary/20 hover:bg-primary/95 transition-all inline-block">
                        Back to My Assignments
                    </Link>
                </div>
            );
        }
    }

    return (
        <div className="max-w-6xl mx-auto space-y-8 pb-20">
            <Link href="/reviewer/reviews" className="flex items-center gap-2 text-gray-500 hover:text-primary transition-colors font-bold text-sm">
                <ArrowLeft className="w-4 h-4" /> Back to My Assignments
            </Link>

            <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden min-h-[80vh] flex flex-col md:flex-row">
                {/* Left Side: Details */}
                <div className="w-full md:w-1/3 p-10 border-b md:border-b-0 md:border-r border-gray-100 bg-gray-50/20 overflow-y-auto max-h-[80vh]">
                    <div className="space-y-8">
                        <div>
                            <span className="px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border bg-indigo-50 text-indigo-900 border-indigo-200">
                                Assigned Manuscript
                            </span>
                            <h1 className="text-2xl font-serif font-black text-gray-900 leading-tight mt-4">
                                {submission.title}
                            </h1>
                            <div className="flex flex-wrap items-center gap-4 text-xs text-gray-400 font-bold mt-4 uppercase tracking-wider">
                                <div className="flex items-center gap-2 text-primary">
                                    <Shield className="w-4 h-4" />
                                    <span>{submission.paper_id}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Clock className="w-4 h-4" />
                                    <span>{new Date(submission.submitted_at).toLocaleDateString()}</span>
                                </div>
                            </div>
                        </div>

                        <div className="pt-8 border-t border-gray-100">
                            <h3 className="text-sm font-black text-gray-900 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                                <FileText className="w-4 h-4 text-secondary" /> Abstract
                            </h3>
                            <p className="text-sm text-gray-600 leading-relaxed text-justify italic">
                                "{submission.abstract || "No abstract provided."}"
                            </p>
                        </div>

                        {submission.keywords && (
                            <div className="pt-8 border-t border-gray-100">
                                <h3 className="text-sm font-black text-gray-900 uppercase tracking-[0.2em] mb-4">Keywords</h3>
                                <div className="flex flex-wrap gap-2">
                                    {submission.keywords.split(',').map((k: string) => (
                                        <span key={k} className="px-3 py-1 bg-white border border-gray-200 rounded-lg text-[10px] font-bold text-gray-500 uppercase tracking-wider uppercase">
                                            {k.trim()}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        )}

                        <div className="pt-8 border-t border-gray-100">
                            <a
                                href={submission.file_path}
                                download
                                className="w-full flex items-center justify-center gap-2 bg-gray-900 text-white py-4 rounded-2xl font-bold shadow-lg hover:bg-black transition-all text-sm"
                            >
                                <Download className="w-5 h-5" /> Download for Offline Review
                            </a>
                        </div>
                    </div>
                </div>

                {/* Right Side: Viewer */}
                <div className="flex-1 bg-gray-100 flex flex-col items-center justify-center min-h-[800px] lg:min-h-0">
                    {submission.file_path ? (
                        <div className="w-full h-[800px] lg:h-full relative overflow-hidden">
                            <iframe
                                src={`${submission.file_path}#toolbar=0`}
                                className="w-full h-full border-none shadow-inner bg-white"
                                title="Manuscript Viewer"
                            />
                        </div>
                    ) : (
                        <div className="text-center p-20">
                            <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-6" />
                            <p className="text-gray-400 font-bold uppercase tracking-widest text-sm">Manuscript file not available for online viewing</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
