import {
    FileStack,
    Users,
    Activity,
    BookOpen,
    AlertCircle,
    TrendingUp,
    ArrowRight
} from 'lucide-react';
import Link from 'next/link';
import pool from '@/lib/db';

export const dynamic = 'force-dynamic';

import { getSession } from '@/actions/session';

export default async function AdminDashboard() {
    try {
        const user = await getSession();

        // Stats for Admin
        const [submissionRows]: any = await pool.execute('SELECT COUNT(*) as count FROM submissions');
        const totalSubmissions = submissionRows[0].count;

        const [userRows]: any = await pool.execute('SELECT COUNT(*) as count FROM users');
        const totalUsers = userRows[0].count;

        const [issueRows]: any = await pool.execute(
            "SELECT year FROM volumes_issues WHERE status = 'open' ORDER BY year DESC LIMIT 1"
        );
        const currentIssue = issueRows.length > 0
            ? `${issueRows[0].year} Edition`
            : '2026 Edition';

        const stats = [
            { label: 'System Health', value: '100%', icon: <Activity className="w-6 h-6" />, color: 'bg-green-600', trend: 'Online' },
            { label: 'Total Staff', value: String(totalUsers), icon: <Users className="w-6 h-6" />, color: 'bg-primary', trend: 'Active' },
            { label: 'Submissions', value: String(totalSubmissions), icon: <FileStack className="w-6 h-6" />, color: 'bg-blue-600', trend: 'Managed' },
            { label: 'Edition', value: currentIssue, icon: <BookOpen className="w-6 h-6" />, color: 'bg-secondary', trend: 'Public' },
        ];

        const [recentSubmissions]: any = await pool.execute(
            'SELECT id, paper_id, title, author_name, status, submitted_at FROM submissions ORDER BY submitted_at DESC LIMIT 3'
        );

        const currentRole = {
            title: 'Admin',
            subtitle: 'The Architect',
            job: 'Infrastructure & Technical Oversight',
            actions: ['Creating user accounts', 'Managing site security', 'Updating journal metadata (ISSN)', 'Fixing technical bugs']
        };

        return (
            <div className="space-y-12">
                {/* Role Overview */}
                <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-10 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full translate-x-32 -translate-y-32 group-hover:scale-110 transition-transform duration-700"></div>
                    <div className="relative z-10">
                        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                            <div>
                                <h2 className="text-2xl sm:text-3xl font-sans font-black text-gray-900 mb-2">Welcome Back, {user?.fullName}</h2>
                                <p className="text-gray-500 font-medium max-w-2xl">
                                    <span className="font-bold text-gray-900">Main Job:</span> {currentRole.job}
                                </p>
                            </div>
                            <div className="flex flex-wrap gap-2">
                                {currentRole.actions.slice(0, 2).map((action, i) => (
                                    <span key={i} className="px-4 py-2 rounded-xl bg-gray-50 text-gray-600 text-xs font-bold border border-gray-100">
                                        • {action}
                                    </span>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {stats.map((stat) => (
                        <div key={stat.label} className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-gray-200/50 transition-all group">
                            <div className="flex items-center justify-between mb-6">
                                <div className={`${stat.color} w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform`}>
                                    {stat.icon}
                                </div>
                                <span className="text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-tighter bg-green-50 text-green-600">
                                    {stat.trend}
                                </span>
                            </div>
                            <p className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-1">{stat.label}</p>
                            <h3 className="text-2xl sm:text-3xl font-sans font-black text-gray-900">{stat.value}</h3>
                        </div>
                    ))}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm p-10">
                        <div className="flex items-center justify-between mb-10">
                            <h2 className="text-2xl font-sans font-black text-gray-900">Recent Global Activity</h2>
                            <Link href="/admin/submissions" className="text-primary font-bold text-sm flex items-center gap-2 hover:underline">
                                Full Audit <ArrowRight className="w-4 h-4" />
                            </Link>
                        </div>
                        <div className="space-y-6">
                            {recentSubmissions.map((sub: any) => (
                                <Link
                                    href={`/admin/submissions/${sub.id}`}
                                    key={sub.paper_id}
                                    className="flex items-center justify-between p-6 bg-gray-50 rounded-2xl border border-transparent hover:border-primary/10 hover:bg-white transition-all cursor-pointer group/item"
                                >
                                    <div className="flex items-center gap-6">
                                        <div className="w-16 h-12 rounded-xl bg-white flex items-center justify-center font-mono font-black text-[10px] text-gray-400 border border-gray-100 px-2 text-center">
                                            {sub.paper_id}
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-gray-900 mb-1 line-clamp-1">{sub.title}</h4>
                                            <p className="text-xs text-gray-500">{sub.author_name} • {new Date(sub.submitted_at).toLocaleDateString()}</p>
                                        </div>
                                    </div>
                                    <span className="px-4 py-1.5 rounded-full bg-primary/10 text-primary text-[10px] font-black uppercase tracking-widest whitespace-nowrap">
                                        {sub.status.replace('_', ' ')}
                                    </span>
                                </Link>
                            ))}
                        </div>
                    </div>

                    <div className="bg-secondary p-10 rounded-2xl text-white relative overflow-hidden h-full flex flex-col justify-between">
                        <div className="relative z-10">
                            <TrendingUp className="w-12 h-12 mb-6 opacity-30" />
                            <h2 className="text-2xl font-sans font-black mb-4">Architect Mode</h2>
                            <div className="space-y-4">
                                <div className="bg-white/10 p-4 rounded-xl flex items-center gap-4">
                                    <AlertCircle className="w-5 h-5 text-white/50" />
                                    <span className="text-sm font-bold">Manage credentials</span>
                                </div>
                                <div className="bg-white/10 p-4 rounded-xl flex items-center gap-4">
                                    <AlertCircle className="w-5 h-5 text-white/50" />
                                    <span className="text-sm font-bold">Inspect server logs</span>
                                </div>
                            </div>
                        </div>
                        <Link href="/admin/users" className="bg-white text-secondary w-full py-4 rounded-xl font-bold mt-8 shadow-xl shadow-black/10 hover:bg-gray-100 transition-all text-center block" >
                            Manage Users & Access
                        </Link>
                    </div>
                </div>
            </div>
        );
    } catch (error: any) {
        console.error("Admin Dashboard Error:", error);
        return <div>Error loading admin dashboard.</div>;
    }
}
