'use client'

import { Plus, BookOpen, Clock, CheckCircle2, AlertCircle, Trash2, Globe } from 'lucide-react';
import { getVolumesIssues, createVolumeIssue, publishIssue } from '@/actions/publications';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function PublicationsPage() {
    const [volumes, setVolumes] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [status, setStatus] = useState<{ success?: boolean; error?: string } | null>(null);

    useEffect(() => {
        fetchData();
    }, []);

    async function fetchData() {
        setLoading(true);
        const data = await getVolumesIssues();
        setVolumes(data);
        setLoading(false);
    }

    async function handleCreate(formData: FormData) {
        setIsSubmitting(true);
        setStatus(null);
        const res = await createVolumeIssue(formData);
        if (res.success) {
            setStatus({ success: true });
            setShowCreateModal(false);
            fetchData();
            setTimeout(() => setStatus(null), 3000);
        } else {
            setStatus({ error: res.error });
        }
        setIsSubmitting(false);
    }

    async function handlePublish(id: number) {
        if (!confirm('Are you sure you want to PUBLISH this issue? This will also update the status of all assigned papers.')) return;
        const res = await publishIssue(id);
        if (res.success) fetchData();
        else alert(res.error);
    }

    if (loading) return <div className="p-20 text-center font-bold text-gray-400 uppercase tracking-widest">Initialising Publications...</div>;

    return (
        <div className="space-y-12 pb-20">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                    <h1 className="text-3xl font-serif font-black text-gray-900 mb-2">Volumes & Issues</h1>
                    <p className="text-gray-500 font-medium tracking-tight">Manage your journal's publication schedule and editorial cycles.</p>
                </div>
                <button
                    onClick={() => setShowCreateModal(true)}
                    className="bg-primary text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-primary/20 flex items-center gap-2 hover:bg-primary/95 transition-all"
                >
                    <Plus className="w-5 h-5" /> New Volume/Issue
                </button>
            </div>

            {status?.success && (
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 bg-emerald-50 text-emerald-700 rounded-2xl font-bold border border-emerald-100 flex items-center gap-3"
                >
                    <CheckCircle2 className="w-5 h-5" /> Issue created successfully!
                </motion.div>
            )}

            {/* Grid of Issues */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {volumes.map((v) => (
                    <motion.div
                        layout
                        key={v.id}
                        className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden hover:shadow-xl hover:shadow-blue-900/5 transition-all group"
                    >
                        <div className="p-8 space-y-6">
                            <div className="flex items-start justify-between">
                                <div className="space-y-1">
                                    <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em]">Volume {v.volume_number}</p>
                                    <h3 className="text-2xl font-serif font-black text-gray-900 leading-none">Issue {v.issue_number}</h3>
                                </div>
                                <span className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border ${v.status === 'published' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-amber-50 text-amber-900 border-amber-100'
                                    }`}>
                                    {v.status}
                                </span>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100/50">
                                    <Clock className="w-4 h-4 text-gray-400 mb-2" />
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Year</p>
                                    <p className="font-black text-gray-900">{v.year}</p>
                                </div>
                                <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100/50">
                                    <Globe className="w-4 h-4 text-gray-400 mb-2" />
                                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Cycle</p>
                                    <p className="font-black text-gray-900 truncate">{v.month_range}</p>
                                </div>
                            </div>

                            <div className="pt-2">
                                {v.status === 'open' ? (
                                    <button
                                        onClick={() => handlePublish(v.id)}
                                        className="w-full bg-primary text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-primary/10 hover:shadow-primary/20 transition-all flex items-center justify-center gap-2"
                                    >
                                        <CheckCircle2 className="w-4 h-4" /> Publish Issue
                                    </button>
                                ) : (
                                    <div className="w-full bg-emerald-50 text-emerald-700 py-4 rounded-2xl font-black text-xs uppercase tracking-widest border border-emerald-100 flex items-center justify-center gap-2">
                                        <Globe className="w-4 h-4" /> Live in Archives
                                    </div>
                                )}
                            </div>
                        </div>
                    </motion.div>
                ))}

                {volumes.length === 0 && (
                    <div className="col-span-full bg-gray-50 rounded-[3rem] p-20 flex flex-col items-center justify-center text-center border border-dashed border-gray-200">
                        <BookOpen className="w-16 h-16 text-gray-200 mb-6" />
                        <h3 className="text-xl font-serif font-black text-gray-400 mb-2">No Volumes Found</h3>
                        <p className="text-gray-400 max-w-sm">Create your first journal volume to begin the publication process.</p>
                    </div>
                )}
            </div>

            {/* Create Modal */}
            <AnimatePresence>
                {showCreateModal && (
                    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="bg-white rounded-[2.5rem] p-10 max-w-lg w-full shadow-2xl space-y-8"
                        >
                            <div className="flex items-center justify-between">
                                <h2 className="text-2xl font-serif font-black text-gray-900">New Publication</h2>
                                <button onClick={() => setShowCreateModal(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                                    <Trash2 className="w-6 h-6 text-gray-400" />
                                </button>
                            </div>

                            <form action={handleCreate} className="space-y-6">
                                <div className="grid grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-xs font-black text-gray-400 uppercase tracking-widest pl-2">Volume Number</label>
                                        <input
                                            name="volume"
                                            type="number"
                                            required
                                            className="w-full bg-gray-50 p-4 rounded-xl font-bold outline-none focus:ring-2 focus:ring-primary/20"
                                            placeholder="e.g. 1"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs font-black text-gray-400 uppercase tracking-widest pl-2">Issue Number</label>
                                        <input
                                            name="issue"
                                            type="number"
                                            required
                                            className="w-full bg-gray-50 p-4 rounded-xl font-bold outline-none focus:ring-2 focus:ring-primary/20"
                                            placeholder="e.g. 1"
                                        />
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest pl-2">Publication Year</label>
                                    <input
                                        name="year"
                                        type="number"
                                        required
                                        defaultValue={new Date().getFullYear()}
                                        className="w-full bg-gray-50 p-4 rounded-xl font-bold outline-none focus:ring-2 focus:ring-primary/20"
                                    />
                                </div>

                                <div className="space-y-2">
                                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest pl-2">Month Range / Cycle</label>
                                    <input
                                        name="monthRange"
                                        type="text"
                                        required
                                        placeholder="e.g. Jan - Mar"
                                        className="w-full bg-gray-50 p-4 rounded-xl font-bold outline-none focus:ring-2 focus:ring-primary/20"
                                    />
                                </div>

                                {status?.error && (
                                    <p className="text-red-500 text-xs font-bold bg-red-50 p-4 rounded-xl border border-red-100">
                                        {status.error}
                                    </p>
                                )}

                                <button
                                    disabled={isSubmitting}
                                    className="w-full bg-primary text-white py-5 rounded-2xl font-black shadow-xl shadow-primary/20 hover:shadow-2xl transition-all disabled:opacity-50"
                                >
                                    {isSubmitting ? 'Creating...' : 'Initialise Publication'}
                                </button>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
}
