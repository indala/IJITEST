"use client";

import { motion, AnimatePresence } from 'framer-motion';
import { useState, useRef, useEffect } from 'react';
import { useFormStatus } from 'react-dom';
import { Upload, X, CheckCircle2, AlertCircle, FileText, ImageIcon, Loader2 } from 'lucide-react';
import { submitReviewerApplication } from '@/actions/reviewer';
import { checkUserEmail } from '@/actions/users';

function FileInput({
    name,
    label,
    accept,
    icon: Icon
}: {
    name: string;
    label: string;
    accept: string;
    icon: any
}) {
    const [fileName, setFileName] = useState<string | null>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setFileName(file.name);
        } else {
            setFileName(null);
        }
    };

    return (
        <div className="space-y-2">
            <label className="block text-[10px] font-black text-slate-700 uppercase tracking-widest pl-1">
                {label} <span className="text-red-500">*</span>
            </label>
            <div
                onClick={() => inputRef.current?.click()}
                className={`
                    relative group cursor-pointer overflow-hidden
                    border-2 border-dashed rounded-2xl p-6
                    transition-all duration-300
                    ${fileName
                        ? 'border-emerald-200 bg-emerald-50/50'
                        : 'border-slate-200 hover:border-primary/30 hover:bg-slate-50'
                    }
                `}
            >
                <input
                    ref={inputRef}
                    type="file"
                    name={name}
                    accept={accept}
                    required
                    onChange={handleFileChange}
                    className="hidden"
                />

                <div className="flex items-center gap-4">
                    <div className={`
                        w-12 h-12 rounded-xl flex items-center justify-center transition-colors
                        ${fileName ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-400 group-hover:text-primary group-hover:bg-primary/5'}
                    `}>
                        {fileName ? <CheckCircle2 className="w-6 h-6" /> : <Icon className="w-6 h-6" />}
                    </div>

                    <div className="flex-1 min-w-0">
                        <p className={`text-sm font-bold truncate ${fileName ? 'text-emerald-700' : 'text-slate-700'}`}>
                            {fileName || "Click to browse"}
                        </p>
                        <p className="text-xs text-slate-400 font-medium">
                            {fileName ? "File selected" : accept.replace(/\./g, ' ').toUpperCase()}
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}

function SubmitButton({ disabled }: { disabled?: boolean }) {
    const { pending } = useFormStatus();

    return (
        <button
            type="submit"
            disabled={pending || disabled}
            className="w-full bg-primary text-white py-5 rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-primary/20 hover:shadow-2xl hover:bg-primary/95 transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:grayscale disabled:cursor-not-allowed"
        >
            {pending ? (
                <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Processing...</span>
                </>
            ) : (
                <>
                    <span>Submit Application</span>
                    <CheckCircle2 className="w-5 h-5" />
                </>
            )}
        </button>
    );
}

export default function ReviewerApplicationForm() {
    const [state, setState] = useState<{ success?: boolean; error?: string } | null>(null);
    const [activeTab, setActiveTab] = useState<'reviewer' | 'editor'>('reviewer');
    const [email, setEmail] = useState('');
    const [emailStatus, setEmailStatus] = useState<{ loading: boolean; exists: boolean | null }>({ loading: false, exists: null });

    useEffect(() => {
        if (!email || email.length < 5 || !email.includes('@')) {
            setEmailStatus({ loading: false, exists: null });
            return;
        }

        const timeoutId = setTimeout(async () => {
            setEmailStatus({ loading: true, exists: null });
            const result = await checkUserEmail(email);
            setEmailStatus({ loading: false, exists: !!result.exists });
        }, 500);

        return () => clearTimeout(timeoutId);
    }, [email]);

    async function handleSubmit(formData: FormData) {
        if (emailStatus.exists) return;
        formData.append('application_type', activeTab);
        const result = await submitReviewerApplication(formData);
        if (result.success) {
            setState({ success: true });
        } else {
            setState({ error: result.error });
        }
    }

    if (state?.success) {
        return (
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-[2.5rem] p-12 shadow-xl shadow-slate-200/50 border border-slate-100 text-center"
            >
                <div className="w-24 h-24 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-8">
                    <CheckCircle2 className="w-12 h-12 text-emerald-500" />
                </div>
                <h2 className="text-3xl font-serif font-black text-slate-900 mb-4">Application Received!</h2>
                <p className="text-slate-600 font-medium text-lg mb-8 max-w-md mx-auto">
                    {activeTab === 'reviewer'
                        ? "Thank you for your interest in joining our review board. Our editorial team will review your application and get back to you shortly."
                        : "Thank you for your interest in joining our editorial board. We will review your profile and academic background for editorial responsibilities."
                    }
                </p>
                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 inline-block text-left">
                    <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">What happens next?</p>
                    <ul className="space-y-2 text-sm font-bold text-slate-700">
                        <li className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                            Admin Review (24-48 hours)
                        </li>
                        <li className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                            Invitation via Email
                        </li>
                        <li className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                            Onboarding & Credentials
                        </li>
                    </ul>
                </div>
            </motion.div>
        );
    }

    return (
        <div className="bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden">
            <div className="bg-gradient-to-br from-blue-600 to-primary p-8 md:p-10 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                    <FileText className="w-32 h-32" />
                </div>
                <h2 className="text-2xl md:text-3xl font-serif font-black mb-2 relative z-10">
                    {activeTab === 'reviewer' ? 'Join Review Board' : 'Join Editorial Board'}
                </h2>
                <p className="text-white/80 font-medium relative z-10 leading-snug">
                    {activeTab === 'reviewer'
                        ? 'Contribute to the scientific community by reviewing innovative research.'
                        : 'Shape the journal\'s direction by joining our distinguished editorial team.'
                    }
                </p>
            </div>

            {/* Role Selection Tabs */}
            <div className="flex p-2 bg-slate-100 mx-8 mt-8 rounded-2xl">
                <button
                    onClick={() => setActiveTab('reviewer')}
                    className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'reviewer'
                        ? 'bg-white text-primary shadow-sm'
                        : 'text-slate-400 hover:text-slate-600'
                        }`}
                >
                    Reviewer
                </button>
                <button
                    onClick={() => setActiveTab('editor')}
                    className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'editor'
                        ? 'bg-white text-primary shadow-sm'
                        : 'text-slate-400 hover:text-slate-600'
                        }`}
                >
                    Editor
                </button>
            </div>

            <div className="p-8 md:p-10 pt-6">
                <AnimatePresence mode='wait'>
                    {state?.error && (
                        <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mb-8 p-4 bg-red-50 border border-red-100 text-red-600 rounded-2xl text-sm font-bold flex items-center gap-3"
                        >
                            <AlertCircle className="w-5 h-5 flex-shrink-0" />
                            {state.error}
                        </motion.div>
                    )}
                </AnimatePresence>

                <form action={handleSubmit} className="space-y-8">
                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="block text-[10px] font-black text-slate-700 uppercase tracking-widest pl-1">Full Name <span className="text-red-500">*</span></label>
                            <input
                                name="fullName"
                                type="text"
                                required
                                className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-transparent focus:bg-white focus:border-primary/20 focus:ring-4 focus:ring-primary/5 transition-all outline-none text-slate-900 font-bold"
                                placeholder="Dr. John Doe"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="block text-[10px] font-black text-slate-700 uppercase tracking-widest pl-1">Designation <span className="text-red-500">*</span></label>
                            <input
                                name="designation"
                                type="text"
                                required
                                className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-transparent focus:bg-white focus:border-primary/20 focus:ring-4 focus:ring-primary/5 transition-all outline-none text-slate-900 font-bold"
                                placeholder="Associate Professor"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="block text-[10px] font-black text-slate-700 uppercase tracking-widest pl-1">Institute / Organization <span className="text-red-500">*</span></label>
                        <input
                            name="institute"
                            type="text"
                            required
                            className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-transparent focus:bg-white focus:border-primary/20 focus:ring-4 focus:ring-primary/5 transition-all outline-none text-slate-900 font-bold"
                            placeholder="University of Technology..."
                        />
                    </div>

                    <div className="space-y-2">
                        <div className="flex items-center justify-between pl-1">
                            <label className="block text-[10px] font-black text-slate-700 uppercase tracking-widest">Email Address <span className="text-red-500">*</span></label>
                            {emailStatus.loading && <Loader2 className="w-3 h-3 animate-spin text-primary" />}
                        </div>
                        <div className="relative">
                            <input
                                name="email"
                                type="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className={`w-full px-5 py-4 rounded-2xl bg-slate-50 border transition-all outline-none text-slate-900 font-bold ${emailStatus.exists
                                        ? 'border-red-200 bg-red-50/10 focus:ring-red-500/5'
                                        : 'border-transparent focus:bg-white focus:border-primary/20 focus:ring-4 focus:ring-primary/5'
                                    }`}
                                placeholder="email@institution.edu"
                            />
                            {emailStatus.exists && (
                                <motion.div
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    className="absolute -bottom-6 left-1 flex items-center gap-1.5 text-red-500"
                                >
                                    <AlertCircle className="w-3 h-3" />
                                    <span className="text-[10px] font-black uppercase tracking-widest">Account already exists in our system.</span>
                                </motion.div>
                            )}
                        </div>
                    </div>


                    <div className="grid md:grid-cols-2 gap-6 pt-6 border-t border-slate-100">
                        <FileInput
                            name="cv"
                            label="Attach CV"
                            accept=".doc,.docx,.pdf"
                            icon={FileText}
                        />
                        <FileInput
                            name="photo"
                            label="Attach Photo"
                            accept=".jpg,.jpeg,.png"
                            icon={ImageIcon}
                        />
                    </div>

                    <div className="pt-8">
                        <SubmitButton disabled={!!emailStatus.exists} />
                        <p className="text-center mt-4 text-[10px] text-slate-400 font-medium italic">
                            {emailStatus.exists
                                ? "Please log in to your existing account instead of applying again."
                                : "By submitting this form, you agree to our professional code of conduct."
                            }
                        </p>
                    </div>
                </form>
            </div>
        </div>
    );
}
