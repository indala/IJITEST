'use client';

import { Download, User, BookOpen, Eye } from 'lucide-react';
import Link from 'next/link';

interface PaperCardProps {
    paper: {
        id: number | string;
        paper_id: string;
        title: string;
        author_name: string;
        author_email?: string;
        affiliation?: string;
        keywords?: string;
        abstract?: string;
        file_path?: string;
        volume_number?: number;
        issue_number?: number;
        publication_year?: number;
        month_range?: string;
    };
}

export default function PaperCard({ paper }: PaperCardProps) {
    return (
        <div className="bg-white p-8 md:p-10 rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-primary/5 transition-all group relative overflow-hidden">
            {/* Decorative background accent */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16 blur-3xl group-hover:bg-primary/10 transition-colors" />

            <div className="flex flex-col gap-8 relative z-10">
                {/* Header info */}
                <div className="flex flex-wrap items-center gap-3">
                    <span className="bg-primary/5 text-primary text-[10px] font-black px-3 py-1.5 rounded-full uppercase tracking-[0.15em]">Research Article</span>
                    {paper.volume_number && (
                        <span className="flex items-center gap-1.5 bg-secondary/10 text-secondary text-[10px] font-black px-3 py-1.5 rounded-full uppercase tracking-[0.15em]">
                            <BookOpen className="w-3 h-3" /> Volume {paper.volume_number}, Issue {paper.issue_number} ({paper.publication_year})
                        </span>
                    )}
                </div>

                <div className="space-y-4">
                    <Link href={`/archives/${paper.id}`}>
                        <h3 className="text-xl sm:text-2xl font-sans font-black text-gray-900 leading-tight group-hover:text-primary transition-colors cursor-pointer">
                            {paper.title}
                        </h3>
                    </Link>

                    <div className="flex flex-wrap items-center gap-x-8 gap-y-3">
                        <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center border border-gray-100">
                                <User className="w-4 h-4 text-gray-400" />
                            </div>
                            <span className="text-sm font-bold text-gray-600">{paper.author_name}</span>
                        </div>
                        <div className="flex items-center gap-3 text-[10px] font-bold text-gray-400 border-l border-gray-100 pl-8">
                            <span className="uppercase tracking-widest">Paper ID:</span>
                            <span className="bg-gray-50 px-3 py-1 rounded-lg text-gray-900 font-mono tracking-tighter">{paper.paper_id}</span>
                        </div>
                    </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row items-center gap-4 pt-4 border-t border-gray-50">
                    <Link
                        href={`/archives/${paper.id}`}
                        className="w-full sm:w-auto flex items-center justify-center gap-3 bg-primary text-white text-xs font-black uppercase tracking-[0.2em] px-6 py-4 sm:px-10 sm:py-5 rounded-2xl hover:bg-primary/95 transition-all shadow-lg shadow-primary/20 hover:shadow-primary/30"
                    >
                        <Eye className="w-4 h-4" /> Read Article
                    </Link>

                    {paper.file_path && (
                        <a
                            href={paper.file_path}
                            download
                            className="w-full sm:w-auto flex items-center justify-center gap-3 bg-white text-gray-600 text-xs font-black uppercase tracking-[0.2em] px-6 py-4 sm:px-10 sm:py-5 rounded-2xl transition-all border-2 border-gray-100 hover:border-primary/20 hover:text-primary shadow-sm hover:shadow-md"
                        >
                            <Download className="w-4 h-4" /> Download PDF
                        </a>
                    )}
                </div>
            </div>
        </div>
    );
}
