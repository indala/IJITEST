"use client";

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles, Gift } from 'lucide-react';

export default function PromotionPopup() {
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const timer = setTimeout(() => {
            const hasSeen = localStorage.getItem('hasSeenPromotion');
            if (!hasSeen) {
                setIsVisible(true);
            }
        }, 5000); // 5 seconds delay

        return () => clearTimeout(timer);
    }, []);

    const closePopup = () => {
        setIsVisible(false);
        localStorage.setItem('hasSeenPromotion', 'true');
    };

    return (
        <AnimatePresence>
            {isVisible && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 20 }}
                        className="relative max-w-md w-full bg-white rounded-2xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col"
                    >
                        {/* Decorative Background */}
                        <div className="absolute top-0 right-0 w-64 h-64 bg-secondary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />
                        <div className="absolute bottom-0 left-0 w-48 h-48 bg-primary/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2 pointer-events-none" />

                        {/* Close Button */}
                        <button
                            onClick={closePopup}
                            className="absolute top-4 right-4 sm:top-6 sm:right-6 p-2 text-gray-400 hover:text-gray-900 transition-colors z-20 bg-gray-50 rounded-full shadow-sm"
                            aria-label="Close promotion"
                        >
                            <X className="w-5 h-5" />
                        </button>

                        <div className="relative z-10 p-6 sm:p-9 text-center space-y-5 sm:space-y-7 overflow-y-auto sm:overflow-y-visible">
                            <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 bg-primary/10 rounded-xl sm:rounded-2xl text-primary mb-1 mx-auto">
                                <Sparkles className="w-7 h-7 sm:w-8 sm:h-8" />
                            </div>

                            <div className="space-y-2 sm:space-y-3">
                                <span className="inline-block px-3 py-1 bg-secondary text-white text-[9px] sm:text-[10px] font-black uppercase tracking-[0.3em] rounded-full">
                                    Special Offer
                                </span>
                                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-sans font-black text-gray-900 leading-tight">
                                    Publish Your Research <br />
                                    <span className="text-primary">Absolutely Free!</span>
                                </h2>
                                <p className="text-xs sm:text-sm text-gray-600 font-medium leading-relaxed border-l-4 border-primary/20 pl-4 sm:pl-6 text-left">
                                    In our commitment to supporting early-career researchers, the <strong>First Author</strong> will receive <strong>100% Waiver</strong> on Article Processing Charges (APC) for our 2026 issues.
                                </p>
                            </div>

                            <div className="bg-gray-50 p-4 sm:p-5 rounded-xl sm:rounded-2xl border border-gray-100 flex items-center gap-4 text-left">
                                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-lg sm:rounded-xl flex items-center justify-center shadow-sm shrink-0">
                                    <Gift className="w-5 h-5 sm:w-6 sm:h-6 text-secondary" />
                                </div>
                                <p className="text-[10px] sm:text-xs font-bold text-gray-500">
                                    Limited time offer. Applicable for high-quality technical papers submitted this month.
                                </p>
                            </div>

                            <div className="flex flex-col gap-3 sm:gap-4 pt-1">
                                <button
                                    onClick={closePopup}
                                    className="w-full py-4 sm:py-4.5 bg-primary text-white rounded-xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-primary/20 hover:shadow-2xl hover:bg-primary/95 transition-all"
                                >
                                    Submit Now
                                </button>
                                <button
                                    onClick={closePopup}
                                    className="text-[9px] sm:text-[10px] font-black text-gray-400 uppercase tracking-widest hover:text-gray-900 transition-colors"
                                >
                                    Remind Me Later
                                </button>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
}
