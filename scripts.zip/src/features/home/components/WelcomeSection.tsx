'use client';
import { motion } from 'framer-motion';
import { memo } from 'react';

interface WelcomeSectionProps {
    journalName?: string;
    journalShortName?: string;
    settings: Record<string, string>;
}

function WelcomeSection({ journalName, journalShortName, settings }: WelcomeSectionProps) {
    const name = journalName || "International Journal of Innovative Trends in Engineering Science and Technology";
    const shortName = journalShortName || "IJITEST";

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
        >
            <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-sans font-black text-primary mb-8 tracking-tight">
                Welcome to <span className="text-secondary">{shortName}</span>
            </h1>
            <div className="prose prose-sm sm:prose-base md:prose-lg text-slate-950 font-medium leading-relaxed border-l-4 border-primary/20 pl-8 space-y-6">
                <p>
                    {name} ({shortName}) is a scholarly open access online international journal, which aims to publish peer-reviewed original research papers in the field of various Engineering disciplines. Backed by {settings.publisher_name || 'Felix Academic Publications'} and guided by COPE-compliant ethics, {shortName} accelerates high-quality research from submission to global indexing.
                </p>
                <p>
                    {shortName} aims to bring the new application developments among the researchers and academicians, laying the foundation of sharing research knowledge among the global scientific community. All submitted papers are peer-reviewed by experts in the relevant field, ensuring that accepted papers are published online immediately after final manuscript verification.
                </p>
                <div className="pt-4 border-t border-primary/10">
                    <p className="text-sm font-bold text-primary">
                        Average decision time: 3&ndash;5 working days after submission.
                    </p>
                </div>
            </div>
        </motion.div>
    );
}

export default memo(WelcomeSection);
