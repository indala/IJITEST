"use client";

import { useState, useRef } from 'react';
import { Camera, Save, AlertCircle, CheckCircle2, User, Building2, Briefcase, Phone, FileText } from 'lucide-react';
import { motion } from 'framer-motion';
import { updateUserProfile } from '@/actions/users';

interface ProfileFormProps {
    user: {
        id: number;
        email: string;
        full_name: string;
        designation?: string;
        institute?: string;
        phone?: string;
        bio?: string;
        photo_url?: string;
        role: string;
    };
}

export default function ProfileForm({ user }: ProfileFormProps) {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [status, setStatus] = useState<{ success?: boolean; error?: string } | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(user.photo_url || null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    async function handleAction(formData: FormData) {
        setIsSubmitting(true);
        setStatus(null);

        try {
            const result = await updateUserProfile(formData);
            if (result.success) {
                setStatus({ success: true });
                setTimeout(() => setStatus(null), 5000);
            } else {
                setStatus({ error: result.error });
            }
        } catch (error) {
            setStatus({ error: "An unexpected error occurred." });
        } finally {
            setIsSubmitting(false);
        }
    }

    const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreviewUrl(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="max-w-4xl mx-auto">
            <form action={handleAction} className="space-y-8">
                {/* Profile Header Card */}
                <div className="bg-white rounded-[2.5rem] p-8 md:p-10 shadow-xl shadow-blue-900/5 border border-blue-50 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 -z-10" />

                    <div className="flex flex-col md:flex-row gap-8 items-center md:items-start relative z-10">
                        {/* Photo Upload Area */}
                        <div className="relative group">
                            <div className="w-32 h-32 md:w-40 md:h-40 rounded-[2rem] bg-blue-100 border-4 border-white shadow-lg overflow-hidden flex items-center justify-center">
                                {previewUrl ? (
                                    <img src={previewUrl} alt="Profile" className="w-full h-full object-cover" />
                                ) : (
                                    <User className="w-16 h-16 text-blue-400" />
                                )}
                            </div>
                            <button
                                type="button"
                                onClick={() => fileInputRef.current?.click()}
                                className="absolute -bottom-2 -right-2 w-12 h-12 bg-primary text-white rounded-2xl flex items-center justify-center shadow-lg border-4 border-white hover:scale-110 transition-transform"
                            >
                                <Camera className="w-5 h-5" />
                            </button>
                            <input
                                type="file"
                                name="photo"
                                ref={fileInputRef}
                                className="hidden"
                                accept="image/*"
                                onChange={handlePhotoChange}
                            />
                            <input type="hidden" name="existingPhotoUrl" value={user.photo_url || ''} />
                        </div>

                        <div className="flex-1 text-center md:text-left pt-4">
                            <h2 className="text-2xl md:text-3xl font-serif font-black text-slate-900 mb-2">{user.full_name}</h2>
                            <p className="text-primary font-black text-xs uppercase tracking-[0.2em] mb-4 bg-blue-50 inline-block px-4 py-1.5 rounded-full border border-blue-100 italic">
                                {user.role} Account
                            </p>
                            <p className="text-slate-500 font-medium text-sm flex items-center justify-center md:justify-start gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                                {user.email}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Professional Details Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-6 bg-white rounded-[2.5rem] p-8 shadow-xl shadow-blue-900/5 border border-blue-50">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                                <Briefcase className="w-5 h-5 text-primary" />
                            </div>
                            <h3 className="font-black text-slate-900 uppercase tracking-widest text-xs">Identity & Role</h3>
                        </div>

                        <div className="space-y-4">
                            <div className="space-y-2">
                                <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-1">Full Name</label>
                                <input
                                    type="text"
                                    name="fullName"
                                    defaultValue={user.full_name}
                                    required
                                    className="w-full bg-slate-50 border-none rounded-2xl px-5 py-4 text-sm font-bold text-slate-700 focus:ring-2 focus:ring-primary/20 transition-all"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-1">Designation</label>
                                <input
                                    type="text"
                                    name="designation"
                                    defaultValue={user.designation}
                                    placeholder="e.g. Associate Professor"
                                    className="w-full bg-slate-50 border-none rounded-2xl px-5 py-4 text-sm font-bold text-slate-700 focus:ring-2 focus:ring-primary/20 transition-all"
                                />
                            </div>
                        </div>
                    </div>

                    <div className="space-y-6 bg-white rounded-[2.5rem] p-8 shadow-xl shadow-blue-900/5 border border-blue-50">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                                <Building2 className="w-5 h-5 text-primary" />
                            </div>
                            <h3 className="font-black text-slate-900 uppercase tracking-widest text-xs">Affiliation</h3>
                        </div>

                        <div className="space-y-4">
                            <div className="space-y-2">
                                <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-1">Institution / University</label>
                                <input
                                    type="text"
                                    name="institute"
                                    defaultValue={user.institute}
                                    placeholder="e.g. Stanford University"
                                    className="w-full bg-slate-50 border-none rounded-2xl px-5 py-4 text-sm font-bold text-slate-700 focus:ring-2 focus:ring-primary/20 transition-all"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-xs font-black text-slate-400 uppercase tracking-widest px-1">Phone Number</label>
                                <input
                                    type="tel"
                                    name="phone"
                                    defaultValue={user.phone}
                                    placeholder="+1 (555) 000-0000"
                                    className="w-full bg-slate-50 border-none rounded-2xl px-5 py-4 text-sm font-bold text-slate-700 focus:ring-2 focus:ring-primary/20 transition-all"
                                />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Bio / About Section */}
                <div className="bg-white rounded-[2.5rem] p-8 shadow-xl shadow-blue-900/5 border border-blue-50 space-y-6">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                            <FileText className="w-5 h-5 text-primary" />
                        </div>
                        <h3 className="font-black text-slate-900 uppercase tracking-widest text-xs">Short Bio / Expertise</h3>
                    </div>
                    <textarea
                        name="bio"
                        defaultValue={user.bio}
                        placeholder="Tell us about your academic background and research interests..."
                        rows={4}
                        className="w-full bg-slate-50 border-none rounded-3xl px-6 py-5 text-sm font-medium text-slate-700 focus:ring-2 focus:ring-primary/20 transition-all resize-none"
                    />
                </div>

                {/* Feedback Messages */}
                {status && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`p-6 rounded-3xl flex items-center gap-4 ${status.success ? 'bg-emerald-50 border border-emerald-100 text-emerald-800' : 'bg-red-50 border border-red-100 text-red-800'
                            }`}
                    >
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${status.success ? 'bg-white text-emerald-500' : 'bg-white text-red-500'
                            }`}>
                            {status.success ? <CheckCircle2 className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
                        </div>
                        <div>
                            <p className="font-black text-xs uppercase tracking-widest mb-0.5">
                                {status.success ? 'Success' : 'Error Occurred'}
                            </p>
                            <p className="font-bold text-sm">
                                {status.success ? 'Your profile details have been saved successfully.' : status.error}
                            </p>
                        </div>
                    </motion.div>
                )}

                {/* Submit Button */}
                <div className="flex justify-end pt-4">
                    <button
                        type="submit"
                        disabled={isSubmitting}
                        className="bg-primary text-white px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-primary/20 hover:shadow-2xl hover:-translate-y-1 transition-all flex items-center gap-3 disabled:opacity-50 disabled:translate-y-0"
                    >
                        {isSubmitting ? (
                            <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        ) : (
                            <Save className="w-5 h-5" />
                        )}
                        {isSubmitting ? "Saving Changes..." : "Save Profile Details"}
                    </button>
                </div>
            </form>
        </div>
    );
}
